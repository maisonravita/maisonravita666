'use client';

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Loader2, ShieldCheck } from 'lucide-react';
import { supabase, type Ingredient } from '@/lib/supabase';
import { toast } from '@/hooks/use-toast';

export type DietFlags = Pick<Ingredient, 'halal_certified' | 'contains_pork' | 'contains_alcohol'>;

export const EMPTY_DIET_FLAGS: DietFlags = {
  halal_certified: false,
  contains_pork: false,
  contains_alcohol: false,
};

const FIELDS: Array<{ key: keyof DietFlags; label: string; hint: string; meatOnly?: boolean }> = [
  { key: 'halal_certified', label: 'Halal certifié', hint: 'Viande livrée avec certification halal', meatOnly: true },
  { key: 'contains_pork', label: 'Contient du porc', hint: 'Lardons, jambon, saucisse, gélatine de porc…' },
  { key: 'contains_alcohol', label: 'Contient de l’alcool', hint: 'Vin, bière, sauce au vin…' },
];

export function DietFlagsFields({
  value,
  onChange,
  category,
  idPrefix,
}: {
  value: DietFlags;
  onChange: (next: DietFlags) => void;
  category: string;
  idPrefix: string;
}) {
  return (
    <div className="space-y-2">
      {FIELDS.filter((f) => !f.meatOnly || category === 'viandes').map((f) => (
        <div key={f.key} className="flex items-center justify-between gap-3 rounded-lg bg-background/60 px-3 py-2">
          <Label htmlFor={`${idPrefix}-${f.key}`} className="text-sm leading-snug">
            {f.label}
            <span className="block text-xs font-normal text-muted-foreground">{f.hint}</span>
          </Label>
          <Switch
            id={`${idPrefix}-${f.key}`}
            checked={value[f.key]}
            onCheckedChange={(checked) =>
              onChange({
                ...value,
                [f.key]: checked,
                ...(f.key === 'contains_pork' && checked ? { halal_certified: false } : {}),
              })
            }
          />
        </div>
      ))}
    </div>
  );
}

export function DietBadges({ ingredient }: { ingredient: DietFlags & { category: string } }) {
  const badges = [
    ingredient.category === 'viandes' && ingredient.halal_certified && { label: 'Halal', cls: 'border-emerald-300 text-emerald-700' },
    ingredient.contains_pork && { label: 'Porc', cls: 'border-rose-300 text-rose-700' },
    ingredient.contains_alcohol && { label: 'Alcool', cls: 'border-orange-300 text-orange-700' },
  ].filter((b): b is { label: string; cls: string } => !!b);
  if (badges.length === 0) return null;
  return (
    <div className="mb-2 flex flex-wrap gap-1">
      {badges.map((b) => (
        <Badge key={b.label} variant="outline" className={`text-[11px] ${b.cls}`}>
          {b.label}
        </Badge>
      ))}
    </div>
  );
}

export function DietFlagsDialog({
  ingredient,
  onClose,
  onDone,
}: {
  ingredient: Ingredient;
  onClose: () => void;
  onDone: () => void;
}) {
  const [flags, setFlags] = useState<DietFlags>({
    halal_certified: ingredient.halal_certified,
    contains_pork: ingredient.contains_pork,
    contains_alcohol: ingredient.contains_alcohol,
  });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase.from('ingredients').update(flags).eq('id', ingredient.id);
    setSaving(false);
    if (error) {
      console.error('diet flags update failed', error);
      toast({ title: 'Enregistrement impossible', description: 'Réessayez dans un instant.', variant: 'destructive' });
      return;
    }
    toast({ title: 'Régime alimentaire mis à jour', description: ingredient.name });
    onDone();
  };

  return (
    <Dialog open onOpenChange={(o) => !o && !saving && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            {ingredient.name}
          </DialogTitle>
          <DialogDescription>
            Ces informations servent à respecter les restrictions alimentaires (halal, sans porc…) lors de la
            création des menus.
          </DialogDescription>
        </DialogHeader>
        <div className="rounded-xl bg-muted/40 p-2">
          <DietFlagsFields value={flags} onChange={setFlags} category={ingredient.category} idPrefix="edit" />
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose} disabled={saving}>Annuler</Button>
          <Button onClick={save} disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Enregistrer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
