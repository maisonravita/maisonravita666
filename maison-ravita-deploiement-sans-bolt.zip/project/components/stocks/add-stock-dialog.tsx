'use client';

import { useMemo, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, PackagePlus, Sparkles, X } from 'lucide-react';
import { supabase, type Ingredient } from '@/lib/supabase';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { DietFlagsFields, EMPTY_DIET_FLAGS, type DietFlags } from '@/components/stocks/diet-flags';

export const CATEGORIES: Record<string, string> = {
  legumes: 'Légumes',
  fruits: 'Fruits',
  viandes: 'Viandes',
  poissons: 'Poissons',
  produits_laitiers: 'Produits laitiers & oeufs',
  feculents: 'Féculents',
  boulangerie: 'Boulangerie',
  epicerie: 'Épicerie',
  sauces: 'Sauces & condiments',
  huiles: 'Huiles',
  herbes: 'Herbes & épices',
  surgeles: 'Surgelés',
  boissons: 'Boissons',
  divers: 'Divers',
};

const UNITS = ['kg', 'g', 'L', 'cl', 'pièce', 'botte', 'douzaine', 'baguette', 'boîte', 'sachet', 'carton'];

type Props = {
  ingredients: Ingredient[];
  preselected?: Ingredient | null;
  onClose: () => void;
  onDone: () => void;
};

function friendlyError(message: string): string {
  if (message.includes('invalid_quantity')) return 'La quantité doit être supérieure à zéro.';
  if (message.includes('not_authorized')) return 'Seuls l’administrateur et le cuisinier peuvent modifier le stock.';
  if (message.includes('duplicate') || message.includes('23505')) return 'Cet aliment existe déjà, sélectionnez-le dans la liste.';
  return 'L’enregistrement a échoué. Réessayez.';
}

export function AddStockDialog({ ingredients, preselected, onClose, onDone }: Props) {
  const [name, setName] = useState(preselected?.name ?? '');
  const [selected, setSelected] = useState<Ingredient | null>(preselected ?? null);
  const [category, setCategory] = useState('divers');
  const [unit, setUnit] = useState('kg');
  const [price, setPrice] = useState('');
  const [threshold, setThreshold] = useState('');
  const [dietFlags, setDietFlags] = useState<DietFlags>(EMPTY_DIET_FLAGS);
  const [quantity, setQuantity] = useState('');
  const [expiry, setExpiry] = useState('');
  const [lot, setLot] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const suggestions = useMemo(() => {
    const q = name.trim().toLowerCase();
    if (!q || selected) return [];
    return ingredients.filter((i) => i.name.toLowerCase().includes(q)).slice(0, 6);
  }, [name, ingredients, selected]);

  const exact = ingredients.find((i) => i.name.toLowerCase() === name.trim().toLowerCase());
  const target = selected ?? exact ?? null;
  const isNew = !target && name.trim().length > 0;
  const currentUnit = target?.unit ?? unit;

  const pick = (ing: Ingredient) => {
    setSelected(ing);
    setName(ing.name);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const qty = parseFloat(quantity.replace(',', '.'));
    if (!name.trim()) return setError('Indiquez le nom de l’aliment.');
    if (!qty || qty <= 0) return setError('La quantité doit être supérieure à zéro.');
    const unitPrice = parseFloat(price.replace(',', '.'));
    if (isNew && (isNaN(unitPrice) || unitPrice < 0)) {
      return setError('Indiquez le prix d’achat par unité (sert au calcul du coût des menus).');
    }

    setSaving(true);
    try {
      let ingredientId = target?.id;
      if (!ingredientId) {
        const { data, error: insertError } = await supabase
          .from('ingredients')
          .insert({
            name: name.trim().replace(/^./, (c) => c.toUpperCase()),
            category,
            unit,
            price: unitPrice,
            alert_threshold: parseFloat(threshold.replace(',', '.')) || 0,
            ...dietFlags,
            halal_certified: category === 'viandes' && dietFlags.halal_certified,
          })
          .select('id')
          .maybeSingle();
        if (insertError) throw new Error(insertError.code === '23505' ? 'duplicate' : insertError.message);
        if (!data) throw new Error('insert_failed');
        ingredientId = data.id;
      }

      const { error: rpcError } = await supabase.rpc('add_stock', {
        p_ingredient_id: ingredientId,
        p_quantity: qty,
        p_lot_number: lot || null,
        p_expiry_date: expiry || null,
        p_reason: 'Entrée en stock',
      });
      if (rpcError) throw new Error(rpcError.message);

      toast({ title: 'Stock mis à jour', description: `+${qty} ${currentUnit} de ${name.trim()}` });
      onDone();
    } catch (err) {
      console.error('add stock failed', err);
      setError(friendlyError(err instanceof Error ? err.message : ''));
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && !saving && onClose()}>
      <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PackagePlus className="h-5 w-5 text-primary" />
            Ajouter au stock
          </DialogTitle>
          <DialogDescription>Saisissez librement n’importe quel aliment reçu ou acheté.</DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="space-y-4">
          <div className="relative space-y-2">
            <Label htmlFor="food-name">Aliment</Label>
            <div className="relative">
              <Input
                id="food-name"
                autoFocus={!preselected}
                autoComplete="off"
                placeholder="ex : Lentilles vertes, Pommes Gala, Cuisses de poulet…"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setSelected(null);
                }}
                className="pr-9"
              />
              {name && (
                <button
                  type="button"
                  aria-label="Effacer"
                  onClick={() => {
                    setName('');
                    setSelected(null);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            {suggestions.length > 0 && !exact && (
              <div className="absolute z-10 w-full overflow-hidden rounded-lg border bg-popover shadow-lg">
                {suggestions.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => pick(s)}
                    className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-muted"
                  >
                    <span>{s.name}</span>
                    <span className="text-xs text-muted-foreground">{s.unit}</span>
                  </button>
                ))}
              </div>
            )}
            {target && (
              <p className="text-xs text-muted-foreground">
                Aliment connu · {CATEGORIES[target.category] ?? target.category} · {Number(target.price).toFixed(2)} € / {target.unit}
              </p>
            )}
          </div>

          {isNew && (
            <div className="space-y-3 rounded-xl border border-primary/20 bg-primary/5 p-3">
              <p className="flex items-center gap-1.5 text-sm font-medium text-primary">
                <Sparkles className="h-4 w-4" /> Nouvel aliment
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">Catégorie</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(CATEGORIES).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Unité</Label>
                  <Select value={unit} onValueChange={setUnit}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {UNITS.map((u) => (
                        <SelectItem key={u} value={u}>{u}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Prix (€ / {unit})</Label>
                  <Input inputMode="decimal" placeholder="ex : 2,40" value={price} onChange={(e) => setPrice(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Seuil d’alerte ({unit})</Label>
                  <Input inputMode="decimal" placeholder="ex : 5" value={threshold} onChange={(e) => setThreshold(e.target.value)} />
                </div>
              </div>
              <DietFlagsFields value={dietFlags} onChange={setDietFlags} category={category} idPrefix="new" />
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1.5">
              <Label htmlFor="qty">Quantité reçue</Label>
              <div className="relative">
                <Input
                  id="qty"
                  inputMode="decimal"
                  autoFocus={!!preselected}
                  placeholder="0"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="pr-20 text-lg font-semibold"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">{currentUnit}</span>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="expiry" className="text-xs">Date limite (optionnel)</Label>
              <Input id="expiry" type="date" value={expiry} onChange={(e) => setExpiry(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="lot" className="text-xs">N° de lot (optionnel)</Label>
              <Input id="lot" placeholder="ex : L2410" value={lot} onChange={(e) => setLot(e.target.value)} />
            </div>
          </div>

          {error && <p className={cn('rounded-lg bg-destructive/10 p-3 text-sm text-destructive')}>{error}</p>}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={onClose} disabled={saving}>Annuler</Button>
            <Button type="submit" disabled={saving}>
              {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PackagePlus className="mr-2 h-4 w-4" />}
              Ajouter
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
