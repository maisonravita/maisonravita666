'use client';

import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ArrowDownRight, ArrowUpRight, ChefHat, History, Loader2, Trash2, SlidersHorizontal } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { cn } from '@/lib/utils';

type Movement = {
  id: string;
  movement_type: 'in' | 'out' | 'loss' | 'adjustment' | 'inventory';
  quantity: number;
  unit: string;
  reason: string | null;
  cargo_id: string | null;
  created_at: string;
  ingredients: { name: string } | null;
};

type Filter = 'all' | 'production' | 'manual';

const fmt = (n: number) => (Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0+$/, ''));

export function MovementsDialog({ onClose }: { onClose: () => void }) {
  const [movements, setMovements] = useState<Movement[] | null>(null);
  const [failed, setFailed] = useState(false);
  const [filter, setFilter] = useState<Filter>('all');

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase
        .from('stock_movements')
        .select('id, movement_type, quantity, unit, reason, cargo_id, created_at, ingredients(name)')
        .order('created_at', { ascending: false })
        .limit(150);
      if (error) {
        console.error('movements load failed', error);
        setFailed(true);
        return;
      }
      setMovements((data ?? []) as unknown as Movement[]);
    })();
  }, []);

  const visible = (movements ?? []).filter((m) =>
    filter === 'all' ? true : filter === 'production' ? !!m.cargo_id : !m.cargo_id
  );

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90vh] max-w-xl overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            Historique du stock
          </DialogTitle>
          <DialogDescription>
            Les barquettes scannées en production retirent automatiquement les ingrédients de leur recette.
          </DialogDescription>
        </DialogHeader>

        <div className="inline-flex w-fit rounded-lg bg-muted p-1">
          {([
            ['all', 'Tout'],
            ['production', 'Production'],
            ['manual', 'Manuel'],
          ] as const).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setFilter(id)}
              className={cn(
                'rounded-md px-3 py-1 text-sm font-medium transition-all',
                filter === id ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="-mx-6 max-h-[60vh] overflow-y-auto px-6">
          {failed ? (
            <p className="py-10 text-center text-sm text-muted-foreground">Impossible de charger l’historique.</p>
          ) : !movements ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : visible.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">Aucun mouvement pour le moment.</p>
          ) : (
            <ul className="divide-y">
              {visible.map((m) => {
                const qty = Number(m.quantity);
                const isIn = qty > 0;
                const Icon = m.cargo_id
                  ? ChefHat
                  : m.movement_type === 'loss'
                    ? Trash2
                    : m.movement_type === 'adjustment'
                      ? SlidersHorizontal
                      : isIn
                        ? ArrowUpRight
                        : ArrowDownRight;
                return (
                  <li key={m.id} className="flex items-center gap-3 py-2.5">
                    <div
                      className={cn(
                        'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg',
                        isIn ? 'bg-emerald-50 text-emerald-700' : m.cargo_id ? 'bg-sky-50 text-sky-700' : 'bg-amber-50 text-amber-700'
                      )}
                    >
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{m.ingredients?.name ?? 'Aliment'}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {m.reason ?? '—'} ·{' '}
                        {new Date(m.created_at).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                    <span className={cn('text-sm font-semibold tabular-nums', isIn ? 'text-emerald-700' : 'text-foreground')}>
                      {isIn ? '+' : ''}
                      {fmt(qty)} {m.unit}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
