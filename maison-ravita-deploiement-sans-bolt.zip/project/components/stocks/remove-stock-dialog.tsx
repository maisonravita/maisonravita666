'use client';

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, PackageMinus } from 'lucide-react';
import { supabase, type Ingredient } from '@/lib/supabase';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const TYPES = [
  { id: 'out', label: 'Utilisé en cuisine' },
  { id: 'loss', label: 'Perte / jeté' },
  { id: 'adjustment', label: 'Correction inventaire' },
] as const;

type Props = {
  ingredient: Ingredient;
  available: number;
  onClose: () => void;
  onDone: () => void;
};

export function RemoveStockDialog({ ingredient, available, onClose, onDone }: Props) {
  const [type, setType] = useState<(typeof TYPES)[number]['id']>('out');
  const [quantity, setQuantity] = useState('');
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const qty = parseFloat(quantity.replace(',', '.'));
    if (!qty || qty <= 0) return setError('La quantité doit être supérieure à zéro.');
    if (qty > available + 1e-9) return setError(`Il n’y a que ${available} ${ingredient.unit} en stock.`);

    setSaving(true);
    const { error: rpcError } = await supabase.rpc('remove_stock', {
      p_ingredient_id: ingredient.id,
      p_quantity: qty,
      p_type: type,
      p_reason: reason || TYPES.find((t) => t.id === type)?.label,
    });
    if (rpcError) {
      console.error('remove stock failed', rpcError);
      setError(
        rpcError.message.includes('insufficient_stock')
          ? 'Quantité supérieure au stock disponible.'
          : rpcError.message.includes('not_authorized')
            ? 'Seuls l’administrateur et le cuisinier peuvent modifier le stock.'
            : 'L’enregistrement a échoué. Réessayez.'
      );
      setSaving(false);
      return;
    }
    toast({ title: 'Stock mis à jour', description: `-${qty} ${ingredient.unit} de ${ingredient.name}` });
    onDone();
  };

  return (
    <Dialog open onOpenChange={(o) => !o && !saving && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PackageMinus className="h-5 w-5 text-primary" />
            Sortie de stock
          </DialogTitle>
          <DialogDescription>
            {ingredient.name} · {available} {ingredient.unit} disponibles. Les lots qui expirent en premier sont utilisés d’abord.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-3 gap-2">
            {TYPES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setType(t.id)}
                className={cn(
                  'rounded-lg border-2 px-2 py-2 text-xs font-medium transition-colors',
                  type === t.id ? 'border-primary bg-primary/5 text-primary' : 'border-border hover:border-primary/40'
                )}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="out-qty">Quantité</Label>
            <div className="relative">
              <Input
                id="out-qty"
                autoFocus
                inputMode="decimal"
                placeholder="0"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="pr-20 text-lg font-semibold"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">{ingredient.unit}</span>
            </div>
            <button type="button" className="text-xs text-primary hover:underline" onClick={() => setQuantity(String(available))}>
              Tout retirer
            </button>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="out-reason" className="text-xs">Motif (optionnel)</Label>
            <Input id="out-reason" placeholder="ex : Production du midi" value={reason} onChange={(e) => setReason(e.target.value)} />
          </div>

          {error && <p className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={onClose} disabled={saving}>Annuler</Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Valider la sortie
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
