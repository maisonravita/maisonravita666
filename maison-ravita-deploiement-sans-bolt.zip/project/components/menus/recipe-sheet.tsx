'use client';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, AlertCircle, ShieldAlert } from 'lucide-react';
import { ISSUE_LABELS } from '@/lib/diet';
import { cn } from '@/lib/utils';
import type { PlanningData, RecipeWithLines } from '@/lib/menu-planning';

type Props = {
  recipe: RecipeWithLines | null;
  portions: number;
  data: PlanningData;
  onClose: () => void;
};

const fmtQty = (n: number) => (n >= 10 ? n.toFixed(0) : n.toFixed(2).replace(/\.?0+$/, ''));

export function RecipeSheet({ recipe, portions, data, onClose }: Props) {
  if (!recipe) return null;
  const share = Math.min(100, (recipe.cost / data.budget) * 100);
  const missingCount = recipe.lines.filter(
    (l) => (data.stock.get(l.ingredient_id) ?? 0) < l.qty * portions
  ).length;

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">{recipe.name}</DialogTitle>
          <DialogDescription>{recipe.description}</DialogDescription>
        </DialogHeader>

        {recipe.diet.length > 0 && (
          <div className="flex gap-2 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800">
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
            <div>
              <p className="font-semibold">Ne respecte pas les restrictions alimentaires</p>
              <ul className="mt-1 space-y-0.5">
                {recipe.diet.map((i) => (
                  <li key={`${i.kind}-${i.ingredient}`}>
                    {i.ingredient} : {ISSUE_LABELS[i.kind]}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-xl bg-muted/50 p-3">
            <p className="text-xs text-muted-foreground">Coût / portion</p>
            <p className="font-bold">{recipe.cost.toFixed(2)} €</p>
          </div>
          <div className="rounded-xl bg-muted/50 p-3">
            <p className="text-xs text-muted-foreground">Préparation</p>
            <p className="font-bold">{recipe.prep_time_minutes} min</p>
          </div>
          <div className="rounded-xl bg-muted/50 p-3">
            <p className="text-xs text-muted-foreground">Cuisson</p>
            <p className="font-bold">{recipe.cook_time_minutes} min</p>
          </div>
        </div>

        <div>
          <div className="mb-1 flex justify-between text-xs text-muted-foreground">
            <span>Part du budget barquette</span>
            <span>{share.toFixed(0)} % de {data.budget.toFixed(2)} €</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-muted">
            <div
              className={cn('h-full rounded-full transition-all', share > 95 ? 'bg-amber-500' : 'bg-primary')}
              style={{ width: `${share}%` }}
            />
          </div>
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <p className="text-sm font-semibold">Ingrédients pour {portions} portions</p>
            {recipe.lines.length > 0 && (
              <Badge variant="outline" className={missingCount ? 'border-amber-300 text-amber-700' : 'border-emerald-300 text-emerald-700'}>
                {missingCount ? `${missingCount} à acheter` : 'Tout en stock'}
              </Badge>
            )}
          </div>
          <div className="divide-y rounded-xl border">
            {recipe.lines.map((l) => {
              const ing = data.ingredients.get(l.ingredient_id);
              const needed = l.qty * portions;
              const available = data.stock.get(l.ingredient_id) ?? 0;
              const ok = available >= needed;
              return (
                <div key={l.ingredient_id} className="flex items-center gap-3 px-3 py-2 text-sm">
                  {ok ? (
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
                  ) : (
                    <AlertCircle className="h-4 w-4 shrink-0 text-amber-600" />
                  )}
                  <span className="flex-1 truncate">{ing?.name ?? 'Ingrédient'}</span>
                  <span className="font-medium tabular-nums">
                    {fmtQty(needed)} {ing?.unit}
                  </span>
                  <span className={cn('w-24 text-right text-xs tabular-nums', ok ? 'text-muted-foreground' : 'text-amber-700')}>
                    {ok ? `stock ${fmtQty(available)}` : `manque ${fmtQty(needed - available)}`}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div>
          <p className="mb-2 text-sm font-semibold">Étapes</p>
          <ol className="space-y-2">
            {recipe.steps.map((step, i) => (
              <li key={i} className="flex gap-3 text-sm leading-relaxed">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                  {i + 1}
                </span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </div>

        {recipe.allergens.length > 0 && (
          <div>
            <p className="mb-1 text-sm font-semibold">Allergènes</p>
            <div className="flex flex-wrap gap-1">
              {recipe.allergens.map((a) => (
                <Badge key={a} variant="outline">{a}</Badge>
              ))}
            </div>
          </div>
        )}

        {recipe.conservation && (
          <div>
            <p className="mb-1 text-sm font-semibold">Conservation</p>
            <p className="text-sm text-muted-foreground">{recipe.conservation}</p>
          </div>
        )}

        <div className="grid grid-cols-3 gap-2 border-t pt-3 text-center">
          {[120, 260, portions].map((n, i) => (
            <div key={i}>
              <p className="text-xs text-muted-foreground">Pour {n}</p>
              <p className="font-bold">{(recipe.cost * n).toFixed(2)} €</p>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
