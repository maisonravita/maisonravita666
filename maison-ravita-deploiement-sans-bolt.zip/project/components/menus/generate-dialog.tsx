'use client';

import { useMemo, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { AlertTriangle, Boxes, Check, Loader2, ShieldCheck, Sparkles, Wand2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { GenerationMode } from '@/lib/menu-generator';
import type { PlanningData } from '@/lib/menu-planning';
import { DIET_OPTIONS, dietIssues, type DietRestriction } from '@/lib/diet';

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: (mode: GenerationMode, replaceDrafts: boolean, restrictions: DietRestriction[]) => void;
  generating: boolean;
  planning: PlanningData;
  stockedIngredients: number;
};

const MODES: Array<{ id: GenerationMode; title: string; text: string; icon: typeof Boxes }> = [
  {
    id: 'stock',
    title: 'Selon le stock',
    text: 'Priorité aux plats réalisables avec ce qui est déjà en réserve, pour limiter les achats et le gaspillage.',
    icon: Boxes,
  },
  {
    id: 'libre',
    title: 'Choix libre',
    text: 'L’application compose une semaine variée parmi toutes les recettes, sans tenir compte du stock.',
    icon: Wand2,
  },
];

export function GenerateDialog({
  open,
  onOpenChange,
  onConfirm,
  generating,
  planning,
  stockedIngredients,
}: Props) {
  const { budget } = planning;
  const totalIngredients = planning.ingredients.size;
  const [mode, setMode] = useState<GenerationMode>(stockedIngredients > 0 ? 'stock' : 'libre');
  const [replaceDrafts, setReplaceDrafts] = useState(true);
  const [restrictions, setRestrictions] = useState<DietRestriction[]>(planning.restrictions);

  const toggleRestriction = (id: DietRestriction) =>
    setRestrictions((prev) => (prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]));

  const compat = useMemo(() => {
    const candidates = planning.recipes.filter(
      (r) => r.status === 'validated' && r.lines.length > 0 && r.cost <= budget
    );
    const issues = candidates.map((r) => dietIssues(r.lines, planning.ingredients, restrictions));
    const nonHalalMeats = new Set(
      issues.flat().filter((i) => i.kind === 'non_halal').map((i) => i.ingredient)
    );
    return {
      total: candidates.length,
      ok: issues.filter((i) => i.length === 0).length,
      nonHalalMeats: Array.from(nonHalalMeats),
    };
  }, [planning, budget, restrictions]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Générer la semaine</DialogTitle>
          <DialogDescription>
            Chaque plat respecte le budget de {budget.toFixed(2)} € par barquette, calculé avec les prix actuels.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3">
          {MODES.map((m) => {
            const Icon = m.icon;
            const active = mode === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => setMode(m.id)}
                className={cn(
                  'flex gap-3 rounded-xl border-2 p-4 text-left transition-all',
                  active ? 'border-primary bg-primary/5 shadow-sm' : 'border-border hover:border-primary/40'
                )}
              >
                <div
                  className={cn(
                    'flex h-10 w-10 shrink-0 items-center justify-center rounded-lg transition-colors',
                    active ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                  )}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-semibold">{m.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{m.text}</p>
                </div>
              </button>
            );
          })}
        </div>

        {mode === 'stock' && (
          <div
            className={cn(
              'flex gap-2 rounded-lg p-3 text-sm',
              stockedIngredients === 0 ? 'bg-amber-50 text-amber-900' : 'bg-emerald-50 text-emerald-900'
            )}
          >
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            {stockedIngredients === 0
              ? 'Le stock est vide : les plats seront choisis librement. Ajoutez des lots dans Stocks pour un menu basé sur la réserve.'
              : `${stockedIngredients} ingrédient(s) sur ${totalIngredients} disponibles en réserve.`}
          </div>
        )}

        <div className="space-y-2">
          <p className="flex items-center gap-1.5 text-sm font-semibold">
            <ShieldCheck className="h-4 w-4 text-primary" />
            Restrictions alimentaires
          </p>
          <div className="flex flex-wrap gap-2">
            {DIET_OPTIONS.map((o) => {
              const active = restrictions.includes(o.id);
              return (
                <button
                  key={o.id}
                  type="button"
                  title={o.hint}
                  onClick={() => toggleRestriction(o.id)}
                  className={cn(
                    'flex items-center gap-1 rounded-full border px-3 py-1.5 text-sm font-medium transition-all',
                    active
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-border text-muted-foreground hover:border-primary/40 hover:text-foreground'
                  )}
                >
                  {active && <Check className="h-3.5 w-3.5" />}
                  {o.label}
                </button>
              );
            })}
          </div>
          <p className={cn('text-xs', compat.ok === 0 ? 'text-destructive' : 'text-muted-foreground')}>
            {restrictions.length === 0
              ? 'Aucune restriction : toutes les recettes sous budget peuvent être proposées.'
              : `${compat.ok} recette(s) compatible(s) sur ${compat.total}.`}
          </p>
          {compat.nonHalalMeats.length > 0 && (
            <p className="rounded-lg bg-amber-50 p-2.5 text-xs leading-relaxed text-amber-900">
              Non certifiés halal : {compat.nonHalalMeats.join(', ')}. Si votre fournisseur les livre halal,
              cochez « Halal certifié » sur ces aliments dans Stocks pour débloquer leurs recettes.
            </p>
          )}
        </div>

        <div className="flex items-center justify-between rounded-lg bg-muted/50 p-3">
          <Label htmlFor="replace-drafts" className="text-sm leading-snug">
            Remplacer les brouillons existants
            <span className="block text-xs font-normal text-muted-foreground">
              Les plats déjà validés sont toujours conservés.
            </span>
          </Label>
          <Switch id="replace-drafts" checked={replaceDrafts} onCheckedChange={setReplaceDrafts} />
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={generating}>
            Annuler
          </Button>
          <Button onClick={() => onConfirm(mode, replaceDrafts, restrictions)} disabled={generating || compat.ok === 0}>
            {generating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
            Générer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
