'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { Loader2 } from 'lucide-react';

const roleHomePaths: Record<string, string> = {
  admin: '/dashboard',
  cook: '/dashboard/stocks',
  preparator: '/dashboard/production',
  driver: '/dashboard/livraisons',
  courier: '/dashboard/achats',
};

export function RoleRedirect() {
  const { profile, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && profile) {
      const path = roleHomePaths[profile.role] ?? '/dashboard';
      router.replace(path);
    }
  }, [profile, loading, router]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
    </div>
  );
}
