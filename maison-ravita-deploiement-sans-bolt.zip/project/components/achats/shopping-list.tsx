'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  CheckCircle2,
  ClipboardCopy,
  Loader2,
  RefreshCw,
  ShieldCheck,
  ShoppingBasket,
  Truck,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase, type Ingredient, type ShoppingItem } from '@/lib/supabase';
import { toast } from '@/hooks/use-toast';

export type ShoppingRow = ShoppingItem & { ingredients: Ingredient };

const GROUPS: Array<{ priority: ShoppingItem['priority']; title: string; hint: string; tone: string; dot: string }> = [
  { priority: 'high', title: 'Urgent', hint: 'Manque pour aujourd’hui ou demain', tone: 'text-red-700', dot: 'bg-red-500' },
  { priority: 'medium', title: 'À prévoir', hint: 'Manque pour les menus de la semaine', tone: 'text-amber-700', dot: 'bg-amber-500' },
  { priority: 'low', title: 'Réassort', hint: 'Remonter au-dessus du seuil d’alerte', tone: 'text-sky-700', dot: 'bg-sky-500' },
];

const HORIZONS = [3, 7, 14];

const fmt = (n: number) => (Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0+$/, ''));

type Props = {
  items: ShoppingRow[];
  canRecalculate: boolean;
  canBuy: boolean;
  horizon: number;
  onPurchased: (item: ShoppingRow) => Promise<void>;
  onRefreshed: () => void;
};

export function ShoppingList({ items, canRecalculate, canBuy, horizon, onPurchased, onRefreshed }: Props) {
  const [days, setDays] = useState(horizon);
  const [refreshing, setRefreshing] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  const total = items.reduce((s, i) => s + Number(i.estimated_price), 0);
  const halalCount = items.filter((i) => i.halal_required).length;

  const recalculate = async (d: number) => {
    setDays(d);
    setRefreshing(true);
    const { data, error } = await supabase.rpc('generate_shopping_list', { p_days: d });
    setRefreshing(false);
    if (error) {
      console.error('shopping list refresh failed', error);
      toast({ title: 'Mise à jour impossible', description: 'Réessayez dans un instant.', variant: 'destructive' });
      return;
    }
    const r = (data ?? {}) as { created?: number; removed?: number };
    toast({
      title: 'Liste de courses à jour',
      description: `${r.created ?? 0} ajout(s), ${r.removed ?? 0} retrait(s) pour les ${d} prochains jours.`,
    });
    onRefreshed();
  };

  const copyList = async () => {
    const lines = GROUPS.flatMap((g) => {
      const rows = items.filter((i) => i.priority === g.priority);
      if (rows.length === 0) return [];
      return [
        `${g.title.toUpperCase()}`,
        ...rows.map(
          (i) =>
            `- ${i.ingredients.name} : ${fmt(Number(i.quantity_needed))} ${i.unit}${i.halal_required ? ' (HALAL CERTIFIÉ)' : ''}`
        ),
        '',
      ];
    });
    try {
      await navigator.clipboard.writeText(`Liste de courses Maison Ravita\n\n${lines.join('\n')}`);
      toast({ title: 'Liste copiée', description: 'Vous pouvez la coller dans un message.' });
    } catch {
      toast({ title: 'Copie impossible', variant: 'destructive' });
    }
  };

  const buy = async (item: ShoppingRow) => {
    setBusyId(item.id);
    await onPurchased(item);
    setBusyId(null);
  };

  return (
    <section className="space-y-4">
      <Card className="overflow-hidden border-primary/20">
        <CardContent className="space-y-4 p-4 sm:p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex items-start gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <ShoppingBasket className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-semibold">Liste de courses automatique</h2>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  Calculée à partir des menus des {days} prochains jours, du stock réel et des seuils d’alerte.
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              {items.length > 0 && (
                <Button variant="outline" size="sm" onClick={copyList}>
                  <ClipboardCopy className="mr-1.5 h-4 w-4" />
                  Copier
                </Button>
              )}
              {canRecalculate && (
                <Button size="sm" onClick={() => recalculate(days)} disabled={refreshing}>
                  <RefreshCw className={cn('mr-1.5 h-4 w-4', refreshing && 'animate-spin')} />
                  Recalculer
                </Button>
              )}
            </div>
          </div>

          {canRecalculate && (
            <div className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">Anticiper</span>
              <div className="inline-flex rounded-lg bg-muted p-1">
                {HORIZONS.map((d) => (
                  <button
                    key={d}
                    disabled={refreshing}
                    onClick={() => recalculate(d)}
                    className={cn(
                      'rounded-md px-3 py-1 text-sm font-medium transition-all',
                      days === d ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
                    )}
                  >
                    {d} jours
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-xl bg-muted/50 p-3">
              <p className="text-xs text-muted-foreground">Produits</p>
              <p className="text-lg font-bold">{items.length}</p>
            </div>
            <div className="rounded-xl bg-muted/50 p-3">
              <p className="text-xs text-muted-foreground">Budget estimé</p>
              <p className="text-lg font-bold">{total.toFixed(2)} €</p>
            </div>
            <div className="rounded-xl bg-muted/50 p-3">
              <p className="text-xs text-muted-foreground">Halal requis</p>
              <p className={cn('text-lg font-bold', halalCount > 0 && 'text-emerald-700')}>{halalCount}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {items.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
            <CheckCircle2 className="h-10 w-10 text-emerald-600" />
            <p className="font-semibold">Rien à acheter pour l’instant</p>
            <p className="max-w-sm text-sm text-muted-foreground">
              Le stock couvre les menus prévus. Un produit apparaîtra ici dès qu’il viendra à manquer.
            </p>
          </CardContent>
        </Card>
      ) : (
        GROUPS.map((g) => {
          const rows = items.filter((i) => i.priority === g.priority);
          if (rows.length === 0) return null;
          return (
            <div key={g.priority} className="space-y-2">
              <div className="flex items-center gap-2">
                <span className={cn('h-2 w-2 rounded-full', g.dot)} />
                <h3 className={cn('text-sm font-semibold', g.tone)}>
                  {g.title} ({rows.length})
                </h3>
                <span className="text-xs text-muted-foreground">· {g.hint}</span>
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                {rows.map((item) => (
                  <Card key={item.id} className={cn('transition-shadow hover:shadow-md', item.halal_required && 'border-emerald-300')}>
                    <CardContent className="space-y-3 p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate font-semibold">{item.ingredients.name}</p>
                          <p className="text-sm">
                            <span className="text-lg font-bold tabular-nums">{fmt(Number(item.quantity_needed))}</span>{' '}
                            <span className="text-muted-foreground">{item.unit}</span>
                            <span className="ml-2 text-xs text-muted-foreground">≈ {Number(item.estimated_price).toFixed(2)} €</span>
                          </p>
                        </div>
                        {item.halal_required && (
                          <Badge className="shrink-0 gap-1 bg-emerald-600 hover:bg-emerald-600">
                            <ShieldCheck className="h-3 w-3" />
                            Halal certifié
                          </Badge>
                        )}
                      </div>
                      {item.reason && <p className="text-xs leading-relaxed text-muted-foreground">{item.reason}</p>}
                      {item.supplier && (
                        <p className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Truck className="h-3 w-3" /> {item.supplier}
                        </p>
                      )}
                      {canBuy && (
                        <Button size="sm" className="w-full" disabled={busyId === item.id} onClick={() => buy(item)}>
                          {busyId === item.id ? (
                            <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                          ) : (
                            <CheckCircle2 className="mr-1.5 h-4 w-4" />
                          )}
                          Marquer comme acheté
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          );
        })
      )}
    </section>
  );
}
