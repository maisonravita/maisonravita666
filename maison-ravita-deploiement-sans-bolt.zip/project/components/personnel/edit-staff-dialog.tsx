'use client';

import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, UserCog } from 'lucide-react';
import type { Profile, UserRole } from '@/lib/supabase';
import { roleLabels } from '@/lib/role-nav';
import { callRpc } from '@/lib/rpc';
import { toast } from '@/hooks/use-toast';

export function EditStaffDialog({
  member,
  isSelf,
  onClose,
  onSaved,
}: {
  member: Profile | null;
  isSelf: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState({ full_name: '', phone: '', role: 'preparator' as UserRole, active: true, hourly_rate: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!member) return;
    setForm({
      full_name: member.full_name,
      phone: member.phone ?? '',
      role: member.role,
      active: member.active,
      hourly_rate: member.hourly_rate != null ? String(member.hourly_rate) : '',
    });
    setError(null);
  }, [member]);

  const save = async () => {
    if (!member) return;
    if (form.full_name.trim().length < 2) {
      setError('Indiquez le nom complet.');
      return;
    }
    const rateText = form.hourly_rate.replace(',', '.').trim();
    const rate = rateText === '' ? null : Number(rateText);
    if (rate !== null && (!Number.isFinite(rate) || rate < 0 || rate > 500)) {
      setError('Le taux horaire doit être un nombre entre 0 et 500 €.');
      return;
    }
    setSaving(true);
    setError(null);
    const result = await callRpc('admin_update_staff', {
      p_user_id: member.id,
      p_full_name: form.full_name.trim(),
      p_role: form.role,
      p_active: form.active,
      p_phone: form.phone.trim(),
      p_hourly_rate: rate,
    });
    setSaving(false);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    toast({ title: 'Fiche mise à jour', description: form.full_name.trim() });
    onSaved();
    onClose();
  };

  return (
    <Dialog open={!!member} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserCog className="w-5 h-5 text-primary" />
            Modifier l&apos;employé
          </DialogTitle>
          <DialogDescription>{member?.email}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="edit-name">Nom complet</Label>
            <Input id="edit-name" value={form.full_name} maxLength={120}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="edit-phone">Téléphone</Label>
              <Input id="edit-phone" value={form.phone} maxLength={30}
                onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-rate">Taux horaire (€)</Label>
              <Input id="edit-rate" inputMode="decimal" value={form.hourly_rate}
                onChange={(e) => setForm({ ...form, hourly_rate: e.target.value })} placeholder="12,50" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Rôle</Label>
            <Select value={form.role} disabled={isSelf}
              onValueChange={(v) => setForm({ ...form, role: v as UserRole })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(roleLabels).map(([key, label]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between rounded-xl border p-3">
            <div>
              <p className="text-sm font-medium">Compte actif</p>
              <p className="text-xs text-muted-foreground">
                {isSelf ? 'Vous ne pouvez pas désactiver votre propre compte.' : 'Un compte inactif ne peut plus rien consulter.'}
              </p>
            </div>
            <Switch checked={form.active} disabled={isSelf}
              onCheckedChange={(checked) => setForm({ ...form, active: checked })} />
          </div>
          {error && <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2">{error}</p>}
        </div>
        <DialogFooter>
          <Button className="w-full h-11" onClick={save} disabled={saving}>
            {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Enregistrer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
