'use client';

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Check, Copy, Loader2, RefreshCw, UserPlus } from 'lucide-react';
import { supabase, type UserRole } from '@/lib/supabase';
import { roleLabels } from '@/lib/role-nav';
import { failMessage } from '@/lib/rpc';

const EMPTY = { full_name: '', email: '', phone: '', role: 'preparator' as UserRole, password: '' };

function generatePassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  const values = new Uint32Array(10);
  crypto.getRandomValues(values);
  return Array.from(values, (v) => chars[v % chars.length]).join('');
}

export function AddStaffDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => void;
}) {
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<{ email: string; password: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const reset = () => {
    setForm({ ...EMPTY, password: generatePassword() });
    setError(null);
    setCreated(null);
    setCopied(false);
  };

  const handleOpenChange = (next: boolean) => {
    if (next) reset();
    onOpenChange(next);
  };

  const validate = () => {
    if (form.full_name.trim().length < 2) return 'Indiquez le nom complet.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) return 'Adresse e-mail invalide.';
    if (form.password.length < 8) return 'Le mot de passe doit contenir au moins 8 caractères.';
    return null;
  };

  const submit = async () => {
    const invalid = validate();
    if (invalid) {
      setError(invalid);
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      if (!token) {
        setError('Session expirée. Reconnectez-vous.');
        return;
      }
      const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/create-staff`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string,
        },
        body: JSON.stringify({
          full_name: form.full_name.trim(),
          email: form.email.trim(),
          phone: form.phone.trim(),
          role: form.role,
          password: form.password,
        }),
      });
      const body = await response.json().catch(() => null);
      if (!response.ok || body?.status !== 'ok') {
        setError(typeof body?.message === 'string' ? body.message : failMessage(body));
        return;
      }
      setCreated({ email: form.email.trim().toLowerCase(), password: form.password });
      onCreated();
    } catch (e) {
      setError(failMessage(e));
    } finally {
      setSaving(false);
    }
  };

  const copyCredentials = async () => {
    if (!created) return;
    try {
      await navigator.clipboard.writeText(`Identifiant : ${created.email}\nMot de passe : ${created.password}`);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        {created ? (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Check className="w-5 h-5 text-emerald-600" />
                Compte créé
              </DialogTitle>
              <DialogDescription>
                Transmettez ces identifiants à l&apos;employé. Il pourra se connecter immédiatement.
              </DialogDescription>
            </DialogHeader>
            <div className="rounded-xl border bg-muted/40 p-4 space-y-2 text-sm">
              <p><span className="text-muted-foreground">Identifiant :</span> <span className="font-medium">{created.email}</span></p>
              <p><span className="text-muted-foreground">Mot de passe :</span> <span className="font-mono font-medium">{created.password}</span></p>
            </div>
            <DialogFooter className="gap-2 sm:gap-0">
              <Button variant="outline" onClick={copyCredentials}>
                {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                {copied ? 'Copié' : 'Copier'}
              </Button>
              <Button onClick={() => onOpenChange(false)}>Terminer</Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-primary" />
                Nouvel employé
              </DialogTitle>
              <DialogDescription>Le compte est créé et activé directement avec le rôle choisi.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="staff-name">Nom complet</Label>
                <Input id="staff-name" value={form.full_name} maxLength={120}
                  onChange={(e) => setForm({ ...form, full_name: e.target.value })} placeholder="Jean Dupont" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="staff-email">E-mail (identifiant)</Label>
                <Input id="staff-email" type="email" value={form.email} maxLength={200}
                  onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="jean@maisonravita.fr" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="staff-phone">Téléphone</Label>
                  <Input id="staff-phone" value={form.phone} maxLength={30}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="06 12 34 56 78" />
                </div>
                <div className="space-y-2">
                  <Label>Rôle</Label>
                  <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v as UserRole })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(roleLabels).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="staff-password">Mot de passe provisoire</Label>
                <div className="flex gap-2">
                  <Input id="staff-password" value={form.password} maxLength={72} className="font-mono"
                    onChange={(e) => setForm({ ...form, password: e.target.value })} />
                  <Button type="button" variant="outline" size="icon" aria-label="Générer un mot de passe"
                    onClick={() => setForm({ ...form, password: generatePassword() })}>
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              {error && (
                <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2">{error}</p>
              )}
            </div>
            <DialogFooter>
              <Button className="w-full h-11" onClick={submit} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Créer le compte
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
