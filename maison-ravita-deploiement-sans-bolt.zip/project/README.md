# Maison Ravita — Application de gestion de restauration collective

Application web professionnelle de gestion de restauration collective, optimisée pour smartphone, avec authentification sécurisée, base de données Supabase, scanner QR caméra, suivi des cargos, livraisons, stocks, achats et finances.

## Technologies

- Next.js 13 (App Router) + TypeScript
- Tailwind CSS + shadcn/ui
- Supabase (PostgreSQL, Auth, RLS, Storage)
- jsqr (scanner QR caméra)
- lucide-react (icônes)
- PWA installable

## Rôles utilisateurs

1. **Administrateur** — Accès complet : dashboard, menus, stocks, achats, cargos, livraisons, personnel, finances, paramètres
2. **Cuisinier** — Check-in, hygiène, recettes validées, stocks, réception des marchandises, signalements
3. **Préparateur** — Check-in, hygiène, choix site/service, scanner QR caméra, compteur personnel, cargos, photos
4. **Livreur** — Check-in, cargos disponibles, chargement, tournées, livraison avec preuve photo, signalements
5. **Coursier** — Liste de courses, déclaration d'achats, photos de tickets, substitutions

## Installation

```bash
npm install
npm run dev
```

## Variables d'environnement

Les variables Supabase sont pré-configurées dans `.env` :
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## Build

```bash
npm run build
```

## Fonctionnalités implémentées

### Phase 1 — Fondations
- Authentification email/mot de passe (Supabase Auth)
- Profils utilisateurs avec rôles (admin, cook, preparator, driver, courier)
- Navigation adaptative : barre latérale (desktop) + barre inférieure (mobile)
- Tableau de bord administrateur avec KPIs en temps réel
- Compteur total de barquettes (atomique, côté serveur)
- Sécurité RLS sur toutes les tables
- Design system vert émeraude, responsive mobile-first

### Phase 2 — Menus et cuisine
- Génération automatique de 14 repas par semaine (7 jours x 2 services)
- 8 recettes sample avec coûts calculés (< 1,50€/portion)
- Calendrier hebdomadaire navigable
- Validation des menus par l'administrateur
- Régénération de plats individuels
- Fiches techniques détaillées (ingrédients, étapes, allergènes, coûts par 120/260/380)
- Gestion des stocks avec seuils d'alerte
- Ajustements d'inventaire (rôle cook/admin)

### Phase 3 — Préparation et cargos
- Parcours préparateur : check-in → hygiène → choix site → choix service → préparation
- Scanner QR caméra (jsqr) avec détection des doublons
- Saisie manuelle de secours
- Compteur personnel toujours visible
- Fonction `process_scan()` atomique côté base de données :
  - Vérifie l'unicité du QR code
  - Vérifie la cohérence site/service/cargo
  - Crée le meal_unit
  - Incrémente le compteur du cargo
  - Incrémente le compteur global
  - Journalise le scan (succès ou échec)
- Gestion des cargos (création, fermeture, statuts)
- Photos de livraison

### Phase 4 — Livraisons
- Parcours livreur : check-in → cargos disponibles → chargement → tournée → livraison
- Sélection multiple de cargos à charger
- Démarrage de tournée
- Confirmation de livraison avec photo obligatoire
- Signalement d'incidents (retard, dommages, etc.)
- Fin de tournée

### Phase 5 — Achats et finances
- Liste de courses automatique
- Déclaration d'achats avec photo de ticket
- Suivi des substitutions
- Factures fournisseurs (validation/rejet)
- Factures clients par site
- Tableau de bord financier

### Phase 6 — Personnel
- Liste du personnel avec rôles
- Modification des rôles (admin uniquement)
- Paramètres configurables (budget, capacités, TVA)

## Sécurité

- **Row Level Security** activée sur toutes les tables
- Fonctions `is_admin()` et `get_my_role()` (SECURITY DEFINER) pour les politiques
- Rôles stockés dans `profiles`, non modifiables par l'utilisateur
- Scans QR transactionnels via `process_scan()` — empêche les doublons même avec plusieurs appareils
- Compteur global atomique via `increment_total_counter()`
- Journal d'audit des actions administratives

## Base de données

21 tables créées via 6 migrations Supabase :
- profiles, sites, settings
- ingredients, stock_lots, stock_movements
- recipes, recipe_ingredients, menus
- cargos, meal_units, scan_events, total_counter
- employee_checkins, hygiene_checklists
- requests, notifications
- shopping_items, purchases, supplier_invoices
- delivery_routes, gps_positions, delivery_proofs, incidents
- customer_invoices, audit_logs, staff_schedules, budget_exceptions, payroll_records

## Données de test

- 2 sites (Site 1: 120 personnes, Site 2: 260 personnes)
- 30 ingrédients avec prix et fournisseurs
- 8 recettes validées avec coûts < 1,50€/portion
- Paramètres : budget 1,50€/barquette, 380 barquettes/service, capacité cargo 50

## PWA

L'application est installable sur iPhone et Android via le manifest.json.
Meta viewport et theme-color configurés pour une expérience native.
