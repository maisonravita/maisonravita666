/*
# Maison Ravita — Seed Data

Inserts initial configuration data:
1. Sites: Site 1 (120 people) and Site 2 (260 people)
2. Settings: budget per barquette (1.50€), production targets, cargo capacity
3. Sample ingredients with prices and alert thresholds
4. Sample validated recipes with ingredients and costs under 1.50€/portion
5. Total counter initialized to 0

All data is clearly identified as test/demo data.
*/

-- SITES
INSERT INTO sites (name, capacity, address) VALUES
  ('Site 1', 120, '12 Rue des Lilas, Lyon'),
  ('Site 2', 260, '45 Avenue du Parc, Lyon')
ON CONFLICT DO NOTHING;

-- SETTINGS
INSERT INTO settings (key, value, description) VALUES
  ('budget_per_barquette', '1.50', 'Coût maximum des ingrédients par barquette en euros'),
  ('daily_production_midi', '380', 'Nombre de barquettes prévues au service du midi'),
  ('daily_production_soir', '380', 'Nombre de barquettes prévues au service du soir'),
  ('cargo_max_capacity', '50', 'Capacité maximale de barquettes par cargo'),
  ('tva_rate', '5.5', 'Taux de TVA applicable pour la restauration'),
  ('site1_capacity', '120', 'Nombre de personnes au Site 1'),
  ('site2_capacity', '260', 'Nombre de personnes au Site 2')
ON CONFLICT (key) DO NOTHING;

-- INGREDIENTS (sample data for testing)
INSERT INTO ingredients (name, category, unit, price, supplier, alert_threshold) VALUES
  ('Riz basmati', 'feculents', 'kg', 1.80, 'Métro Cash', 10),
  ('Poulet fermier', 'viandes', 'kg', 8.50, 'Prieur Frais', 5),
  ('Boeuf haché', 'viandes', 'kg', 9.20, 'Prieur Frais', 5),
  ('Pommes de terre', 'legumes', 'kg', 1.20, 'Marché Gros', 20),
  ('Carottes', 'legumes', 'kg', 1.10, 'Marché Gros', 10),
  ('Oignons', 'legumes', 'kg', 1.30, 'Marché Gros', 10),
  ('Tomates', 'legumes', 'kg', 2.40, 'Marché Gros', 10),
  ('Pâtes penne', 'feculents', 'kg', 1.50, 'Métro Cash', 15),
  ('Sauce tomate', 'sauces', 'kg', 2.10, 'Métro Cash', 8),
  ('Crème fraîche', 'produits_laitiers', 'L', 2.80, 'Prieur Frais', 5),
  ('Fromage râpé', 'produits_laitiers', 'kg', 7.50, 'Prieur Frais', 3),
  ('Lardons', 'viandes', 'kg', 8.90, 'Prieur Frais', 3),
  ('Saumon frais', 'poissons', 'kg', 14.00, 'Pêche Fraîche', 4),
  ('Courgettes', 'legumes', 'kg', 1.80, 'Marché Gros', 8),
  ('Aubergines', 'legumes', 'kg', 2.00, 'Marché Gros', 8),
  ('Huile olive', 'huiles', 'L', 6.50, 'Métro Cash', 3),
  ('Ail', 'legumes', 'kg', 4.50, 'Marché Gros', 2),
  ('Persil', 'herbes', 'botte', 0.80, 'Marché Gros', 5),
  ('Laitue', 'legumes', 'pièce', 0.90, 'Marché Gros', 10),
  ('Pain', 'boulangerie', 'baguette', 0.90, 'Boulangerie Martin', 20),
  ('Farine', 'feculents', 'kg', 0.80, 'Métro Cash', 20),
  ('Oeufs', 'produits_laitiers', 'douzaine', 3.20, 'Prieur Frais', 5),
  ('Beurre', 'produits_laitiers', 'kg', 7.80, 'Prieur Frais', 3),
  ('Lait', 'produits_laitiers', 'L', 1.10, 'Prieur Frais', 10),
  ('Jambon blanc', 'viandes', 'kg', 10.50, 'Prieur Frais', 3),
  ('Emmental', 'produits_laitiers', 'kg', 8.20, 'Prieur Frais', 3),
  ('Poireaux', 'legumes', 'kg', 1.60, 'Marché Gros', 8),
  ('Champignons de Paris', 'legumes', 'kg', 3.50, 'Marché Gros', 5),
  ('Epinards', 'legumes', 'kg', 2.80, 'Marché Gros', 5),
  ('Semoule', 'feculents', 'kg', 1.40, 'Métro Cash', 10)
ON CONFLICT DO NOTHING;

-- TOTAL COUNTER init
INSERT INTO total_counter (id, count) VALUES (1, 0)
ON CONFLICT DO NOTHING;
