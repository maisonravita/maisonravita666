/*
# Maison Ravita — Schema Part 3: Cargos, Meal Units, Scans, Counter

## Tables
1. cargos — Cargo containers for barquettes with QR code and status tracking
2. meal_units — Individual barquettes with unique QR codes
3. scan_events — QR scan audit trail (successes and failures)
4. total_counter — Global barquette counter (single row, atomically updated)

## Functions
1. increment_total_counter() — Atomically increments and returns the global count
2. process_scan() — Atomic scan processing: prevents duplicates, verifies cargo,
   creates meal_unit, increments cargo count, logs scan event, increments global counter

## Security
- RLS on all tables
- Cargos: preparator creates, admin/preparator/driver update
- Meal units: only the scanning user creates
- Scan events: only the scanning user creates
- Total counter: read by all, written only via SECURITY DEFINER function

## Idempotency
- meal_units.qr_code has UNIQUE constraint — duplicate scans are rejected at DB level
- process_scan() checks for existing QR code before inserting
- Scan events are always logged (success or failure) for audit trail
*/

-- CARGOS
CREATE TABLE IF NOT EXISTS cargos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  site_id uuid NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  service text NOT NULL CHECK (service IN ('midi', 'soir')),
  recipe_id uuid NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  preparator_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  meal_unit_count integer NOT NULL DEFAULT 0,
  max_capacity integer NOT NULL DEFAULT 50,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'loaded', 'in_delivery', 'delivered')),
  photo_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  loaded_at timestamptz,
  delivered_at timestamptz
);
ALTER TABLE cargos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_cargos" ON cargos;
CREATE POLICY "select_cargos" ON cargos FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_cargos" ON cargos;
CREATE POLICY "insert_cargos" ON cargos FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = preparator_id OR is_admin());

DROP POLICY IF EXISTS "update_cargos" ON cargos;
CREATE POLICY "update_cargos" ON cargos FOR UPDATE
  TO authenticated USING (get_my_role() IN ('admin', 'preparator', 'driver')) WITH CHECK (get_my_role() IN ('admin', 'preparator', 'driver'));

-- MEAL UNITS
CREATE TABLE IF NOT EXISTS meal_units (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  qr_code text UNIQUE NOT NULL,
  cargo_id uuid NOT NULL REFERENCES cargos(id) ON DELETE CASCADE,
  site_id uuid NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  service text NOT NULL CHECK (service IN ('midi', 'soir')),
  recipe_id uuid NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  scanned_at timestamptz NOT NULL DEFAULT now(),
  scanned_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE
);
ALTER TABLE meal_units ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_meal_units" ON meal_units;
CREATE POLICY "select_meal_units" ON meal_units FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_meal_units" ON meal_units;
CREATE POLICY "insert_meal_units" ON meal_units FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = scanned_by);

-- SCAN EVENTS
CREATE TABLE IF NOT EXISTS scan_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  qr_code text NOT NULL,
  meal_unit_id uuid REFERENCES meal_units(id) ON DELETE SET NULL,
  cargo_id uuid NOT NULL REFERENCES cargos(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  success boolean NOT NULL DEFAULT true,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE scan_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_scan_events" ON scan_events;
CREATE POLICY "select_scan_events" ON scan_events FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_scan_events" ON scan_events;
CREATE POLICY "insert_scan_events" ON scan_events FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- TOTAL COUNTER
CREATE TABLE IF NOT EXISTS total_counter (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  count bigint NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE total_counter ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_total_counter" ON total_counter;
CREATE POLICY "select_total_counter" ON total_counter FOR SELECT
  TO authenticated USING (true);

-- Atomic increment function
CREATE OR REPLACE FUNCTION increment_total_counter()
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_count bigint;
BEGIN
  INSERT INTO total_counter (id, count) VALUES (1, 1)
  ON CONFLICT (id) DO UPDATE
    SET count = total_counter.count + 1, updated_at = now()
    RETURNING count INTO new_count;
  RETURN new_count;
END;
$$;

-- Atomic scan processing function
CREATE OR REPLACE FUNCTION process_scan(
  p_qr_code text,
  p_cargo_id uuid,
  p_site_id uuid,
  p_service text,
  p_recipe_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  existing_unit meal_units%ROWTYPE;
  cargo_rec cargos%ROWTYPE;
  new_unit meal_units%ROWTYPE;
  new_count bigint;
BEGIN
  SELECT * INTO existing_unit FROM meal_units WHERE qr_code = p_qr_code;
  IF FOUND THEN
    INSERT INTO scan_events (qr_code, meal_unit_id, cargo_id, user_id, success, error_message)
    VALUES (p_qr_code, existing_unit.id, p_cargo_id, auth.uid(), false, 'Barquette déjà scannée');
    RETURN json_build_object('status', 'duplicate', 'message', 'Barquette déjà scannée');
  END IF;

  SELECT * INTO cargo_rec FROM cargos WHERE id = p_cargo_id;
  IF NOT FOUND THEN
    INSERT INTO scan_events (qr_code, cargo_id, user_id, success, error_message)
    VALUES (p_qr_code, p_cargo_id, auth.uid(), false, 'Cargo introuvable');
    RETURN json_build_object('status', 'error', 'message', 'Cargo introuvable');
  END IF;

  IF cargo_rec.status != 'open' THEN
    INSERT INTO scan_events (qr_code, cargo_id, user_id, success, error_message)
    VALUES (p_qr_code, p_cargo_id, auth.uid(), false, 'Cargo fermé');
    RETURN json_build_object('status', 'error', 'message', 'Cargo fermé');
  END IF;

  IF cargo_rec.site_id != p_site_id OR cargo_rec.service != p_service THEN
    INSERT INTO scan_events (qr_code, cargo_id, user_id, success, error_message)
    VALUES (p_qr_code, p_cargo_id, auth.uid(), false, 'Incohérence site/service');
    RETURN json_build_object('status', 'mismatch', 'message', 'Incohérence site/service');
  END IF;

  INSERT INTO meal_units (qr_code, cargo_id, site_id, service, recipe_id, scanned_by)
  VALUES (p_qr_code, p_cargo_id, p_site_id, p_service, p_recipe_id, auth.uid())
  RETURNING * INTO new_unit;

  UPDATE cargos SET meal_unit_count = meal_unit_count + 1 WHERE id = p_cargo_id;

  INSERT INTO scan_events (qr_code, meal_unit_id, cargo_id, user_id, success)
  VALUES (p_qr_code, new_unit.id, p_cargo_id, auth.uid(), true);

  SELECT increment_total_counter() INTO new_count;

  RETURN json_build_object(
    'status', 'ok',
    'meal_unit_id', new_unit.id,
    'cargo_count', cargo_rec.meal_unit_count + 1,
    'total_count', new_count
  );
END;
$$;

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_cargos_status ON cargos(status);
CREATE INDEX IF NOT EXISTS idx_cargos_site_service ON cargos(site_id, service);
CREATE INDEX IF NOT EXISTS idx_meal_units_qr ON meal_units(qr_code);
CREATE INDEX IF NOT EXISTS idx_meal_units_cargo ON meal_units(cargo_id);
CREATE INDEX IF NOT EXISTS idx_scan_events_qr ON scan_events(qr_code);
