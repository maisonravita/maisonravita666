/*
# Liens vers les fiches employés

1. Modified tables
- `requests.user_id` gains an extra foreign key to `profiles(id)` so the app can show who sent a request.
- `cargos.preparator_id` gains an extra foreign key to `profiles(id)` so the app can show who prepared a cargo
  (distinct from the existing `driver_id` link).

2. Security
- No policy change. Profile visibility is still governed by the existing `profiles` policies.

3. Notes
- Existing foreign keys to `auth.users` are kept; no data is modified.
*/

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'requests_user_profile_fkey') THEN
    ALTER TABLE requests ADD CONSTRAINT requests_user_profile_fkey
      FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'cargos_preparator_profile_fkey') THEN
    ALTER TABLE cargos ADD CONSTRAINT cargos_preparator_profile_fkey
      FOREIGN KEY (preparator_id) REFERENCES profiles(id);
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
