/*
# Maison Ravita — Schema Part 5: Delivery, Finance, Staff, Audit

## Tables
1. delivery_routes — Delivery routes assigned to drivers
2. gps_positions — GPS position updates during active routes
3. delivery_proofs — Delivery confirmation with photo and location
4. incidents — Delivery and transport incidents
5. customer_invoices — Customer billing invoices per site
6. audit_logs — Audit trail of administrative actions
7. staff_schedules — Weekly staff scheduling
8. budget_exceptions — Budget overrun authorization requests
9. payroll_records — Payroll records per employee per period
10. employee_checkins — Employee check-in/check-out with geolocation
11. hygiene_checklists — Daily hygiene confirmation checklists

## Security
- delivery_routes: all read, driver/admin create+update
- gps_positions: all read, driver creates
- delivery_proofs: all read, driver creates
- incidents: all read, driver creates
- customer_invoices: admin only
- audit_logs: admin read, all insert
- staff_schedules: self read, admin manage
- budget_exceptions: self read, admin update
- payroll_records: self read (non-admin), admin manage
- employee_checkins: self/admin read, self insert, self/admin update
- hygiene_checklists: self/admin read, self insert
*/

-- EMPLOYEE CHECKINS
CREATE TABLE IF NOT EXISTS employee_checkins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  check_in_at timestamptz NOT NULL DEFAULT now(),
  check_out_at timestamptz,
  latitude double precision,
  longitude double precision,
  location_verified boolean NOT NULL DEFAULT false
);
ALTER TABLE employee_checkins ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_checkins" ON employee_checkins;
CREATE POLICY "select_checkins" ON employee_checkins FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR is_admin());

DROP POLICY IF EXISTS "insert_checkins" ON employee_checkins;
CREATE POLICY "insert_checkins" ON employee_checkins FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_checkins" ON employee_checkins;
CREATE POLICY "update_checkins" ON employee_checkins FOR UPDATE
  TO authenticated USING (auth.uid() = user_id OR is_admin()) WITH CHECK (auth.uid() = user_id OR is_admin());

-- HYGIENE CHECKLISTS
CREATE TABLE IF NOT EXISTS hygiene_checklists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  items jsonb NOT NULL DEFAULT '{}',
  confirmed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE hygiene_checklists ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_hygiene" ON hygiene_checklists;
CREATE POLICY "select_hygiene" ON hygiene_checklists FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR is_admin());

DROP POLICY IF EXISTS "insert_hygiene" ON hygiene_checklists;
CREATE POLICY "insert_hygiene" ON hygiene_checklists FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- DELIVERY ROUTES
CREATE TABLE IF NOT EXISTS delivery_routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'planned' CHECK (status IN ('planned', 'active', 'completed', 'cancelled')),
  started_at timestamptz,
  completed_at timestamptz,
  cargo_ids uuid[] NOT NULL DEFAULT '{}'
);
ALTER TABLE delivery_routes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_routes" ON delivery_routes;
CREATE POLICY "select_routes" ON delivery_routes FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_routes" ON delivery_routes;
CREATE POLICY "insert_routes" ON delivery_routes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = driver_id OR is_admin());

DROP POLICY IF EXISTS "update_routes" ON delivery_routes;
CREATE POLICY "update_routes" ON delivery_routes FOR UPDATE
  TO authenticated USING (auth.uid() = driver_id OR is_admin()) WITH CHECK (auth.uid() = driver_id OR is_admin());

-- GPS POSITIONS
CREATE TABLE IF NOT EXISTS gps_positions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id uuid NOT NULL REFERENCES delivery_routes(id) ON DELETE CASCADE,
  driver_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE gps_positions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_gps" ON gps_positions;
CREATE POLICY "select_gps" ON gps_positions FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_gps" ON gps_positions;
CREATE POLICY "insert_gps" ON gps_positions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = driver_id);

-- DELIVERY PROOFS
CREATE TABLE IF NOT EXISTS delivery_proofs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cargo_id uuid NOT NULL REFERENCES cargos(id) ON DELETE CASCADE,
  route_id uuid REFERENCES delivery_routes(id) ON DELETE SET NULL,
  driver_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  site_id uuid NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  quantity_delivered integer NOT NULL,
  photo_url text NOT NULL,
  latitude double precision,
  longitude double precision,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE delivery_proofs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_proofs" ON delivery_proofs;
CREATE POLICY "select_proofs" ON delivery_proofs FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_proofs" ON delivery_proofs;
CREATE POLICY "insert_proofs" ON delivery_proofs FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = driver_id);

-- INCIDENTS
CREATE TABLE IF NOT EXISTS incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('delay', 'missing_cargo', 'damaged', 'wrong_destination', 'wrong_quantity', 'transport_incident', 'other')),
  description text NOT NULL,
  cargo_id uuid REFERENCES cargos(id) ON DELETE SET NULL,
  route_id uuid REFERENCES delivery_routes(id) ON DELETE SET NULL,
  driver_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE incidents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_incidents" ON incidents;
CREATE POLICY "select_incidents" ON incidents FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_incidents" ON incidents;
CREATE POLICY "insert_incidents" ON incidents FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = driver_id);

-- CUSTOMER INVOICES
CREATE TABLE IF NOT EXISTS customer_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_id uuid NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  period text NOT NULL,
  quantity_billable integer NOT NULL DEFAULT 0,
  unit_price numeric(10,2) NOT NULL DEFAULT 0,
  amount_ht numeric(10,2) NOT NULL DEFAULT 0,
  tva_rate numeric(5,2) NOT NULL DEFAULT 5.5,
  amount_ttc numeric(10,2) NOT NULL DEFAULT 0,
  due_date date,
  paid boolean NOT NULL DEFAULT false,
  paid_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE customer_invoices ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_customer_invoices" ON customer_invoices;
CREATE POLICY "select_customer_invoices" ON customer_invoices FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "admin_insert_customer_invoices" ON customer_invoices;
CREATE POLICY "admin_insert_customer_invoices" ON customer_invoices FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_customer_invoices" ON customer_invoices;
CREATE POLICY "admin_update_customer_invoices" ON customer_invoices FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- AUDIT LOGS
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  details jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_audit_logs" ON audit_logs;
CREATE POLICY "select_audit_logs" ON audit_logs FOR SELECT
  TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "insert_audit_logs" ON audit_logs;
CREATE POLICY "insert_audit_logs" ON audit_logs FOR INSERT
  TO authenticated WITH CHECK (true);

-- STAFF SCHEDULES
CREATE TABLE IF NOT EXISTS staff_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL,
  start_time time NOT NULL DEFAULT '08:00',
  end_time time NOT NULL DEFAULT '16:00',
  role text NOT NULL,
  published boolean NOT NULL DEFAULT false
);
ALTER TABLE staff_schedules ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_schedules" ON staff_schedules;
CREATE POLICY "select_schedules" ON staff_schedules FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR is_admin());

DROP POLICY IF EXISTS "admin_insert_schedules" ON staff_schedules;
CREATE POLICY "admin_insert_schedules" ON staff_schedules FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_schedules" ON staff_schedules;
CREATE POLICY "admin_update_schedules" ON staff_schedules FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_delete_schedules" ON staff_schedules;
CREATE POLICY "admin_delete_schedules" ON staff_schedules FOR DELETE
  TO authenticated USING (is_admin());

-- BUDGET EXCEPTIONS
CREATE TABLE IF NOT EXISTS budget_exceptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requested_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  amount numeric(10,2) NOT NULL,
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  approved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE budget_exceptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_budget_exceptions" ON budget_exceptions;
CREATE POLICY "select_budget_exceptions" ON budget_exceptions FOR SELECT
  TO authenticated USING (auth.uid() = requested_by OR is_admin());

DROP POLICY IF EXISTS "insert_budget_exceptions" ON budget_exceptions;
CREATE POLICY "insert_budget_exceptions" ON budget_exceptions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = requested_by);

DROP POLICY IF EXISTS "update_budget_exceptions" ON budget_exceptions;
CREATE POLICY "update_budget_exceptions" ON budget_exceptions FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- PAYROLL RECORDS
CREATE TABLE IF NOT EXISTS payroll_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  period text NOT NULL,
  base_salary numeric(10,2) NOT NULL DEFAULT 0,
  overtime_hours numeric(5,2) NOT NULL DEFAULT 0,
  overtime_pay numeric(10,2) NOT NULL DEFAULT 0,
  bonus numeric(10,2) NOT NULL DEFAULT 0,
  advance numeric(10,2) NOT NULL DEFAULT 0,
  total numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE payroll_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_payroll" ON payroll_records;
CREATE POLICY "select_payroll" ON payroll_records FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR is_admin());

DROP POLICY IF EXISTS "admin_insert_payroll" ON payroll_records;
CREATE POLICY "admin_insert_payroll" ON payroll_records FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_payroll" ON payroll_records;
CREATE POLICY "admin_update_payroll" ON payroll_records FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_checkins_user ON employee_checkins(user_id);
CREATE INDEX IF NOT EXISTS idx_delivery_routes_driver ON delivery_routes(driver_id);
CREATE INDEX IF NOT EXISTS idx_gps_route ON gps_positions(route_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
