/*
# Purchase reception and in-transit quantities

1. Modified Functions
- `refresh_shopping_item`: quantities already bought but not yet received ("en cours d'achat")
  are now subtracted from what needs to be bought, so a bought item is never re-added to the list.
2. New Functions
- `receive_purchase(p_purchase_id, p_expiry_date, p_lot_number)` (RPC, admin/cook only):
  atomically marks a bought purchase as received and adds its quantity to the stock
  (through `add_stock`, which records the movement and refreshes the shopping list).
3. Security
- Role is checked from the session; the claim is a single conditional UPDATE so a purchase
  cannot be received twice.
*/

CREATE OR REPLACE FUNCTION refresh_shopping_item(p_ingredient_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  ing ingredients%ROWTYPE;
  v_days int;
  v_halal boolean;
  v_need numeric;
  v_need_soon numeric;
  v_stock numeric;
  v_incoming numeric;
  v_to_buy numeric;
  v_priority text;
  v_reason text;
  v_existing uuid;
BEGIN
  SELECT * INTO ing FROM ingredients WHERE id = p_ingredient_id;
  IF NOT FOUND THEN RETURN 'none'; END IF;

  SELECT COALESCE(NULLIF(value, '')::int, 7) INTO v_days FROM settings WHERE key = 'shopping_horizon_days';
  v_days := LEAST(GREATEST(COALESCE(v_days, 7), 1), 31);
  SELECT COALESCE(value, '') LIKE '%halal%' INTO v_halal FROM settings WHERE key = 'diet_restrictions';

  SELECT
    COALESCE(sum(ri.quantity_per_portion * GREATEST(m.quantity - p.done, 0)), 0),
    COALESCE(sum(ri.quantity_per_portion * GREATEST(m.quantity - p.done, 0)) FILTER (WHERE m.date <= current_date + 1), 0)
  INTO v_need, v_need_soon
  FROM menus m
  JOIN recipe_ingredients ri ON ri.recipe_id = m.recipe_id AND ri.ingredient_id = p_ingredient_id
  CROSS JOIN LATERAL (
    SELECT count(*) AS done FROM meal_units mu
    WHERE mu.recipe_id = m.recipe_id AND mu.service = m.service
      AND mu.scanned_at >= m.date AND mu.scanned_at < m.date + 1
  ) p
  WHERE m.date BETWEEN current_date AND current_date + v_days - 1;

  SELECT COALESCE(sum(quantity), 0) INTO v_stock
  FROM stock_lots WHERE ingredient_id = p_ingredient_id AND quantity > 0;

  SELECT COALESCE(sum(quantity_bought), 0) INTO v_incoming
  FROM purchases WHERE ingredient_id = p_ingredient_id AND status = 'purchased';

  v_to_buy := ceil((v_need + COALESCE(ing.alert_threshold, 0) - v_stock - v_incoming) * 100) / 100;

  SELECT id INTO v_existing FROM shopping_items
  WHERE ingredient_id = p_ingredient_id AND status = 'pending';

  IF v_to_buy <= 0 THEN
    IF v_existing IS NOT NULL THEN
      DELETE FROM shopping_items WHERE id = v_existing
        AND NOT EXISTS (SELECT 1 FROM purchases WHERE shopping_item_id = v_existing);
      RETURN 'removed';
    END IF;
    RETURN 'none';
  END IF;

  v_priority := CASE
    WHEN v_stock + v_incoming < v_need_soon THEN 'high'
    WHEN v_stock + v_incoming < v_need THEN 'medium'
    ELSE 'low'
  END;

  v_reason := CASE
    WHEN v_need > 0 THEN 'Menus des ' || v_days || ' prochains jours : '
      || fmt_qty(v_need) || ' ' || ing.unit || ' nécessaires, ' || fmt_qty(v_stock) || ' en stock'
    WHEN v_stock <= 0 THEN 'Rupture de stock'
    ELSE 'Sous le seuil d''alerte (' || fmt_qty(ing.alert_threshold) || ' ' || ing.unit || ')'
  END;
  IF v_incoming > 0 THEN
    v_reason := v_reason || ', ' || fmt_qty(v_incoming) || ' déjà acheté(s) en attente de réception';
  END IF;

  INSERT INTO shopping_items (ingredient_id, quantity_needed, unit, priority, status, estimated_price, supplier, reason, halal_required)
  VALUES (p_ingredient_id, v_to_buy, ing.unit, v_priority, 'pending',
          round(v_to_buy * ing.price, 2), ing.supplier, v_reason,
          v_halal AND ing.category = 'viandes')
  ON CONFLICT (ingredient_id) WHERE status = 'pending'
  DO UPDATE SET quantity_needed = EXCLUDED.quantity_needed,
                priority = EXCLUDED.priority,
                estimated_price = EXCLUDED.estimated_price,
                reason = EXCLUDED.reason,
                halal_required = EXCLUDED.halal_required;

  RETURN CASE WHEN v_existing IS NULL THEN 'created' ELSE 'updated' END;
END;
$$;

REVOKE EXECUTE ON FUNCTION refresh_shopping_item(uuid) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION receive_purchase(p_purchase_id uuid, p_expiry_date date DEFAULT NULL, p_lot_number text DEFAULT NULL)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_purchase purchases%ROWTYPE;
BEGIN
  IF get_my_role() NOT IN ('admin', 'cook') THEN
    RAISE EXCEPTION 'not_authorized';
  END IF;

  UPDATE purchases SET status = 'received', received_at = now()
  WHERE id = p_purchase_id AND status = 'purchased'
  RETURNING * INTO v_purchase;

  IF v_purchase.id IS NULL THEN
    RAISE EXCEPTION 'already_received';
  END IF;

  IF v_purchase.shopping_item_id IS NOT NULL THEN
    UPDATE shopping_items SET status = 'received' WHERE id = v_purchase.shopping_item_id;
  END IF;

  PERFORM add_stock(v_purchase.ingredient_id, v_purchase.quantity_bought, NULLIF(trim(p_lot_number), ''), p_expiry_date, 'Réception d''achat');

  RETURN json_build_object('ingredient_id', v_purchase.ingredient_id, 'quantity', v_purchase.quantity_bought);
END;
$$;

REVOKE EXECUTE ON FUNCTION receive_purchase(uuid, date, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION receive_purchase(uuid, date, text) TO authenticated;
