/*
# Maison Ravita — Schema Part 4: Requests, Notifications, Shopping, Purchases, Invoices

## Tables
1. requests — Employee requests/anomalies (missing ingredients, equipment issues, etc.)
2. notifications — System notifications for users
3. shopping_items — Auto-generated shopping list items from menus
4. purchases — Actual purchases by couriers with receipt photos
5. supplier_invoices — Supplier invoices/receipts for accounting

## Security
- requests: owner creates, admin updates status
- notifications: owner or admin reads, admin or self inserts
- shopping_items: all read, admin creates, admin/courier update
- purchases: all read, courier creates, admin/cook/courier update
- supplier_invoices: all read, admin/courier create, admin update
*/

-- REQUESTS
CREATE TABLE IF NOT EXISTS requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('missing_ingredient', 'stock_shortage', 'damaged_product', 'equipment_issue', 'hygiene_issue', 'recipe_error', 'other')),
  category text NOT NULL,
  description text NOT NULL,
  quantity_missing numeric(10,2),
  urgency text NOT NULL DEFAULT 'medium' CHECK (urgency IN ('low', 'medium', 'high', 'critical')),
  photo_url text,
  service text CHECK (service IN ('midi', 'soir')),
  status text NOT NULL DEFAULT 'sent' CHECK (status IN ('sent', 'viewed', 'processing', 'resolved', 'rejected')),
  rejection_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_requests" ON requests;
CREATE POLICY "select_requests" ON requests FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR is_admin());

DROP POLICY IF EXISTS "insert_requests" ON requests;
CREATE POLICY "insert_requests" ON requests FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_requests" ON requests;
CREATE POLICY "update_requests" ON requests FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- NOTIFICATIONS
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL DEFAULT 'info',
  read boolean NOT NULL DEFAULT false,
  link text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_notifications" ON notifications;
CREATE POLICY "select_notifications" ON notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR (user_id IS NULL AND is_admin()));

DROP POLICY IF EXISTS "insert_notifications" ON notifications;
CREATE POLICY "insert_notifications" ON notifications FOR INSERT
  TO authenticated WITH CHECK (is_admin() OR auth.uid() = user_id);

DROP POLICY IF EXISTS "update_notifications" ON notifications;
CREATE POLICY "update_notifications" ON notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id OR is_admin()) WITH CHECK (auth.uid() = user_id OR is_admin());

-- SHOPPING ITEMS
CREATE TABLE IF NOT EXISTS shopping_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ingredient_id uuid NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  quantity_needed numeric(10,2) NOT NULL,
  unit text NOT NULL,
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'purchased', 'received', 'rejected')),
  estimated_price numeric(10,2) NOT NULL DEFAULT 0,
  supplier text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE shopping_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_shopping" ON shopping_items;
CREATE POLICY "select_shopping" ON shopping_items FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_shopping" ON shopping_items;
CREATE POLICY "admin_insert_shopping" ON shopping_items FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "update_shopping" ON shopping_items;
CREATE POLICY "update_shopping" ON shopping_items FOR UPDATE
  TO authenticated USING (get_my_role() IN ('admin', 'courier')) WITH CHECK (get_my_role() IN ('admin', 'courier'));

-- PURCHASES
CREATE TABLE IF NOT EXISTS purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shopping_item_id uuid REFERENCES shopping_items(id) ON DELETE SET NULL,
  ingredient_id uuid NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  quantity_bought numeric(10,2) NOT NULL,
  unit text NOT NULL,
  actual_price numeric(10,2) NOT NULL,
  receipt_photo_url text,
  substitution text,
  status text NOT NULL DEFAULT 'purchased' CHECK (status IN ('pending', 'purchased', 'received', 'rejected')),
  courier_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  received_at timestamptz
);
ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_purchases" ON purchases;
CREATE POLICY "select_purchases" ON purchases FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_purchases" ON purchases;
CREATE POLICY "insert_purchases" ON purchases FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = courier_id);

DROP POLICY IF EXISTS "update_purchases" ON purchases;
CREATE POLICY "update_purchases" ON purchases FOR UPDATE
  TO authenticated USING (get_my_role() IN ('admin', 'cook', 'courier')) WITH CHECK (get_my_role() IN ('admin', 'cook', 'courier'));

-- SUPPLIER INVOICES
CREATE TABLE IF NOT EXISTS supplier_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL DEFAULT 'alimentaire',
  supplier text,
  invoice_number text,
  invoice_date date,
  amount_ht numeric(10,2) NOT NULL DEFAULT 0,
  tva_rate numeric(5,2) NOT NULL DEFAULT 5.5,
  amount_ttc numeric(10,2) NOT NULL DEFAULT 0,
  document_url text,
  status text NOT NULL DEFAULT 'imported' CHECK (status IN ('imported', 'to_verify', 'validated', 'rejected')),
  purchase_id uuid REFERENCES purchases(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE supplier_invoices ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_invoices" ON supplier_invoices;
CREATE POLICY "select_invoices" ON supplier_invoices FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_invoices" ON supplier_invoices;
CREATE POLICY "insert_invoices" ON supplier_invoices FOR INSERT
  TO authenticated WITH CHECK (get_my_role() IN ('admin', 'courier'));

DROP POLICY IF EXISTS "update_invoices" ON supplier_invoices;
CREATE POLICY "update_invoices" ON supplier_invoices FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, read);
CREATE INDEX IF NOT EXISTS idx_purchases_status ON purchases(status);
