/*
# Automatic stock consumption from production

Every barquette scanned in production now automatically deducts its recipe's ingredients
from the stock.

1. Modified Tables
- `stock_movements`: new nullable column `cargo_id` linking a production movement to its cargo.
  One movement row per (ingredient, cargo) holds the cumulative quantity consumed by that cargo.
2. New Functions / Triggers
- `consume_stock_for_meal()` trigger AFTER INSERT on `meal_units`:
  computes total theoretical use for the cargo (barquettes x quantity per portion),
  rounds down to the stock precision (0.01), takes the difference from lots (earliest expiry first),
  updates the cargo's movement row, and notifies admins when an ingredient goes low or runs out.
  Small per-portion quantities are therefore never lost to rounding.
- `process_scan()` rewritten: uses the cargo's own recipe (not a client-supplied one),
  locks the cargo row during the scan, and has a fixed search_path.
3. Security
- EXECUTE on process_scan revoked from anon/public, granted to authenticated.
- The trigger function is not callable directly.
*/

ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS cargo_id uuid REFERENCES cargos(id) ON DELETE SET NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_stock_movements_cargo_ingredient
  ON stock_movements (ingredient_id, cargo_id) WHERE cargo_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_stock_movements_created ON stock_movements (created_at DESC);

CREATE OR REPLACE FUNCTION consume_stock_for_meal()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  ri record;
  lot record;
  v_units integer;
  v_code text;
  v_target numeric;
  v_already numeric;
  v_left numeric;
  v_take numeric;
  v_taken numeric;
  v_before numeric;
  v_after numeric;
BEGIN
  SELECT count(*) INTO v_units FROM meal_units WHERE cargo_id = NEW.cargo_id;
  SELECT code INTO v_code FROM cargos WHERE id = NEW.cargo_id;

  FOR ri IN
    SELECT r.ingredient_id, r.quantity_per_portion, i.name, i.unit, i.alert_threshold
    FROM recipe_ingredients r JOIN ingredients i ON i.id = r.ingredient_id
    WHERE r.recipe_id = NEW.recipe_id
  LOOP
    v_target := floor(v_units * ri.quantity_per_portion * 100) / 100;
    SELECT COALESCE(-quantity, 0) INTO v_already
      FROM stock_movements WHERE ingredient_id = ri.ingredient_id AND cargo_id = NEW.cargo_id;
    v_already := COALESCE(v_already, 0);
    v_left := v_target - v_already;
    CONTINUE WHEN v_left <= 0;

    SELECT COALESCE(sum(quantity), 0) INTO v_before
      FROM stock_lots WHERE ingredient_id = ri.ingredient_id AND quantity > 0;
    CONTINUE WHEN v_before <= 0;

    v_taken := 0;
    FOR lot IN
      SELECT id, quantity FROM stock_lots
      WHERE ingredient_id = ri.ingredient_id AND quantity > 0
      ORDER BY expiry_date NULLS LAST, received_at
      FOR UPDATE
    LOOP
      EXIT WHEN v_left <= 0;
      v_take := LEAST(lot.quantity, v_left);
      UPDATE stock_lots SET quantity = quantity - v_take WHERE id = lot.id;
      v_left := v_left - v_take;
      v_taken := v_taken + v_take;
    END LOOP;

    CONTINUE WHEN v_taken <= 0;

    INSERT INTO stock_movements (ingredient_id, movement_type, quantity, unit, reason, user_id, cargo_id)
    VALUES (ri.ingredient_id, 'out', -v_taken, ri.unit, 'Production — cargo ' || COALESCE(v_code, ''), NEW.scanned_by, NEW.cargo_id)
    ON CONFLICT (ingredient_id, cargo_id) WHERE cargo_id IS NOT NULL
    DO UPDATE SET quantity = stock_movements.quantity + EXCLUDED.quantity, created_at = now();

    v_after := v_before - v_taken;
    IF v_after <= 0 THEN
      INSERT INTO notifications (user_id, title, message, type, link)
      VALUES (NULL, 'Rupture de stock', ri.name || ' est épuisé suite à la production.', 'error', '/dashboard/stocks');
    ELSIF ri.alert_threshold > 0 AND v_before > ri.alert_threshold AND v_after <= ri.alert_threshold THEN
      INSERT INTO notifications (user_id, title, message, type, link)
      VALUES (NULL, 'Stock bas', ri.name || ' : il reste ' || trim(to_char(v_after, 'FM999999990.99')) || ' ' || ri.unit || '.', 'warning', '/dashboard/stocks');
    END IF;
  END LOOP;

  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION consume_stock_for_meal() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_consume_stock_for_meal ON meal_units;
CREATE TRIGGER trg_consume_stock_for_meal
  AFTER INSERT ON meal_units
  FOR EACH ROW EXECUTE FUNCTION consume_stock_for_meal();

CREATE OR REPLACE FUNCTION process_scan(
  p_qr_code text,
  p_cargo_id uuid,
  p_site_id uuid,
  p_service text,
  p_recipe_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  existing_unit meal_units%ROWTYPE;
  cargo_rec cargos%ROWTYPE;
  new_unit meal_units%ROWTYPE;
  new_count bigint;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN json_build_object('status', 'error', 'message', 'Non connecté');
  END IF;

  SELECT * INTO cargo_rec FROM cargos WHERE id = p_cargo_id FOR UPDATE;
  IF NOT FOUND THEN
    RETURN json_build_object('status', 'error', 'message', 'Cargo introuvable');
  END IF;

  SELECT * INTO existing_unit FROM meal_units WHERE qr_code = p_qr_code;
  IF FOUND THEN
    INSERT INTO scan_events (qr_code, meal_unit_id, cargo_id, user_id, success, error_message)
    VALUES (p_qr_code, existing_unit.id, p_cargo_id, auth.uid(), false, 'Barquette déjà scannée');
    RETURN json_build_object('status', 'duplicate', 'message', 'Barquette déjà scannée');
  END IF;

  IF cargo_rec.status != 'open' THEN
    INSERT INTO scan_events (qr_code, cargo_id, user_id, success, error_message)
    VALUES (p_qr_code, p_cargo_id, auth.uid(), false, 'Cargo fermé');
    RETURN json_build_object('status', 'error', 'message', 'Cargo fermé');
  END IF;

  IF cargo_rec.site_id != p_site_id OR cargo_rec.service != p_service THEN
    INSERT INTO scan_events (qr_code, cargo_id, user_id, success, error_message)
    VALUES (p_qr_code, p_cargo_id, auth.uid(), false, 'Incohérence site/service');
    RETURN json_build_object('status', 'mismatch', 'message', 'Incohérence site/service');
  END IF;

  INSERT INTO meal_units (qr_code, cargo_id, site_id, service, recipe_id, scanned_by)
  VALUES (p_qr_code, p_cargo_id, cargo_rec.site_id, cargo_rec.service, cargo_rec.recipe_id, auth.uid())
  RETURNING * INTO new_unit;

  UPDATE cargos SET meal_unit_count = meal_unit_count + 1 WHERE id = p_cargo_id;

  INSERT INTO scan_events (qr_code, meal_unit_id, cargo_id, user_id, success)
  VALUES (p_qr_code, new_unit.id, p_cargo_id, auth.uid(), true);

  SELECT increment_total_counter() INTO new_count;

  RETURN json_build_object(
    'status', 'ok',
    'meal_unit_id', new_unit.id,
    'cargo_count', cargo_rec.meal_unit_count + 1,
    'total_count', new_count
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION process_scan(text, uuid, uuid, text, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION process_scan(text, uuid, uuid, text, uuid) TO authenticated;
