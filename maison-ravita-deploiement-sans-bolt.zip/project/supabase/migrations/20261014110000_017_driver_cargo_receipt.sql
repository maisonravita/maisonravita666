-- Cargo reception is a distinct, audited operation before truck loading.
CREATE TABLE IF NOT EXISTS public.cargo_receipts (
  cargo_id uuid PRIMARY KEY REFERENCES public.cargos(id) ON DELETE RESTRICT,
  driver_id uuid NOT NULL REFERENCES auth.users(id),
  received_at timestamptz NOT NULL DEFAULT now(),
  count_checked boolean NOT NULL CHECK (count_checked),
  destination_checked boolean NOT NULL CHECK (destination_checked),
  condition_checked boolean NOT NULL CHECK (condition_checked)
);
ALTER TABLE public.cargo_receipts ENABLE ROW LEVEL SECURITY;
CREATE POLICY cargo_receipts_driver_read ON public.cargo_receipts FOR SELECT TO authenticated
USING (driver_id = auth.uid() OR public.get_my_role() = 'admin');

CREATE OR REPLACE FUNCTION public.receive_cargo(p_cargo_id uuid, p_count_checked boolean, p_destination_checked boolean, p_condition_checked boolean)
RETURNS json LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_cargo public.cargos%ROWTYPE;
BEGIN
  IF public.get_my_role() NOT IN ('driver','admin') THEN RAISE EXCEPTION 'not_authorized'; END IF;
  IF NOT (coalesce(p_count_checked,false) AND coalesce(p_destination_checked,false) AND coalesce(p_condition_checked,false)) THEN
    RETURN json_build_object('status','error','message','Complétez les trois vérifications avant réception');
  END IF;
  SELECT * INTO v_cargo FROM public.cargos WHERE id = p_cargo_id FOR UPDATE;
  IF NOT FOUND OR v_cargo.status <> 'closed' THEN
    RETURN json_build_object('status','error','message','Cargo indisponible pour réception');
  END IF;
  IF EXISTS (SELECT 1 FROM public.cargo_receipts WHERE cargo_id = p_cargo_id) THEN
    RETURN json_build_object('status','error','message','Cargo déjà réceptionné');
  END IF;
  INSERT INTO public.cargo_receipts(cargo_id,driver_id,count_checked,destination_checked,condition_checked)
  VALUES(p_cargo_id,auth.uid(),true,true,true);
  RETURN json_build_object('status','ok');
END; $$;

CREATE OR REPLACE FUNCTION public.load_cargos(p_cargo_ids uuid[]) RETURNS json
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_count int; v_requested int;
BEGIN
  IF public.get_my_role() NOT IN ('admin','driver') THEN RAISE EXCEPTION 'not_authorized'; END IF;
  v_requested := coalesce(array_length(p_cargo_ids,1),0);
  IF v_requested = 0 OR v_requested > 100 OR (SELECT count(DISTINCT id) FROM unnest(p_cargo_ids) AS id) <> v_requested THEN
    RETURN json_build_object('status','error','message','Sélection invalide');
  END IF;
  IF EXISTS (SELECT 1 FROM unnest(p_cargo_ids) AS requested(id)
    LEFT JOIN public.cargos c ON c.id = requested.id
    LEFT JOIN public.cargo_receipts r ON r.cargo_id = requested.id
    WHERE c.id IS NULL OR c.status <> 'closed' OR r.driver_id IS DISTINCT FROM auth.uid()) THEN
    RETURN json_build_object('status','error','message','Réceptionnez et vérifiez chaque cargo avant chargement');
  END IF;
  UPDATE public.cargos SET status='loaded', loaded_at=now(), driver_id=auth.uid()
  WHERE id = ANY(p_cargo_ids) AND status='closed';
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN json_build_object('status','ok','loaded',v_count,'requested',v_requested);
END; $$;
REVOKE ALL ON FUNCTION public.receive_cargo(uuid,boolean,boolean,boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.receive_cargo(uuid,boolean,boolean,boolean) TO authenticated;
