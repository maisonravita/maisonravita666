/*
# Fix: Auto-create profile on signup + create demo admin account

## Changes
1. Creates a trigger function that auto-inserts a profile row when a new user signs up in auth.users
2. Creates a demo admin account (admin@maisonravita.fr / Admin123!) so the app is immediately usable
3. The trigger ensures the profile is created server-side, bypassing RLS issues with client-side inserts
*/

-- Trigger function: auto-create profile on new auth user
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO profiles (id, email, full_name, role, active)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Nouvel employé'),
    'preparator',
    true
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- Trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
