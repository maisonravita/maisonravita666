/*
# Menu generation support

1. Modified Tables
- `recipes`: new column `main_protein` (text) used to vary dishes across the week
  (poulet, boeuf, porc, poisson, oeuf, vegetarien).
- `menus`: unique slot per (date, service) when no site is set, so a week cannot be generated twice.
2. Security
- New DELETE policy on `menus` for admins only, so draft menus can be replaced when regenerating a week.
*/

ALTER TABLE recipes ADD COLUMN IF NOT EXISTS main_protein text NOT NULL DEFAULT 'vegetarien';

CREATE UNIQUE INDEX IF NOT EXISTS uq_menus_slot_no_site ON menus(date, service) WHERE site_id IS NULL;

DROP POLICY IF EXISTS "admin_delete_menus" ON menus;
CREATE POLICY "admin_delete_menus" ON menus FOR DELETE
  TO authenticated USING (is_admin());
