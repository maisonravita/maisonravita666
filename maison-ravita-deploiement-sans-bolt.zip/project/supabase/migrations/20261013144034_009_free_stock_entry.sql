/*
# Free stock entry

Lets admins and cooks add any food item to the stock, and makes stock changes actually
update quantities.

1. Modified Tables
- `ingredients`: unique on lower(name) so the same food cannot be created twice with different casing.
- Insert/update policies on `ingredients` now allow cooks as well as admins.
2. New Functions (SECURITY DEFINER, callable by signed-in users, role checked inside)
- `add_stock(p_ingredient_id, p_quantity, p_lot_number, p_expiry_date, p_reason)`:
  creates a stock lot and logs an 'in' movement in one step.
- `remove_stock(p_ingredient_id, p_quantity, p_type, p_reason)`:
  takes quantity out of lots, oldest expiry first, and logs an 'out' / 'loss' / 'adjustment' movement.
  Refuses to remove more than what is in stock.
3. Security
- Both functions check that the caller is an admin or cook via get_my_role().
- EXECUTE revoked from anon and public.
*/

CREATE UNIQUE INDEX IF NOT EXISTS uq_ingredients_lower_name ON ingredients (lower(name));

DROP POLICY IF EXISTS "admin_insert_ingredients" ON ingredients;
DROP POLICY IF EXISTS "staff_insert_ingredients" ON ingredients;
CREATE POLICY "staff_insert_ingredients" ON ingredients FOR INSERT
  TO authenticated WITH CHECK (get_my_role() IN ('admin', 'cook'));

DROP POLICY IF EXISTS "admin_update_ingredients" ON ingredients;
DROP POLICY IF EXISTS "staff_update_ingredients" ON ingredients;
CREATE POLICY "staff_update_ingredients" ON ingredients FOR UPDATE
  TO authenticated
  USING (get_my_role() IN ('admin', 'cook'))
  WITH CHECK (get_my_role() IN ('admin', 'cook'));

CREATE OR REPLACE FUNCTION add_stock(
  p_ingredient_id uuid,
  p_quantity numeric,
  p_lot_number text DEFAULT NULL,
  p_expiry_date date DEFAULT NULL,
  p_reason text DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_unit text;
  v_lot uuid;
BEGIN
  IF get_my_role() NOT IN ('admin', 'cook') THEN
    RAISE EXCEPTION 'not_authorized';
  END IF;
  IF p_quantity IS NULL OR p_quantity <= 0 OR p_quantity > 100000 THEN
    RAISE EXCEPTION 'invalid_quantity';
  END IF;
  SELECT unit INTO v_unit FROM ingredients WHERE id = p_ingredient_id;
  IF v_unit IS NULL THEN
    RAISE EXCEPTION 'unknown_ingredient';
  END IF;

  INSERT INTO stock_lots (ingredient_id, lot_number, quantity, unit, expiry_date)
  VALUES (p_ingredient_id, NULLIF(trim(p_lot_number), ''), p_quantity, v_unit, p_expiry_date)
  RETURNING id INTO v_lot;

  INSERT INTO stock_movements (ingredient_id, movement_type, quantity, unit, reason, user_id)
  VALUES (p_ingredient_id, 'in', p_quantity, v_unit, COALESCE(NULLIF(trim(p_reason), ''), 'Entrée en stock'), auth.uid());

  RETURN v_lot;
END;
$$;

CREATE OR REPLACE FUNCTION remove_stock(
  p_ingredient_id uuid,
  p_quantity numeric,
  p_type text DEFAULT 'out',
  p_reason text DEFAULT NULL
) RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_unit text;
  v_total numeric;
  v_left numeric := p_quantity;
  v_take numeric;
  r record;
BEGIN
  IF get_my_role() NOT IN ('admin', 'cook') THEN
    RAISE EXCEPTION 'not_authorized';
  END IF;
  IF p_type NOT IN ('out', 'loss', 'adjustment') THEN
    RAISE EXCEPTION 'invalid_type';
  END IF;
  IF p_quantity IS NULL OR p_quantity <= 0 THEN
    RAISE EXCEPTION 'invalid_quantity';
  END IF;
  SELECT unit INTO v_unit FROM ingredients WHERE id = p_ingredient_id;
  IF v_unit IS NULL THEN
    RAISE EXCEPTION 'unknown_ingredient';
  END IF;

  SELECT COALESCE(sum(quantity), 0) INTO v_total
  FROM stock_lots WHERE ingredient_id = p_ingredient_id AND quantity > 0;
  IF p_quantity > v_total THEN
    RAISE EXCEPTION 'insufficient_stock';
  END IF;

  FOR r IN
    SELECT id, quantity FROM stock_lots
    WHERE ingredient_id = p_ingredient_id AND quantity > 0
    ORDER BY expiry_date NULLS LAST, received_at
    FOR UPDATE
  LOOP
    EXIT WHEN v_left <= 0;
    v_take := LEAST(r.quantity, v_left);
    UPDATE stock_lots SET quantity = quantity - v_take WHERE id = r.id;
    v_left := v_left - v_take;
  END LOOP;

  INSERT INTO stock_movements (ingredient_id, movement_type, quantity, unit, reason, user_id)
  VALUES (p_ingredient_id, p_type, -p_quantity, v_unit, COALESCE(NULLIF(trim(p_reason), ''), 'Sortie de stock'), auth.uid());

  RETURN v_total - p_quantity;
END;
$$;

REVOKE EXECUTE ON FUNCTION add_stock(uuid, numeric, text, date, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION add_stock(uuid, numeric, text, date, text) TO authenticated;
REVOKE EXECUTE ON FUNCTION remove_stock(uuid, numeric, text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION remove_stock(uuid, numeric, text, text) TO authenticated;
