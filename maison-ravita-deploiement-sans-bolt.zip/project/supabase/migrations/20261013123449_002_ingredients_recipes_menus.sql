/*
# Maison Ravita — Schema Part 2: Ingredients, Stocks, Recipes, Menus

## Tables
1. ingredients — Food items with category, unit, price, supplier, alert threshold
2. stock_lots — Stock lots with expiry dates and quantities
3. stock_movements — All stock movements (in/out/loss/adjustment/inventory)
4. recipes — Recipes with cost, allergens, steps, validation status
5. recipe_ingredients — Ingredients required per portion for each recipe
6. menus — Daily menu entries (date, service, site, recipe, validation status)

## Security
- All tables have RLS enabled
- Read access for all authenticated users
- Write access restricted to admin (and cook for stock operations)
*/

-- INGREDIENTS
CREATE TABLE IF NOT EXISTS ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL DEFAULT 'divers',
  unit text NOT NULL DEFAULT 'kg',
  package_size numeric(10,2),
  price numeric(10,2) NOT NULL DEFAULT 0,
  supplier text,
  alert_threshold numeric(10,2) NOT NULL DEFAULT 5,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE ingredients ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_ingredients" ON ingredients;
CREATE POLICY "select_ingredients" ON ingredients FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_ingredients" ON ingredients;
CREATE POLICY "admin_insert_ingredients" ON ingredients FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_ingredients" ON ingredients;
CREATE POLICY "admin_update_ingredients" ON ingredients FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- STOCK LOTS
CREATE TABLE IF NOT EXISTS stock_lots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ingredient_id uuid NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  lot_number text,
  quantity numeric(10,2) NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT 'kg',
  expiry_date date,
  received_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE stock_lots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_stock_lots" ON stock_lots;
CREATE POLICY "select_stock_lots" ON stock_lots FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_stock_lots" ON stock_lots;
CREATE POLICY "insert_stock_lots" ON stock_lots FOR INSERT
  TO authenticated WITH CHECK (get_my_role() IN ('admin', 'cook'));

DROP POLICY IF EXISTS "update_stock_lots" ON stock_lots;
CREATE POLICY "update_stock_lots" ON stock_lots FOR UPDATE
  TO authenticated USING (get_my_role() IN ('admin', 'cook')) WITH CHECK (get_my_role() IN ('admin', 'cook'));

-- STOCK MOVEMENTS
CREATE TABLE IF NOT EXISTS stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ingredient_id uuid NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  movement_type text NOT NULL CHECK (movement_type IN ('in', 'out', 'loss', 'adjustment', 'inventory')),
  quantity numeric(10,2) NOT NULL,
  unit text NOT NULL,
  reason text,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE stock_movements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_stock_movements" ON stock_movements;
CREATE POLICY "select_stock_movements" ON stock_movements FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_stock_movements" ON stock_movements;
CREATE POLICY "insert_stock_movements" ON stock_movements FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- RECIPES
CREATE TABLE IF NOT EXISTS recipes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  photo_url text,
  servings integer NOT NULL DEFAULT 380,
  prep_time_minutes integer NOT NULL DEFAULT 60,
  cook_time_minutes integer NOT NULL DEFAULT 30,
  cost_per_portion numeric(10,2) NOT NULL DEFAULT 0,
  allergens text[] NOT NULL DEFAULT '{}',
  conservation text,
  steps text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'validated', 'archived')),
  created_by uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE recipes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_recipes" ON recipes;
CREATE POLICY "select_recipes" ON recipes FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_recipes" ON recipes;
CREATE POLICY "admin_insert_recipes" ON recipes FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_recipes" ON recipes;
CREATE POLICY "admin_update_recipes" ON recipes FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- RECIPE INGREDIENTS
CREATE TABLE IF NOT EXISTS recipe_ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipe_id uuid NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  ingredient_id uuid NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  quantity_per_portion numeric(10,3) NOT NULL,
  unit text NOT NULL
);
ALTER TABLE recipe_ingredients ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_recipe_ingredients" ON recipe_ingredients;
CREATE POLICY "select_recipe_ingredients" ON recipe_ingredients FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_recipe_ingredients" ON recipe_ingredients;
CREATE POLICY "admin_insert_recipe_ingredients" ON recipe_ingredients FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_recipe_ingredients" ON recipe_ingredients;
CREATE POLICY "admin_update_recipe_ingredients" ON recipe_ingredients FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_delete_recipe_ingredients" ON recipe_ingredients;
CREATE POLICY "admin_delete_recipe_ingredients" ON recipe_ingredients FOR DELETE
  TO authenticated USING (is_admin());

-- MENUS
CREATE TABLE IF NOT EXISTS menus (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  service text NOT NULL CHECK (service IN ('midi', 'soir')),
  site_id uuid REFERENCES sites(id) ON DELETE SET NULL,
  recipe_id uuid NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'validated', 'rejected')),
  quantity integer NOT NULL DEFAULT 380,
  validated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  validated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE menus ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_menus" ON menus;
CREATE POLICY "select_menus" ON menus FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_menus" ON menus;
CREATE POLICY "admin_insert_menus" ON menus FOR INSERT
  TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "admin_update_menus" ON menus;
CREATE POLICY "admin_update_menus" ON menus FOR UPDATE
  TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_ingredients_category ON ingredients(category);
CREATE INDEX IF NOT EXISTS idx_stock_lots_ingredient ON stock_lots(ingredient_id);
CREATE INDEX IF NOT EXISTS idx_stock_movements_ingredient ON stock_movements(ingredient_id);
CREATE INDEX IF NOT EXISTS idx_recipes_status ON recipes(status);
CREATE INDEX IF NOT EXISTS idx_menus_date ON menus(date);
CREATE INDEX IF NOT EXISTS idx_menus_status ON menus(status);
