/*
# Dietary restrictions and automatic shopping list

1. Modified Tables
- `ingredients`: new flags
  - `contains_pork` (boolean, default false) - the food contains pork (lardons, jambon...)
  - `contains_alcohol` (boolean, default false) - the food contains alcohol (wine, beer...)
  - `halal_certified` (boolean, default false) - the meat is halal certified
  Seeded "Lardons" and "Jambon blanc" are marked as containing pork.
- `shopping_items`: new columns
  - `reason` (text) - why the item is on the list (upcoming menus, low stock...)
  - `halal_required` (boolean) - the item must be bought halal certified
  A pending item is unique per ingredient so the list never has duplicates.
- `settings`: new keys `diet_restrictions` (comma list: halal, sans_porc, vegetarien, sans_alcool)
  and `shopping_horizon_days` (how many days of menus the shopping list anticipates, default 7).

2. New Functions
- `refresh_shopping_item(ingredient)` (internal): computes what is needed for the menus of the
  coming days (minus barquettes already produced) plus the alert threshold, subtracts current stock,
  and creates, updates or removes the pending shopping item accordingly.
- Trigger `trg_auto_shopping` on `stock_movements`: every stock change (production, manual exit,
  new delivery) refreshes the shopping list for that food automatically.
- `generate_shopping_list(p_days)` (RPC, admin/cook only): recalculates the full list.

3. Security
- Internal functions are not callable by clients; the RPC checks the caller's role and bounds p_days.
*/

ALTER TABLE ingredients ADD COLUMN IF NOT EXISTS contains_pork boolean NOT NULL DEFAULT false;
ALTER TABLE ingredients ADD COLUMN IF NOT EXISTS contains_alcohol boolean NOT NULL DEFAULT false;
ALTER TABLE ingredients ADD COLUMN IF NOT EXISTS halal_certified boolean NOT NULL DEFAULT false;
UPDATE ingredients SET contains_pork = true WHERE name IN ('Lardons', 'Jambon blanc');

ALTER TABLE shopping_items ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE shopping_items ADD COLUMN IF NOT EXISTS halal_required boolean NOT NULL DEFAULT false;
CREATE UNIQUE INDEX IF NOT EXISTS uq_shopping_pending_ingredient
  ON shopping_items (ingredient_id) WHERE status = 'pending';

INSERT INTO settings (key, value, description) VALUES
  ('diet_restrictions', '', 'Restrictions alimentaires appliquées aux menus (halal, sans_porc, vegetarien, sans_alcool)'),
  ('shopping_horizon_days', '7', 'Nombre de jours de menus anticipés par la liste de courses')
ON CONFLICT (key) DO NOTHING;

CREATE INDEX IF NOT EXISTS idx_meal_units_recipe_service ON meal_units (recipe_id, service, scanned_at);
CREATE INDEX IF NOT EXISTS idx_menus_date ON menus (date);

CREATE OR REPLACE FUNCTION refresh_shopping_item(p_ingredient_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  ing ingredients%ROWTYPE;
  v_days int;
  v_halal boolean;
  v_need numeric;
  v_need_soon numeric;
  v_stock numeric;
  v_to_buy numeric;
  v_priority text;
  v_reason text;
  v_existing uuid;
BEGIN
  SELECT * INTO ing FROM ingredients WHERE id = p_ingredient_id;
  IF NOT FOUND THEN RETURN 'none'; END IF;

  SELECT COALESCE(NULLIF(value, '')::int, 7) INTO v_days FROM settings WHERE key = 'shopping_horizon_days';
  v_days := LEAST(GREATEST(COALESCE(v_days, 7), 1), 31);
  SELECT COALESCE(value, '') LIKE '%halal%' INTO v_halal FROM settings WHERE key = 'diet_restrictions';

  SELECT
    COALESCE(sum(ri.quantity_per_portion * GREATEST(m.quantity - p.done, 0)), 0),
    COALESCE(sum(ri.quantity_per_portion * GREATEST(m.quantity - p.done, 0)) FILTER (WHERE m.date <= current_date + 1), 0)
  INTO v_need, v_need_soon
  FROM menus m
  JOIN recipe_ingredients ri ON ri.recipe_id = m.recipe_id AND ri.ingredient_id = p_ingredient_id
  CROSS JOIN LATERAL (
    SELECT count(*) AS done FROM meal_units mu
    WHERE mu.recipe_id = m.recipe_id AND mu.service = m.service
      AND mu.scanned_at >= m.date AND mu.scanned_at < m.date + 1
  ) p
  WHERE m.date BETWEEN current_date AND current_date + v_days - 1;

  SELECT COALESCE(sum(quantity), 0) INTO v_stock
  FROM stock_lots WHERE ingredient_id = p_ingredient_id AND quantity > 0;

  v_to_buy := ceil((v_need + COALESCE(ing.alert_threshold, 0) - v_stock) * 100) / 100;

  SELECT id INTO v_existing FROM shopping_items
  WHERE ingredient_id = p_ingredient_id AND status = 'pending';

  IF v_to_buy <= 0 THEN
    IF v_existing IS NOT NULL THEN
      DELETE FROM shopping_items WHERE id = v_existing
        AND NOT EXISTS (SELECT 1 FROM purchases WHERE shopping_item_id = v_existing);
      RETURN 'removed';
    END IF;
    RETURN 'none';
  END IF;

  v_priority := CASE
    WHEN v_stock < v_need_soon THEN 'high'
    WHEN v_stock < v_need THEN 'medium'
    ELSE 'low'
  END;

  v_reason := CASE
    WHEN v_need > 0 THEN 'Menus des ' || v_days || ' prochains jours : '
      || trim(to_char(v_need, 'FM999999990.99')) || ' ' || ing.unit || ' nécessaires, '
      || trim(to_char(v_stock, 'FM999999990.99')) || ' en stock'
    WHEN v_stock <= 0 THEN 'Rupture de stock'
    ELSE 'Sous le seuil d''alerte (' || trim(to_char(ing.alert_threshold, 'FM999999990.99')) || ' ' || ing.unit || ')'
  END;

  INSERT INTO shopping_items (ingredient_id, quantity_needed, unit, priority, status, estimated_price, supplier, reason, halal_required)
  VALUES (p_ingredient_id, v_to_buy, ing.unit, v_priority, 'pending',
          round(v_to_buy * ing.price, 2), ing.supplier, v_reason,
          v_halal AND ing.category = 'viandes')
  ON CONFLICT (ingredient_id) WHERE status = 'pending'
  DO UPDATE SET quantity_needed = EXCLUDED.quantity_needed,
                priority = EXCLUDED.priority,
                estimated_price = EXCLUDED.estimated_price,
                reason = EXCLUDED.reason,
                halal_required = EXCLUDED.halal_required;

  RETURN CASE WHEN v_existing IS NULL THEN 'created' ELSE 'updated' END;
END;
$$;

REVOKE EXECUTE ON FUNCTION refresh_shopping_item(uuid) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION auto_shopping_on_movement()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_result text;
  v_name text;
BEGIN
  v_result := refresh_shopping_item(NEW.ingredient_id);
  IF v_result = 'created' THEN
    SELECT name INTO v_name FROM ingredients WHERE id = NEW.ingredient_id;
    INSERT INTO notifications (user_id, title, message, type, link)
    VALUES (NULL, 'Ajouté aux courses', v_name || ' a été ajouté automatiquement à la liste de courses.', 'info', '/dashboard/achats');
  END IF;
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION auto_shopping_on_movement() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_auto_shopping ON stock_movements;
CREATE TRIGGER trg_auto_shopping
  AFTER INSERT OR UPDATE ON stock_movements
  FOR EACH ROW EXECUTE FUNCTION auto_shopping_on_movement();

CREATE OR REPLACE FUNCTION generate_shopping_list(p_days int DEFAULT NULL)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  r record;
  v_result text;
  v_created int := 0;
  v_updated int := 0;
  v_removed int := 0;
BEGIN
  IF get_my_role() NOT IN ('admin', 'cook') THEN
    RAISE EXCEPTION 'not_authorized';
  END IF;
  IF p_days IS NOT NULL THEN
    IF p_days < 1 OR p_days > 31 THEN
      RAISE EXCEPTION 'invalid_days';
    END IF;
    UPDATE settings SET value = p_days::text WHERE key = 'shopping_horizon_days';
  END IF;

  FOR r IN SELECT id FROM ingredients LOOP
    v_result := refresh_shopping_item(r.id);
    IF v_result = 'created' THEN v_created := v_created + 1;
    ELSIF v_result = 'updated' THEN v_updated := v_updated + 1;
    ELSIF v_result = 'removed' THEN v_removed := v_removed + 1;
    END IF;
  END LOOP;

  RETURN json_build_object('created', v_created, 'updated', v_updated, 'removed', v_removed);
END;
$$;

REVOKE EXECUTE ON FUNCTION generate_shopping_list(int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION generate_shopping_list(int) TO authenticated;
