/*
# Security lockdown, server-controlled cargo and delivery flow, staff management

1. Helpers
- `get_my_role()` returns NULL for deactivated accounts; `is_staff()` = active account.
- Helpers get a fixed search_path; trigger/internal functions no longer callable from the API.
- `handle_new_user` : accounts created by the admin (app_metadata.invited) are active with the chosen role;
  self sign-ups are created INACTIVE (no access until an admin activates them).

2. Profiles
- Users may only edit their own full_name and phone. Role, active, hourly_rate change only via `admin_update_staff`.

3. Cargos
- New columns `driver_id`, `route_id`.
- Direct insert/update restricted to admin; preparators and drivers go through functions:
  `open_cargo`, `process_scan` (rewritten), `close_cargo`, `load_cargos`, `start_route`, `deliver_cargo`, `finish_route`.

4. Read access narrowed
- Cargos: admin, own preparator, drivers (closed cargos to load + their own).
- Delivery proofs, routes, gps, incidents, meal units, scan events: own rows or admin.
- Purchases / shopping list: admin, cook, courier. Stock: admin, cook. Supplier invoices: admin, courier.
- Reference data (menus, recipes, ingredients, sites, settings): active staff only.
- anon role loses all table privileges.

5. Notes
- No data is deleted. Only policies are replaced.
*/

ALTER TABLE cargos ADD COLUMN IF NOT EXISTS driver_id uuid REFERENCES profiles(id);
ALTER TABLE cargos ADD COLUMN IF NOT EXISTS route_id uuid REFERENCES delivery_routes(id);
CREATE INDEX IF NOT EXISTS cargos_driver_idx ON cargos(driver_id);
CREATE INDEX IF NOT EXISTS cargos_route_idx ON cargos(route_id);
CREATE INDEX IF NOT EXISTS cargos_status_idx ON cargos(status);
CREATE INDEX IF NOT EXISTS meal_units_scanned_at_idx ON meal_units(scanned_at);

CREATE OR REPLACE FUNCTION get_my_role() RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM profiles WHERE id = auth.uid() AND active = true;
$$;

CREATE OR REPLACE FUNCTION is_admin() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin' AND active = true);
$$;

CREATE OR REPLACE FUNCTION is_staff() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND active = true);
$$;

CREATE OR REPLACE FUNCTION paris_today() RETURNS date
LANGUAGE sql STABLE SET search_path = public AS $$
  SELECT (now() AT TIME ZONE 'Europe/Paris')::date;
$$;

CREATE OR REPLACE FUNCTION increment_total_counter() RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE new_count bigint;
BEGIN
  INSERT INTO total_counter (id, count) VALUES (1, 1)
  ON CONFLICT (id) DO UPDATE SET count = total_counter.count + 1, updated_at = now()
  RETURNING count INTO new_count;
  RETURN new_count;
END;
$$;

CREATE OR REPLACE FUNCTION handle_new_user() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_invited boolean := COALESCE((NEW.raw_app_meta_data->>'invited')::boolean, false);
  v_role text := NEW.raw_app_meta_data->>'role';
BEGIN
  IF v_role IS NULL OR v_role NOT IN ('admin','cook','preparator','driver','courier') THEN
    v_role := 'preparator';
  END IF;
  INSERT INTO profiles (id, email, full_name, role, active)
  VALUES (NEW.id, NEW.email, COALESCE(NULLIF(NEW.raw_user_meta_data->>'full_name',''), 'Nouvel employé'),
          CASE WHEN v_invited THEN v_role ELSE 'preparator' END, v_invited)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION increment_total_counter() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION get_my_role() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION is_admin() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION is_staff() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION get_my_role(), is_admin(), is_staff() TO authenticated;

REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;

REVOKE INSERT, UPDATE ON profiles FROM authenticated;
GRANT UPDATE (full_name, phone) ON profiles TO authenticated;

-- Reference data: active staff only
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['ingredients','recipes','recipe_ingredients','menus','sites','settings','total_counter'] LOOP
    EXECUTE format('DROP POLICY IF EXISTS "select_%1$s" ON %1$I', t);
    EXECUTE format('CREATE POLICY "select_%1$s" ON %1$I FOR SELECT TO authenticated USING (is_staff())', t);
  END LOOP;
END $$;

-- Cargos
DROP POLICY IF EXISTS "select_cargos" ON cargos;
CREATE POLICY "select_cargos" ON cargos FOR SELECT TO authenticated USING (
  is_admin() OR preparator_id = auth.uid()
  OR (get_my_role() = 'driver' AND (status = 'closed' OR driver_id = auth.uid())));
DROP POLICY IF EXISTS "insert_cargos" ON cargos;
CREATE POLICY "insert_cargos" ON cargos FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "update_cargos" ON cargos;
CREATE POLICY "update_cargos" ON cargos FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());

-- Delivery
DROP POLICY IF EXISTS "select_delivery_proofs" ON delivery_proofs;
CREATE POLICY "select_delivery_proofs" ON delivery_proofs FOR SELECT TO authenticated USING (driver_id = auth.uid() OR is_admin());
DROP POLICY IF EXISTS "insert_delivery_proofs" ON delivery_proofs;
CREATE POLICY "insert_delivery_proofs" ON delivery_proofs FOR INSERT TO authenticated WITH CHECK (is_admin());

DROP POLICY IF EXISTS "select_delivery_routes" ON delivery_routes;
CREATE POLICY "select_delivery_routes" ON delivery_routes FOR SELECT TO authenticated USING (driver_id = auth.uid() OR is_admin());
DROP POLICY IF EXISTS "insert_delivery_routes" ON delivery_routes;
CREATE POLICY "insert_delivery_routes" ON delivery_routes FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "update_delivery_routes" ON delivery_routes;
CREATE POLICY "update_delivery_routes" ON delivery_routes FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS "select_gps_positions" ON gps_positions;
CREATE POLICY "select_gps_positions" ON gps_positions FOR SELECT TO authenticated USING (driver_id = auth.uid() OR is_admin());
DROP POLICY IF EXISTS "insert_gps_positions" ON gps_positions;
CREATE POLICY "insert_gps_positions" ON gps_positions FOR INSERT TO authenticated WITH CHECK (
  driver_id = auth.uid() AND EXISTS (SELECT 1 FROM delivery_routes r WHERE r.id = route_id AND r.driver_id = auth.uid()));

DROP POLICY IF EXISTS "select_incidents" ON incidents;
CREATE POLICY "select_incidents" ON incidents FOR SELECT TO authenticated USING (driver_id = auth.uid() OR is_admin());
DROP POLICY IF EXISTS "insert_incidents" ON incidents;
CREATE POLICY "insert_incidents" ON incidents FOR INSERT TO authenticated WITH CHECK (driver_id = auth.uid() AND is_staff());

-- Production
DROP POLICY IF EXISTS "select_meal_units" ON meal_units;
CREATE POLICY "select_meal_units" ON meal_units FOR SELECT TO authenticated USING (scanned_by = auth.uid() OR is_admin());
DROP POLICY IF EXISTS "insert_meal_units" ON meal_units;
CREATE POLICY "insert_meal_units" ON meal_units FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "select_scan_events" ON scan_events;
CREATE POLICY "select_scan_events" ON scan_events FOR SELECT TO authenticated USING (user_id = auth.uid() OR is_admin());
DROP POLICY IF EXISTS "insert_scan_events" ON scan_events;
CREATE POLICY "insert_scan_events" ON scan_events FOR INSERT TO authenticated WITH CHECK (is_admin());

-- Purchasing & stock
DROP POLICY IF EXISTS "select_purchases" ON purchases;
CREATE POLICY "select_purchases" ON purchases FOR SELECT TO authenticated USING (get_my_role() IN ('admin','cook','courier'));
DROP POLICY IF EXISTS "insert_purchases" ON purchases;
CREATE POLICY "insert_purchases" ON purchases FOR INSERT TO authenticated WITH CHECK (courier_id = auth.uid() AND get_my_role() IN ('admin','courier'));
DROP POLICY IF EXISTS "select_shopping_items" ON shopping_items;
CREATE POLICY "select_shopping_items" ON shopping_items FOR SELECT TO authenticated USING (get_my_role() IN ('admin','cook','courier'));
DROP POLICY IF EXISTS "select_stock_lots" ON stock_lots;
CREATE POLICY "select_stock_lots" ON stock_lots FOR SELECT TO authenticated USING (get_my_role() IN ('admin','cook'));
DROP POLICY IF EXISTS "select_stock_movements" ON stock_movements;
CREATE POLICY "select_stock_movements" ON stock_movements FOR SELECT TO authenticated USING (get_my_role() IN ('admin','cook'));
DROP POLICY IF EXISTS "insert_stock_movements" ON stock_movements;
CREATE POLICY "insert_stock_movements" ON stock_movements FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND get_my_role() IN ('admin','cook'));
DROP POLICY IF EXISTS "select_supplier_invoices" ON supplier_invoices;
CREATE POLICY "select_supplier_invoices" ON supplier_invoices FOR SELECT TO authenticated USING (get_my_role() IN ('admin','courier'));
DROP POLICY IF EXISTS "insert_audit_logs" ON audit_logs;
CREATE POLICY "insert_audit_logs" ON audit_logs FOR INSERT TO authenticated WITH CHECK (is_staff());

-- ===== Production functions =====
CREATE OR REPLACE FUNCTION open_cargo(p_site_id uuid, p_service text) RETURNS json
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_menu menus%ROWTYPE;
  v_cargo cargos%ROWTYPE;
  v_capacity int;
  v_site sites%ROWTYPE;
BEGIN
  IF get_my_role() NOT IN ('admin','preparator') OR get_my_role() IS NULL THEN
    RAISE EXCEPTION 'not_authorized';
  END IF;
  IF p_service NOT IN ('midi','soir') THEN
    RETURN json_build_object('status','error','message','Service invalide');
  END IF;
  SELECT * INTO v_site FROM sites WHERE id = p_site_id;
  IF NOT FOUND THEN
    RETURN json_build_object('status','error','message','Site introuvable');
  END IF;

  SELECT * INTO v_menu FROM menus
  WHERE date = paris_today() AND service = p_service AND status = 'validated'
    AND (site_id IS NULL OR site_id = p_site_id)
  ORDER BY site_id NULLS LAST LIMIT 1;
  IF NOT FOUND THEN
    RETURN json_build_object('status','no_menu',
      'message','Aucun menu validé pour ce service aujourd''hui. Demandez à l''administrateur de valider le menu avant de scanner.');
  END IF;

  SELECT COALESCE(NULLIF(value,'')::int, 50) INTO v_capacity FROM settings WHERE key = 'cargo_max_capacity';
  v_capacity := GREATEST(COALESCE(v_capacity, 50), 1);

  SELECT * INTO v_cargo FROM cargos
  WHERE preparator_id = auth.uid() AND site_id = p_site_id AND service = p_service AND status = 'open'
  ORDER BY created_at DESC LIMIT 1 FOR UPDATE;

  IF FOUND AND v_cargo.recipe_id <> v_menu.recipe_id THEN
    IF v_cargo.meal_unit_count = 0 THEN
      UPDATE cargos SET recipe_id = v_menu.recipe_id, max_capacity = v_capacity WHERE id = v_cargo.id RETURNING * INTO v_cargo;
    ELSE
      UPDATE cargos SET status = 'closed', closed_at = now() WHERE id = v_cargo.id;
      v_cargo := NULL;
    END IF;
  END IF;

  IF v_cargo.id IS NULL THEN
    INSERT INTO cargos (code, site_id, service, recipe_id, preparator_id, max_capacity, status)
    VALUES ('CARGO-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,8)),
            p_site_id, p_service, v_menu.recipe_id, auth.uid(), v_capacity, 'open')
    RETURNING * INTO v_cargo;
  END IF;

  RETURN json_build_object(
    'status','ok',
    'cargo', row_to_json(v_cargo),
    'recipe', (SELECT row_to_json(r) FROM recipes r WHERE r.id = v_menu.recipe_id),
    'my_total_today', (SELECT count(*) FROM meal_units WHERE scanned_by = auth.uid()
                       AND (scanned_at AT TIME ZONE 'Europe/Paris')::date = paris_today()),
    'site_done', (SELECT count(*) FROM meal_units WHERE site_id = p_site_id AND service = p_service
                  AND (scanned_at AT TIME ZONE 'Europe/Paris')::date = paris_today()),
    'site_target', v_site.capacity
  );
END;
$$;

CREATE OR REPLACE FUNCTION process_scan(p_qr_code text, p_cargo_id uuid, p_site_id uuid, p_service text, p_recipe_id uuid)
RETURNS json LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_code text := trim(COALESCE(p_qr_code,''));
  cargo_rec cargos%ROWTYPE;
  new_unit meal_units%ROWTYPE;
  new_count bigint;
  v_role text := get_my_role();

  PROCEDURE_dummy int;
BEGIN
  IF v_role IS NULL OR v_role NOT IN ('admin','preparator') THEN
    RETURN json_build_object('status','error','message','Accès refusé');
  END IF;
  IF length(v_code) = 0 OR length(v_code) > 200 THEN
    RETURN json_build_object('status','error','message','Code QR invalide');
  END IF;

  SELECT * INTO cargo_rec FROM cargos WHERE id = p_cargo_id FOR UPDATE;
  IF NOT FOUND OR (cargo_rec.preparator_id <> auth.uid() AND v_role <> 'admin') THEN
    RETURN json_build_object('status','error','message','Cargo introuvable');
  END IF;

  IF EXISTS (SELECT 1 FROM meal_units WHERE qr_code = v_code) THEN
    INSERT INTO scan_events (qr_code, cargo_id, user_id, success, error_message)
    VALUES (v_code, p_cargo_id, auth.uid(), false, 'Barquette déjà scannée');
    RETURN json_build_object('status','duplicate','message','Barquette déjà scannée');
  END IF;

  IF cargo_rec.status <> 'open' THEN
    RETURN json_build_object('status','error','message','Ce cargo est fermé');
  END IF;
  IF cargo_rec.site_id <> p_site_id OR cargo_rec.service <> p_service THEN
    RETURN json_build_object('status','mismatch','message','Incohérence site/service');
  END IF;
  IF cargo_rec.meal_unit_count >= cargo_rec.max_capacity THEN
    RETURN json_build_object('status','full','message','Cargo plein : fermez-le pour en ouvrir un nouveau');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM menus WHERE date = paris_today() AND service = cargo_rec.service
                 AND status = 'validated' AND recipe_id = cargo_rec.recipe_id
                 AND (site_id IS NULL OR site_id = cargo_rec.site_id)) THEN
    INSERT INTO scan_events (qr_code, cargo_id, user_id, success, error_message)
    VALUES (v_code, p_cargo_id, auth.uid(), false, 'Aucun menu validé');
    RETURN json_build_object('status','no_menu','message','Aucun menu validé pour cette recette aujourd''hui');
  END IF;

  INSERT INTO meal_units (qr_code, cargo_id, site_id, service, recipe_id, scanned_by)
  VALUES (v_code, p_cargo_id, cargo_rec.site_id, cargo_rec.service, cargo_rec.recipe_id, auth.uid())
  RETURNING * INTO new_unit;
  UPDATE cargos SET meal_unit_count = meal_unit_count + 1 WHERE id = p_cargo_id;
  INSERT INTO scan_events (qr_code, meal_unit_id, cargo_id, user_id, success)
  VALUES (v_code, new_unit.id, p_cargo_id, auth.uid(), true);
  SELECT increment_total_counter() INTO new_count;

  RETURN json_build_object('status','ok','meal_unit_id',new_unit.id,
    'cargo_count', cargo_rec.meal_unit_count + 1, 'max_capacity', cargo_rec.max_capacity, 'total_count', new_count);
END;
$$;

CREATE OR REPLACE FUNCTION close_cargo(p_cargo_id uuid) RETURNS json
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_role text := get_my_role(); v_count int;
BEGIN
  IF v_role IS NULL OR v_role NOT IN ('admin','preparator') THEN RAISE EXCEPTION 'not_authorized'; END IF;
  UPDATE cargos SET status = 'closed', closed_at = now()
  WHERE id = p_cargo_id AND status = 'open' AND meal_unit_count > 0
    AND (preparator_id = auth.uid() OR v_role = 'admin')
  RETURNING meal_unit_count INTO v_count;
  IF v_count IS NULL THEN
    RETURN json_build_object('status','error','message','Ce cargo ne peut pas être fermé (vide ou déjà fermé)');
  END IF;
  INSERT INTO notifications (user_id, title, message, type, link)
  VALUES (NULL, 'Cargo prêt', v_count || ' barquettes prêtes au chargement', 'info', '/dashboard/cargos');
  RETURN json_build_object('status','ok','count',v_count);
END;
$$;

-- ===== Delivery functions =====
CREATE OR REPLACE FUNCTION load_cargos(p_cargo_ids uuid[]) RETURNS json
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_role text := get_my_role(); v_count int;
BEGIN
  IF v_role IS NULL OR v_role NOT IN ('admin','driver') THEN RAISE EXCEPTION 'not_authorized'; END IF;
  IF p_cargo_ids IS NULL OR array_length(p_cargo_ids,1) IS NULL OR array_length(p_cargo_ids,1) > 100 THEN
    RETURN json_build_object('status','error','message','Sélection invalide');
  END IF;
  WITH u AS (
    UPDATE cargos SET status = 'loaded', loaded_at = now(), driver_id = auth.uid()
    WHERE id = ANY(p_cargo_ids) AND status = 'closed' RETURNING 1)
  SELECT count(*) INTO v_count FROM u;
  RETURN json_build_object('status','ok','loaded',v_count,'requested',array_length(p_cargo_ids,1));
END;
$$;

CREATE OR REPLACE FUNCTION start_route() RETURNS json
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_role text := get_my_role(); v_route delivery_routes%ROWTYPE; v_ids uuid[];
BEGIN
  IF v_role IS NULL OR v_role NOT IN ('admin','driver') THEN RAISE EXCEPTION 'not_authorized'; END IF;
  SELECT * INTO v_route FROM delivery_routes WHERE driver_id = auth.uid() AND status = 'active' LIMIT 1;
  IF FOUND THEN RETURN json_build_object('status','ok','route_id',v_route.id); END IF;

  SELECT array_agg(id) INTO v_ids FROM cargos
  WHERE driver_id = auth.uid() AND status = 'loaded' AND route_id IS NULL;
  IF v_ids IS NULL THEN
    RETURN json_build_object('status','error','message','Aucun cargo chargé');
  END IF;
  INSERT INTO delivery_routes (driver_id, status, started_at, cargo_ids)
  VALUES (auth.uid(), 'active', now(), v_ids) RETURNING * INTO v_route;
  UPDATE cargos SET status = 'in_delivery', route_id = v_route.id WHERE id = ANY(v_ids);
  INSERT INTO notifications (user_id, title, message, type, link)
  VALUES (NULL, 'Tournée démarrée', array_length(v_ids,1) || ' cargo(s) en livraison', 'info', '/dashboard/cargos');
  RETURN json_build_object('status','ok','route_id',v_route.id);
END;
$$;

CREATE OR REPLACE FUNCTION deliver_cargo(p_cargo_id uuid, p_quantity int, p_photo text, p_notes text) RETURNS json
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_role text := get_my_role(); v_cargo cargos%ROWTYPE; v_remaining int; v_site text;
BEGIN
  IF v_role IS NULL OR v_role NOT IN ('admin','driver') THEN RAISE EXCEPTION 'not_authorized'; END IF;
  SELECT * INTO v_cargo FROM cargos WHERE id = p_cargo_id FOR UPDATE;
  IF NOT FOUND OR (v_cargo.driver_id <> auth.uid() AND v_role <> 'admin') THEN
    RETURN json_build_object('status','error','message','Cargo introuvable');
  END IF;
  IF v_cargo.status <> 'in_delivery' THEN
    RETURN json_build_object('status','error','message','Ce cargo a déjà été livré');
  END IF;
  IF p_quantity IS NULL OR p_quantity < 0 OR p_quantity > v_cargo.meal_unit_count THEN
    RETURN json_build_object('status','error','message','Quantité invalide (0 à ' || v_cargo.meal_unit_count || ')');
  END IF;
  IF p_photo IS NULL OR p_photo NOT LIKE 'data:image/%' OR length(p_photo) > 3000000 THEN
    RETURN json_build_object('status','error','message','Photo manquante ou trop lourde');
  END IF;

  INSERT INTO delivery_proofs (cargo_id, route_id, driver_id, site_id, quantity_delivered, photo_url, notes)
  VALUES (v_cargo.id, v_cargo.route_id, auth.uid(), v_cargo.site_id, p_quantity, p_photo, left(p_notes, 1000));
  UPDATE cargos SET status = 'delivered', delivered_at = now() WHERE id = v_cargo.id;

  SELECT name INTO v_site FROM sites WHERE id = v_cargo.site_id;
  IF p_quantity < v_cargo.meal_unit_count THEN
    INSERT INTO notifications (user_id, title, message, type, link)
    VALUES (NULL, 'Livraison incomplète',
      v_cargo.code || ' : ' || p_quantity || '/' || v_cargo.meal_unit_count || ' barquettes livrées à ' || v_site,
      'warning', '/dashboard/cargos');
  END IF;

  SELECT count(*) INTO v_remaining FROM cargos WHERE route_id = v_cargo.route_id AND status = 'in_delivery';
  RETURN json_build_object('status','ok','remaining',v_remaining,'site',v_site);
END;
$$;

CREATE OR REPLACE FUNCTION finish_route(p_route_id uuid) RETURNS json
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_role text := get_my_role(); v_remaining int; v_done int;
BEGIN
  IF v_role IS NULL OR v_role NOT IN ('admin','driver') THEN RAISE EXCEPTION 'not_authorized'; END IF;
  IF NOT EXISTS (SELECT 1 FROM delivery_routes WHERE id = p_route_id AND status = 'active'
                 AND (driver_id = auth.uid() OR v_role = 'admin')) THEN
    RETURN json_build_object('status','error','message','Tournée introuvable ou déjà terminée');
  END IF;
  SELECT count(*) FILTER (WHERE status = 'in_delivery'), count(*) FILTER (WHERE status = 'delivered')
  INTO v_remaining, v_done FROM cargos WHERE route_id = p_route_id;
  IF v_remaining > 0 THEN
    RETURN json_build_object('status','error','message',
      v_remaining || ' cargo(s) restent à livrer. Livrez-les ou signalez un incident avant de terminer.');
  END IF;
  UPDATE delivery_routes SET status = 'completed', completed_at = now() WHERE id = p_route_id;
  INSERT INTO notifications (user_id, title, message, type, link)
  VALUES (NULL, 'Tournée terminée', v_done || ' cargo(s) livré(s)', 'success', '/dashboard/cargos');
  RETURN json_build_object('status','ok','delivered',v_done);
END;
$$;

-- ===== Staff management =====
CREATE OR REPLACE FUNCTION admin_update_staff(p_user_id uuid, p_full_name text, p_role text, p_active boolean,
  p_phone text, p_hourly_rate numeric) RETURNS json
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT is_admin() THEN RAISE EXCEPTION 'not_authorized'; END IF;
  IF p_role NOT IN ('admin','cook','preparator','driver','courier') THEN
    RETURN json_build_object('status','error','message','Rôle invalide');
  END IF;
  IF length(trim(COALESCE(p_full_name,''))) = 0 OR length(p_full_name) > 120 THEN
    RETURN json_build_object('status','error','message','Nom invalide');
  END IF;
  IF p_hourly_rate IS NOT NULL AND (p_hourly_rate < 0 OR p_hourly_rate > 1000) THEN
    RETURN json_build_object('status','error','message','Taux horaire invalide');
  END IF;
  IF p_user_id = auth.uid() AND (p_role <> 'admin' OR NOT p_active) THEN
    RETURN json_build_object('status','error','message','Vous ne pouvez pas retirer vos propres droits administrateur');
  END IF;
  UPDATE profiles SET full_name = trim(p_full_name), role = p_role, active = p_active,
    phone = NULLIF(trim(COALESCE(p_phone,'')), ''), hourly_rate = COALESCE(p_hourly_rate, hourly_rate)
  WHERE id = p_user_id;
  IF NOT FOUND THEN RETURN json_build_object('status','error','message','Employé introuvable'); END IF;
  RETURN json_build_object('status','ok');
END;
$$;

DO $$
DECLARE f text;
BEGIN
  FOREACH f IN ARRAY ARRAY['open_cargo(uuid,text)','process_scan(text,uuid,uuid,text,uuid)','close_cargo(uuid)',
    'load_cargos(uuid[])','start_route()','deliver_cargo(uuid,int,text,text)','finish_route(uuid)',
    'admin_update_staff(uuid,text,text,boolean,text,numeric)'] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon', f);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated', f);
  END LOOP;
END $$;
REVOKE EXECUTE ON FUNCTION paris_today() FROM anon;
