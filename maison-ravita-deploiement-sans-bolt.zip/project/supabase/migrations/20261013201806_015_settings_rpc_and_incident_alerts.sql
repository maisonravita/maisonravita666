/*
# Paramètres appliqués côté serveur + alerte incident

1. New functions
- `admin_save_settings(p_settings jsonb, p_sites jsonb)`: admin only. Validates every numeric
  setting (budget, production midi/soir, cargo capacity, TVA) against sane bounds and updates
  site capacities in `sites` in one call. Returns `{status, message}`.
- `notify_admin_incident()` trigger function + trigger on `incidents` AFTER INSERT: creates an
  admin notification (user_id NULL) so the admin is alerted when a driver reports an incident.

2. Security
- Both functions are SECURITY DEFINER with fixed search_path.
- EXECUTE on `admin_save_settings` revoked from PUBLIC/anon, granted to authenticated
  (role checked inside). The trigger function is not callable by clients.

3. Notes
- Legacy keys `site1_capacity` / `site2_capacity` are kept in sync with the first two sites
  by name so older readers stay coherent; the source of truth is `sites.capacity`.
*/

CREATE OR REPLACE FUNCTION admin_save_settings(p_settings jsonb, p_sites jsonb)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_rules jsonb := '{
    "budget_per_barquette": [0.10, 20],
    "daily_production_midi": [0, 5000],
    "daily_production_soir": [0, 5000],
    "cargo_max_capacity": [1, 500],
    "tva_rate": [0, 30]
  }'::jsonb;
  v_key text;
  v_raw text;
  v_num numeric;
  v_site jsonb;
  v_cap int;
  v_labels jsonb := '{
    "budget_per_barquette": "Budget par barquette",
    "daily_production_midi": "Production midi",
    "daily_production_soir": "Production soir",
    "cargo_max_capacity": "Capacité par cargo",
    "tva_rate": "Taux de TVA"
  }'::jsonb;
BEGIN
  IF NOT is_admin() THEN RAISE EXCEPTION 'not_authorized'; END IF;
  IF jsonb_typeof(p_settings) <> 'object' OR jsonb_typeof(p_sites) <> 'array' THEN
    RETURN json_build_object('status','error','message','Données invalides');
  END IF;

  FOR v_key IN SELECT jsonb_object_keys(p_settings) LOOP
    IF NOT v_rules ? v_key THEN
      RETURN json_build_object('status','error','message','Paramètre inconnu');
    END IF;
    v_raw := p_settings ->> v_key;
    BEGIN
      v_num := v_raw::numeric;
    EXCEPTION WHEN others THEN
      RETURN json_build_object('status','error','message', (v_labels->>v_key) || ' : valeur invalide');
    END;
    IF v_num < (v_rules->v_key->>0)::numeric OR v_num > (v_rules->v_key->>1)::numeric THEN
      RETURN json_build_object('status','error','message',
        (v_labels->>v_key) || ' doit être entre ' || (v_rules->v_key->>0) || ' et ' || (v_rules->v_key->>1));
    END IF;
    IF v_key IN ('daily_production_midi','daily_production_soir','cargo_max_capacity') AND v_num <> trunc(v_num) THEN
      RETURN json_build_object('status','error','message', (v_labels->>v_key) || ' doit être un nombre entier');
    END IF;
  END LOOP;

  FOR v_site IN SELECT * FROM jsonb_array_elements(p_sites) LOOP
    BEGIN
      v_cap := (v_site->>'capacity')::int;
    EXCEPTION WHEN others THEN
      RETURN json_build_object('status','error','message','Capacité de site invalide');
    END;
    IF v_cap IS NULL OR v_cap < 0 OR v_cap > 5000 THEN
      RETURN json_build_object('status','error','message','La capacité d''un site doit être entre 0 et 5000');
    END IF;
  END LOOP;

  FOR v_key IN SELECT jsonb_object_keys(p_settings) LOOP
    UPDATE settings SET value = (p_settings->>v_key)::numeric::text WHERE key = v_key;
    IF NOT FOUND THEN
      INSERT INTO settings (key, value) VALUES (v_key, (p_settings->>v_key)::numeric::text);
    END IF;
  END LOOP;

  FOR v_site IN SELECT * FROM jsonb_array_elements(p_sites) LOOP
    UPDATE sites SET capacity = (v_site->>'capacity')::int WHERE id = (v_site->>'id')::uuid;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'site_not_found';
    END IF;
  END LOOP;

  UPDATE settings SET value = (SELECT capacity::text FROM sites WHERE name = 'Site 1')
    WHERE key = 'site1_capacity' AND EXISTS (SELECT 1 FROM sites WHERE name = 'Site 1');
  UPDATE settings SET value = (SELECT capacity::text FROM sites WHERE name = 'Site 2')
    WHERE key = 'site2_capacity' AND EXISTS (SELECT 1 FROM sites WHERE name = 'Site 2');

  RETURN json_build_object('status','ok');
END;
$$;

REVOKE ALL ON FUNCTION admin_save_settings(jsonb, jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_save_settings(jsonb, jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION notify_admin_incident()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_driver text;
  v_label text;
BEGIN
  SELECT full_name INTO v_driver FROM profiles WHERE id = NEW.driver_id;
  v_label := CASE NEW.type
    WHEN 'delay' THEN 'Retard'
    WHEN 'missing_cargo' THEN 'Cargo manquant'
    WHEN 'damaged' THEN 'Marchandise endommagée'
    WHEN 'wrong_destination' THEN 'Mauvaise destination'
    WHEN 'wrong_quantity' THEN 'Quantité incorrecte'
    WHEN 'transport_incident' THEN 'Incident de transport'
    ELSE 'Autre incident' END;
  INSERT INTO notifications (user_id, title, message, type, link)
  VALUES (NULL, 'Incident livraison : ' || v_label,
          COALESCE(v_driver, 'Un livreur') || ' — ' || left(COALESCE(NEW.description, ''), 200),
          'warning', '/dashboard/cargos');
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION notify_admin_incident() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_notify_admin_incident ON incidents;
CREATE TRIGGER trg_notify_admin_incident
  AFTER INSERT ON incidents
  FOR EACH ROW EXECUTE FUNCTION notify_admin_incident();
