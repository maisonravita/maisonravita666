/*
# Cleaner quantities in shopping list reasons

1. New Functions
- `fmt_qty(numeric)`: formats a quantity without trailing zeros (0 -> "0", 2.50 -> "2.5").
2. Modified Functions
- `refresh_shopping_item` now uses `fmt_qty` in the reason text. Logic unchanged.
3. Security
- Both functions remain non-callable by clients.
*/

CREATE OR REPLACE FUNCTION fmt_qty(p numeric)
RETURNS text
LANGUAGE sql IMMUTABLE SET search_path = public
AS $$ SELECT rtrim(rtrim(to_char(p, 'FM999999990.00'), '0'), '.') $$;

CREATE OR REPLACE FUNCTION refresh_shopping_item(p_ingredient_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  ing ingredients%ROWTYPE;
  v_days int;
  v_halal boolean;
  v_need numeric;
  v_need_soon numeric;
  v_stock numeric;
  v_to_buy numeric;
  v_priority text;
  v_reason text;
  v_existing uuid;
BEGIN
  SELECT * INTO ing FROM ingredients WHERE id = p_ingredient_id;
  IF NOT FOUND THEN RETURN 'none'; END IF;

  SELECT COALESCE(NULLIF(value, '')::int, 7) INTO v_days FROM settings WHERE key = 'shopping_horizon_days';
  v_days := LEAST(GREATEST(COALESCE(v_days, 7), 1), 31);
  SELECT COALESCE(value, '') LIKE '%halal%' INTO v_halal FROM settings WHERE key = 'diet_restrictions';

  SELECT
    COALESCE(sum(ri.quantity_per_portion * GREATEST(m.quantity - p.done, 0)), 0),
    COALESCE(sum(ri.quantity_per_portion * GREATEST(m.quantity - p.done, 0)) FILTER (WHERE m.date <= current_date + 1), 0)
  INTO v_need, v_need_soon
  FROM menus m
  JOIN recipe_ingredients ri ON ri.recipe_id = m.recipe_id AND ri.ingredient_id = p_ingredient_id
  CROSS JOIN LATERAL (
    SELECT count(*) AS done FROM meal_units mu
    WHERE mu.recipe_id = m.recipe_id AND mu.service = m.service
      AND mu.scanned_at >= m.date AND mu.scanned_at < m.date + 1
  ) p
  WHERE m.date BETWEEN current_date AND current_date + v_days - 1;

  SELECT COALESCE(sum(quantity), 0) INTO v_stock
  FROM stock_lots WHERE ingredient_id = p_ingredient_id AND quantity > 0;

  v_to_buy := ceil((v_need + COALESCE(ing.alert_threshold, 0) - v_stock) * 100) / 100;

  SELECT id INTO v_existing FROM shopping_items
  WHERE ingredient_id = p_ingredient_id AND status = 'pending';

  IF v_to_buy <= 0 THEN
    IF v_existing IS NOT NULL THEN
      DELETE FROM shopping_items WHERE id = v_existing
        AND NOT EXISTS (SELECT 1 FROM purchases WHERE shopping_item_id = v_existing);
      RETURN 'removed';
    END IF;
    RETURN 'none';
  END IF;

  v_priority := CASE
    WHEN v_stock < v_need_soon THEN 'high'
    WHEN v_stock < v_need THEN 'medium'
    ELSE 'low'
  END;

  v_reason := CASE
    WHEN v_need > 0 THEN 'Menus des ' || v_days || ' prochains jours : '
      || fmt_qty(v_need) || ' ' || ing.unit || ' nécessaires, ' || fmt_qty(v_stock) || ' en stock'
    WHEN v_stock <= 0 THEN 'Rupture de stock'
    ELSE 'Sous le seuil d''alerte (' || fmt_qty(ing.alert_threshold) || ' ' || ing.unit || ')'
  END;

  INSERT INTO shopping_items (ingredient_id, quantity_needed, unit, priority, status, estimated_price, supplier, reason, halal_required)
  VALUES (p_ingredient_id, v_to_buy, ing.unit, v_priority, 'pending',
          round(v_to_buy * ing.price, 2), ing.supplier, v_reason,
          v_halal AND ing.category = 'viandes')
  ON CONFLICT (ingredient_id) WHERE status = 'pending'
  DO UPDATE SET quantity_needed = EXCLUDED.quantity_needed,
                priority = EXCLUDED.priority,
                estimated_price = EXCLUDED.estimated_price,
                reason = EXCLUDED.reason,
                halal_required = EXCLUDED.halal_required;

  RETURN CASE WHEN v_existing IS NULL THEN 'created' ELSE 'updated' END;
END;
$$;

REVOKE EXECUTE ON FUNCTION refresh_shopping_item(uuid) FROM PUBLIC, anon, authenticated;
