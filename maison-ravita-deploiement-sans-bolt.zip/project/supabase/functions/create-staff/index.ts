import { createClient } from "npm:@supabase/supabase-js@2.58.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const ROLES = ["admin", "cook", "preparator", "driver", "courier"];

function reply(body: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  try {
    if (req.method !== "POST") return reply({ status: "error", message: "Méthode non autorisée" }, 405);

    const url = Deno.env.get("SUPABASE_URL")!;
    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
      auth: { persistSession: false },
    });

    const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data: caller, error: callerError } = await admin.auth.getUser(token);
    if (callerError || !caller.user) return reply({ status: "error", message: "Non connecté" }, 401);

    const { data: callerProfile } = await admin
      .from("profiles")
      .select("role, active")
      .eq("id", caller.user.id)
      .maybeSingle();
    if (!callerProfile || callerProfile.role !== "admin" || !callerProfile.active) {
      return reply({ status: "error", message: "Accès réservé à l'administrateur" }, 403);
    }

    const body = await req.json().catch(() => null);
    const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
    const fullName = typeof body?.full_name === "string" ? body.full_name.trim() : "";
    const role = typeof body?.role === "string" ? body.role : "";
    const password = typeof body?.password === "string" ? body.password : "";
    const phone = typeof body?.phone === "string" ? body.phone.trim().slice(0, 30) : "";

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 200) {
      return reply({ status: "error", message: "Adresse e-mail invalide" }, 400);
    }
    if (fullName.length < 2 || fullName.length > 120) {
      return reply({ status: "error", message: "Nom invalide" }, 400);
    }
    if (!ROLES.includes(role)) return reply({ status: "error", message: "Rôle invalide" }, 400);
    if (password.length < 8 || password.length > 72) {
      return reply({ status: "error", message: "Le mot de passe doit contenir 8 caractères minimum" }, 400);
    }

    const { data: created, error: createError } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName },
      app_metadata: { invited: true, role },
    });
    if (createError || !created.user) {
      const exists = /already|registered|exists/i.test(createError?.message ?? "");
      console.error("createUser failed", createError);
      return reply(
        { status: "error", message: exists ? "Un compte existe déjà avec cet e-mail" : "Création du compte impossible" },
        exists ? 409 : 500,
      );
    }

    const { error: profileError } = await admin.from("profiles").upsert({
      id: created.user.id,
      email,
      full_name: fullName,
      role,
      active: true,
      phone: phone || null,
    });
    if (profileError) {
      console.error("profile upsert failed", profileError);
      await admin.auth.admin.deleteUser(created.user.id);
      return reply({ status: "error", message: "Création du compte impossible" }, 500);
    }

    return reply({ status: "ok", id: created.user.id });
  } catch (err) {
    console.error(err);
    return reply({ status: "error", message: "Erreur serveur" }, 500);
  }
});
