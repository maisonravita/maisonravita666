# Maison Ravita — Déploiement sans Bolt.new

## 1. Installer sur Mac

Installer Node.js 20 ou 22, puis dans le dossier `project` :

```bash
npm ci
cp .env.example .env.local
```

Remplir `.env.local` avec l’URL et la clé **publique anon** de votre projet Supabase. Ne jamais mettre une clé `service_role` dans une variable `NEXT_PUBLIC_`.

```bash
npm run typecheck
npm run dev
```

Ouvrir http://localhost:3000.

## 2. Base Supabase

Les fichiers SQL sont dans `supabase/migrations/`. Vérifier les migrations déjà appliquées avant toute exécution, notamment `20261014110000_017_driver_cargo_receipt.sql`. Effectuer une sauvegarde avant migration. Déployer séparément les fonctions Edge dans `supabase/functions/`. Les fonctionnalités d’ajout d’employés peuvent en dépendre.

## 3. GitHub + Vercel

Créer un dépôt GitHub privé, y importer le dossier `project` (sans `.env.local` ni secrets), puis créer un projet Vercel depuis le dépôt. Dans Vercel, définir `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Déployer.

## 4. À vérifier avant utilisation réelle

- Authentification des cinq rôles et politiques RLS Supabase.
- Validation des menus et affichage chez le cuisinier.
- Réception des marchandises, stocks et déduction unique des ingrédients.
- Scan QR et prévention des doublons entre deux téléphones.
- Réception, chargement et livraison de plusieurs cargos avec photos.
- Téléversement sécurisé des photos et contrôle des accès.
- Fonctionnement des paramètres et des factures.

## 5. Limites

Ce ZIP est une préparation de déploiement, pas un déploiement effectué. La compilation et les tests de bout en bout ne sont pas certifiés. Le suivi GPS continu en arrière-plan n’est pas garanti par une PWA.
