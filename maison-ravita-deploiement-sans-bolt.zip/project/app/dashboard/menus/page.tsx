'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase, type Menu } from '@/lib/supabase';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Sparkles,
  CheckCircle2,
  Loader2,
  RefreshCw,
  UtensilsCrossed,
  ChevronLeft,
  ChevronRight,
  Sun,
  Moon,
  Boxes,
  Euro,
  CalendarCheck,
  AlertCircle,
  ShieldCheck,
  ShieldAlert,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import {
  loadPlanningData,
  syncRecipeCatalog,
  refreshRecipeCosts,
  eligibleRecipes,
  saveRestrictions,
  refreshShoppingList,
  type PlanningData,
  type RecipeWithLines,
} from '@/lib/menu-planning';
import {
  planWeek,
  pickRecipe,
  stockCoverage,
  type GenerationMode,
  type Slot,
} from '@/lib/menu-generator';
import { GenerateDialog } from '@/components/menus/generate-dialog';
import { RecipeSheet } from '@/components/menus/recipe-sheet';
import { DIET_OPTIONS, describeIssues, type DietRestriction } from '@/lib/diet';

const DAY_NAMES = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
const SERVICES = ['midi', 'soir'] as const;
const PROTEIN_LABELS: Record<string, string> = {
  poulet: 'Volaille',
  boeuf: 'Boeuf',
  porc: 'Porc',
  poisson: 'Poisson',
  oeuf: 'Oeuf',
  vegetarien: 'Végétarien',
};

const toKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

function weekDays(offset: number): Date[] {
  const today = new Date();
  const monday = new Date(today.getFullYear(), today.getMonth(), today.getDate() - ((today.getDay() + 6) % 7) + offset * 7);
  return Array.from({ length: 7 }, (_, i) => new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + i));
}

export default function MenusPage() {
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin';
  const [weekOffset, setWeekOffset] = useState(0);
  const [menus, setMenus] = useState<Menu[]>([]);
  const [planning, setPlanning] = useState<PlanningData | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [lastMode, setLastMode] = useState<GenerationMode>('libre');
  const [busyMenu, setBusyMenu] = useState<string | null>(null);
  const [sheet, setSheet] = useState<{ recipe: RecipeWithLines; portions: number } | null>(null);

  const dates = useMemo(() => weekDays(weekOffset), [weekOffset]);
  const startKey = toKey(dates[0]);
  const endKey = toKey(dates[6]);

  const load = useCallback(async () => {
    setLoadError(null);
    try {
      const [menusRes, data] = await Promise.all([
        supabase.from('menus').select('*').gte('date', startKey).lte('date', endKey),
        loadPlanningData(),
      ]);
      if (menusRes.error) throw new Error(menusRes.error.message);
      setMenus((menusRes.data ?? []) as Menu[]);
      setPlanning(data);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Chargement impossible');
    }
    setLoading(false);
  }, [startKey, endKey]);

  useEffect(() => {
    setLoading(true);
    load();
  }, [load]);

  const recipeById = useMemo(
    () => new Map((planning?.recipes ?? []).map((r) => [r.id, r])),
    [planning]
  );

  const menuAt = (date: string, service: 'midi' | 'soir') =>
    menus.find((m) => m.date === date && m.service === service && !m.site_id);

  const stats = useMemo(() => {
    const planned = menus.map((m) => recipeById.get(m.recipe_id)).filter(Boolean) as RecipeWithLines[];
    const avg = planned.length ? planned.reduce((s, r) => s + r.cost, 0) / planned.length : 0;
    return {
      planned: planned.length,
      validated: menus.filter((m) => m.status === 'validated').length,
      avgCost: avg,
    };
  }, [menus, recipeById]);

  const stockedCount = planning
    ? Array.from(planning.stock.values()).filter((q) => q > 0).length
    : 0;

  const syncShopping = async (): Promise<number> => {
    try {
      return await refreshShoppingList();
    } catch (err) {
      console.error('shopping refresh failed', err);
      return 0;
    }
  };

  const generate = async (mode: GenerationMode, replaceDrafts: boolean, restrictions: DietRestriction[]) => {
    if (!planning) return;
    setGenerating(true);
    try {
      const restrictionsChanged =
        restrictions.length !== planning.restrictions.length ||
        restrictions.some((r) => !planning.restrictions.includes(r));
      if (restrictionsChanged) await saveRestrictions(restrictions);
      const created = await syncRecipeCatalog(planning);
      const fresh = created > 0 || restrictionsChanged ? await loadPlanningData() : planning;
      await refreshRecipeCosts(fresh.recipes);
      const pool = eligibleRecipes(fresh);
      if (pool.length === 0) {
        throw new Error(
          `Aucune recette ne respecte à la fois le budget de ${fresh.budget.toFixed(2)} € et les restrictions choisies.`
        );
      }

      if (replaceDrafts) {
        const { error } = await supabase
          .from('menus')
          .delete()
          .gte('date', startKey)
          .lte('date', endKey)
          .eq('status', 'draft')
          .is('site_id', null);
        if (error) throw new Error(error.message);
      }

      const kept = menus.filter((m) => !m.site_id && (m.status !== 'draft' || !replaceDrafts));
      const freshById = new Map(fresh.recipes.map((r) => [r.id, r]));
      const locked = new Map<string, RecipeWithLines>();
      kept.forEach((m) => {
        const r = freshById.get(m.recipe_id);
        if (r) locked.set(`${m.date}|${m.service}`, r);
      });
      const occupied = new Set(kept.map((m) => `${m.date}|${m.service}`));

      const slots: Slot[] = dates.flatMap((d) =>
        SERVICES.map((service) => ({ date: toKey(d), service, portions: fresh.portions[service] }))
      );
      const effectiveMode = mode === 'stock' && stockedCount === 0 ? 'libre' : mode;
      const plan = planWeek(pool, slots, effectiveMode, fresh.stock, locked).filter(
        (p) => !occupied.has(`${p.date}|${p.service}`)
      );

      if (plan.length > 0) {
        const { error } = await supabase.from('menus').insert(
          plan.map((p) => ({
            date: p.date,
            service: p.service,
            recipe_id: p.recipe_id,
            quantity: p.portions,
            status: 'draft',
          }))
        );
        if (error) throw new Error(error.message);
      }

      setLastMode(effectiveMode);
      setDialogOpen(false);
      const toBuy = await syncShopping();
      const avgCoverage = plan.length ? plan.reduce((s, p) => s + p.coverage, 0) / plan.length : 0;
      const shoppingNote = toBuy > 0 ? ` ${toBuy} produit(s) ajouté(s) à la liste de courses.` : '';
      toast({
        title: plan.length ? `${plan.length} plats générés` : 'Semaine déjà complète',
        description:
          (effectiveMode === 'stock'
            ? `Couverture moyenne par le stock : ${Math.round(avgCoverage * 100)} %. Pensez à valider.`
            : 'Composition libre sous budget. Pensez à valider les plats.') + shoppingNote,
      });
      await load();
    } catch (err) {
      toast({
        title: 'Génération impossible',
        description: err instanceof Error ? err.message : 'Erreur inconnue',
        variant: 'destructive',
      });
    }
    setGenerating(false);
  };

  const validateMenu = async (menu: Menu) => {
    if (!profile) return;
    setBusyMenu(menu.id);
    const { error } = await supabase
      .from('menus')
      .update({ status: 'validated', validated_by: profile.id, validated_at: new Date().toISOString() })
      .eq('id', menu.id);
    setBusyMenu(null);
    if (error) {
      toast({ title: 'Validation impossible', description: error.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Plat validé', description: 'Il est maintenant visible en cuisine.' });
    load();
  };

  const validateWeek = async () => {
    if (!profile) return;
    const ids = menus.filter((m) => m.status === 'draft').map((m) => m.id);
    if (ids.length === 0) return;
    const { error } = await supabase
      .from('menus')
      .update({ status: 'validated', validated_by: profile.id, validated_at: new Date().toISOString() })
      .in('id', ids);
    if (error) {
      toast({ title: 'Validation impossible', description: error.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Semaine validée', description: `${ids.length} plats validés.` });
    load();
  };

  const regenerateMenu = async (menu: Menu) => {
    if (!planning) return;
    const pool = eligibleRecipes(planning);
    const sameDay = menus.filter((m) => m.date === menu.date && m.id !== menu.id);
    const usage = new Map<string, number>();
    menus.forEach((m) => usage.set(m.recipe_id, (usage.get(m.recipe_id) ?? 0) + 1));
    const pick = pickRecipe(pool, { date: menu.date, service: menu.service, portions: menu.quantity }, {
      mode: lastMode,
      stock: planning.stock,
      usage,
      avoidProteins: sameDay.map((m) => recipeById.get(m.recipe_id)?.main_protein ?? ''),
      excludeId: menu.recipe_id,
    });
    if (!pick) {
      toast({ title: 'Aucune autre recette sous budget', variant: 'destructive' });
      return;
    }
    setBusyMenu(menu.id);
    const { error } = await supabase.from('menus').update({ recipe_id: pick.recipe.id }).eq('id', menu.id);
    setBusyMenu(null);
    if (error) {
      toast({ title: 'Changement impossible', description: error.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Plat remplacé', description: pick.recipe.name });
    syncShopping();
    load();
  };

  const todayKey = toKey(new Date());
  const activeDiets = DIET_OPTIONS.filter((o) => planning?.restrictions.includes(o.id));

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold">Menus & Recettes</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Programme de la semaine, sous {planning ? planning.budget.toFixed(2) : '1.50'} € par barquette
          </p>
          {activeDiets.length > 0 && (
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-emerald-600" />
              {activeDiets.map((d) => (
                <Badge key={d.id} variant="outline" className="border-emerald-300 text-emerald-700">
                  {d.label}
                </Badge>
              ))}
            </div>
          )}
        </div>
        {isAdmin && (
          <div className="flex gap-2">
            {menus.some((m) => m.status === 'draft') && (
              <Button variant="outline" onClick={validateWeek}>
                <CalendarCheck className="mr-2 h-4 w-4" />
                Tout valider
              </Button>
            )}
            <Button onClick={() => setDialogOpen(true)} disabled={!planning}>
              <Sparkles className="mr-2 h-4 w-4" />
              Générer la semaine
            </Button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-3 gap-3">
        {[
          { icon: UtensilsCrossed, label: 'Plats prévus', value: `${stats.planned}/14` },
          { icon: CheckCircle2, label: 'Validés', value: `${stats.validated}` },
          { icon: Euro, label: 'Coût moyen', value: stats.planned ? `${stats.avgCost.toFixed(2)} €` : '—' },
        ].map(({ icon: Icon, label, value }) => (
          <Card key={label}>
            <CardContent className="flex flex-col gap-1 p-4 sm:flex-row sm:items-center sm:gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Icon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="text-lg font-bold">{value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex items-center justify-between rounded-xl border bg-card px-2 py-1">
        <Button variant="ghost" size="icon" onClick={() => setWeekOffset(weekOffset - 1)} aria-label="Semaine précédente">
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <button className="text-sm font-semibold" onClick={() => setWeekOffset(0)}>
          {dates[0].toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })} —{' '}
          {dates[6].toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}
        </button>
        <Button variant="ghost" size="icon" onClick={() => setWeekOffset(weekOffset + 1)} aria-label="Semaine suivante">
          <ChevronRight className="h-5 w-5" />
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : loadError || !planning ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
            <AlertCircle className="h-8 w-8 text-destructive" />
            <p className="text-sm text-muted-foreground">{loadError ?? 'Chargement impossible'}</p>
            <Button variant="outline" onClick={() => { setLoading(true); load(); }}>Réessayer</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-5">
          {dates.map((date, i) => {
            const key = toKey(date);
            return (
              <section key={key}>
                <h2 className={cn('mb-2 text-sm font-semibold', key === todayKey && 'text-primary')}>
                  {DAY_NAMES[i]} {date.getDate()}
                  {key === todayKey && <span className="ml-2 text-xs font-medium">Aujourd’hui</span>}
                </h2>
                <div className="grid gap-3 sm:grid-cols-2">
                  {SERVICES.map((service) => {
                    const menu = menuAt(key, service);
                    const recipe = menu ? recipeById.get(menu.recipe_id) : undefined;
                    const portions = menu?.quantity ?? planning.portions[service];
                    const coverage = recipe ? stockCoverage(recipe, planning.stock, portions) : 0;
                    const ServiceIcon = service === 'midi' ? Sun : Moon;
                    return (
                      <Card
                        key={service}
                        className={cn('transition-shadow hover:shadow-md', !menu && 'border-dashed bg-muted/20')}
                      >
                        <CardContent className="p-4">
                          <div className="mb-3 flex items-center justify-between">
                            <span className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                              <ServiceIcon className="h-4 w-4" />
                              {service} · {portions} portions
                            </span>
                            {menu && (
                              <Badge
                                variant={menu.status === 'validated' ? 'default' : 'secondary'}
                                className={menu.status === 'validated' ? 'bg-emerald-600 hover:bg-emerald-600' : ''}
                              >
                                {menu.status === 'validated' ? 'Validé' : 'Brouillon'}
                              </Badge>
                            )}
                          </div>

                          {recipe ? (
                            <>
                              <button
                                className="text-left font-semibold leading-snug hover:text-primary"
                                onClick={() => setSheet({ recipe, portions })}
                              >
                                {recipe.name}
                              </button>
                              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                                <Badge variant="outline" className="text-xs">
                                  {recipe.cost.toFixed(2)} €
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                  {PROTEIN_LABELS[recipe.main_protein] ?? recipe.main_protein}
                                </Badge>
                                {recipe.diet.length > 0 ? (
                                  <Badge
                                    variant="outline"
                                    title={describeIssues(recipe.diet)}
                                    className="gap-1 border-red-300 bg-red-50 text-xs text-red-700"
                                  >
                                    <ShieldAlert className="h-3 w-3" />
                                    Non conforme
                                  </Badge>
                                ) : (
                                  activeDiets.length > 0 && (
                                    <Badge variant="outline" className="gap-1 border-emerald-300 text-xs text-emerald-700">
                                      <ShieldCheck className="h-3 w-3" />
                                      {activeDiets.map((d) => d.label).join(' · ')}
                                    </Badge>
                                  )
                                )}
                                {recipe.lines.length > 0 && (
                                  <Badge
                                    variant="outline"
                                    className={cn(
                                      'gap-1 text-xs',
                                      coverage >= 0.999
                                        ? 'border-emerald-300 text-emerald-700'
                                        : coverage > 0
                                          ? 'border-amber-300 text-amber-700'
                                          : 'text-muted-foreground'
                                    )}
                                  >
                                    <Boxes className="h-3 w-3" />
                                    Stock {Math.round(coverage * 100)} %
                                  </Badge>
                                )}
                              </div>
                              <div className="mt-3 flex gap-2">
                                {isAdmin && menu?.status === 'draft' && (
                                  <Button size="sm" className="h-8" disabled={busyMenu === menu.id} onClick={() => validateMenu(menu)}>
                                    <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                                    Valider
                                  </Button>
                                )}
                                <Button size="sm" variant="ghost" className="h-8" onClick={() => setSheet({ recipe, portions })}>
                                  <UtensilsCrossed className="mr-1 h-3.5 w-3.5" />
                                  Fiche
                                </Button>
                                {isAdmin && menu?.status === 'draft' && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-8"
                                    disabled={busyMenu === menu.id}
                                    onClick={() => regenerateMenu(menu)}
                                    aria-label="Changer de plat"
                                  >
                                    <RefreshCw className={cn('h-3.5 w-3.5', busyMenu === menu.id && 'animate-spin')} />
                                  </Button>
                                )}
                              </div>
                            </>
                          ) : (
                            <p className="py-3 text-center text-sm text-muted-foreground">Aucun plat prévu</p>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>
      )}

      {dialogOpen && planning && (
        <GenerateDialog
          open={dialogOpen}
          onOpenChange={(o) => !generating && setDialogOpen(o)}
          onConfirm={generate}
          generating={generating}
          planning={planning}
          stockedIngredients={stockedCount}
        />
      )}

      {sheet && planning && (
        <RecipeSheet
          recipe={sheet.recipe}
          portions={sheet.portions}
          data={planning}
          onClose={() => setSheet(null)}
        />
      )}
    </div>
  );
}
