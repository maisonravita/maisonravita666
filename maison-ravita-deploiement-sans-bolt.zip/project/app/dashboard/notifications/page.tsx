'use client';

import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase, type Notification, type Request as RequestItem } from '@/lib/supabase';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, Loader2, CheckCircle2, AlertTriangle, XCircle, Info, RefreshCw } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { failMessage } from '@/lib/rpc';

const STATUS_LABELS: Record<string, string> = {
  sent: 'Envoyée',
  viewed: 'Vue',
  processing: 'En traitement',
  resolved: 'Résolue',
  rejected: 'Refusée',
};

const URGENCY_COLORS: Record<string, string> = {
  low: 'bg-muted text-muted-foreground',
  medium: 'bg-blue-100 text-blue-700',
  high: 'bg-warning/10 text-warning',
  critical: 'bg-destructive/10 text-destructive',
};

export default function NotificationsPage() {
  const { profile } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [requests, setRequests] = useState<(RequestItem & { profiles: { full_name: string } | null })[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [tab, setTab] = useState<'notifications' | 'requests'>('requests');

  const loadData = useCallback(async () => {
    if (!profile) return;
    const [notifRes, reqRes] = await Promise.all([
      supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(50),
      profile.role === 'admin'
        ? supabase.from('requests').select('*, profiles!requests_user_profile_fkey(full_name)').order('created_at', { ascending: false }).limit(50)
        : supabase.from('requests').select('*, profiles!requests_user_profile_fkey(full_name)').eq('user_id', profile.id).order('created_at', { ascending: false }).limit(50),
    ]);
    if (notifRes.error || reqRes.error) {
      setLoadError(failMessage(notifRes.error ?? reqRes.error));
      setLoading(false);
      return;
    }
    setLoadError(null);
    setNotifications((notifRes.data ?? []) as Notification[]);
    setRequests((reqRes.data ?? []) as unknown as (RequestItem & { profiles: { full_name: string } | null })[]);
    setLoading(false);
  }, [profile]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const markRead = async (id: string) => {
    setBusyId(id);
    const { data, error } = await supabase.from('notifications').update({ read: true }).eq('id', id).select('id');
    setBusyId(null);
    if (error || !data?.length) {
      toast({ title: 'Impossible de marquer comme lu', description: failMessage(error), variant: 'destructive' });
      return;
    }
    loadData();
  };

  const updateRequestStatus = async (id: string, status: 'viewed' | 'processing' | 'resolved' | 'rejected') => {
    setBusyId(id);
    const { data, error } = await supabase
      .from('requests')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('id');
    setBusyId(null);
    if (error || !data?.length) {
      toast({ title: 'Mise à jour impossible', description: failMessage(error), variant: 'destructive' });
      return;
    }
    toast({ title: 'Demande mise à jour', description: STATUS_LABELS[status] });
    loadData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (loadError) {
    return (
      <Card className="border-destructive/30">
        <CardContent className="pt-6 flex flex-col items-center text-center gap-3">
          <AlertTriangle className="w-8 h-8 text-destructive" />
          <p className="text-sm">{loadError}</p>
          <Button variant="outline" onClick={() => { setLoading(true); loadData(); }}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Réessayer
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Notifications & Demandes</h1>
        <p className="text-sm text-muted-foreground mt-1">Suivi des alertes et demandes</p>
      </div>

      <div className="flex gap-2">
        <button
          onClick={() => setTab('requests')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
            tab === 'requests' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
          }`}
        >
          Demandes ({requests.length})
        </button>
        <button
          onClick={() => setTab('notifications')}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
            tab === 'notifications' ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
          }`}
        >
          Notifications ({notifications.filter((n) => !n.read).length})
        </button>
      </div>

      {tab === 'requests' && (
        <div className="space-y-3">
          {requests.length === 0 ? (
            <Card>
              <CardContent className="pt-10 pb-10 text-center">
                <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">Aucune demande</p>
              </CardContent>
            </Card>
          ) : (
            requests.map((req) => (
              <Card key={req.id}>
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-sm">{req.category}</span>
                        <Badge className={`text-xs ${URGENCY_COLORS[req.urgency]}`}>
                          {req.urgency}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{req.description}</p>
                      {req.profiles?.full_name && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Par {req.profiles.full_name}
                        </p>
                      )}
                    </div>
                    <Badge variant="outline" className="shrink-0">
                      {STATUS_LABELS[req.status] ?? req.status}
                    </Badge>
                  </div>
                  {profile?.role === 'admin' && req.status !== 'resolved' && req.status !== 'rejected' && (
                    <div className="flex gap-2 flex-wrap">
                      <Button size="sm" variant="outline" disabled={busyId === req.id} onClick={() => updateRequestStatus(req.id, 'processing')}>
                        En traitement
                      </Button>
                      <Button size="sm" disabled={busyId === req.id} onClick={() => updateRequestStatus(req.id, 'resolved')}>
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Résoudre
                      </Button>
                      <Button size="sm" variant="ghost" disabled={busyId === req.id} onClick={() => updateRequestStatus(req.id, 'rejected')}>
                        <XCircle className="w-3 h-3 mr-1" />
                        Refuser
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {tab === 'notifications' && (
        <div className="space-y-3">
          {notifications.length === 0 ? (
            <Card>
              <CardContent className="pt-10 pb-10 text-center">
                <Info className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">Aucune notification</p>
              </CardContent>
            </Card>
          ) : (
            notifications.map((notif) => (
              <Card key={notif.id} className={notif.read ? 'opacity-60' : ''}>
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      {!notif.read && (
                        <div className="w-2 h-2 rounded-full bg-primary mt-2 shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm">{notif.title}</p>
                        <p className="text-sm text-muted-foreground mt-0.5">{notif.message}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(notif.created_at).toLocaleString('fr-FR')}
                        </p>
                      </div>
                    </div>
                    {!notif.read && (
                      <Button variant="ghost" size="sm" disabled={busyId === notif.id} onClick={() => markRead(notif.id)}>
                        Lu
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}
    </div>
  );
}
