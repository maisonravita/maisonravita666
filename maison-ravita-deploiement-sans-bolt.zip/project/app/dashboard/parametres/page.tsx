'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase, type Site } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Settings, Loader2, Save, Euro, Package, MapPin, AlertTriangle, RefreshCw, Info } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { callRpc, failMessage } from '@/lib/rpc';

const FIELDS = [
  { key: 'budget_per_barquette', label: 'Budget par barquette (€)', icon: Euro, step: '0.01',
    hint: 'Plafond utilisé pour générer et valider les recettes.' },
  { key: 'cargo_max_capacity', label: 'Capacité maximale par cargo', icon: Package, step: '1',
    hint: 'Le scan est bloqué quand un cargo atteint cette limite.' },
  { key: 'daily_production_midi', label: 'Barquettes prévues — midi', icon: Package, step: '1',
    hint: 'Quantités des fiches techniques et des listes de courses.' },
  { key: 'daily_production_soir', label: 'Barquettes prévues — soir', icon: Package, step: '1',
    hint: 'Quantités des fiches techniques et des listes de courses.' },
  { key: 'tva_rate', label: 'Taux de TVA (%)', icon: Euro, step: '0.1', hint: 'Taux de référence pour la future facturation clients.' },
] as const;

type FieldKey = (typeof FIELDS)[number]['key'];

function toNumber(value: string) {
  const n = Number(value.replace(',', '.').trim());
  return value.trim() === '' || !Number.isFinite(n) ? null : n;
}

export default function ParametresPage() {
  const [values, setValues] = useState<Record<FieldKey, string>>({} as Record<FieldKey, string>);
  const [sites, setSites] = useState<Site[]>([]);
  const [siteCaps, setSiteCaps] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [settingsRes, sitesRes] = await Promise.all([
      supabase.from('settings').select('key, value'),
      supabase.from('sites').select('*').order('name'),
    ]);
    if (settingsRes.error || sitesRes.error) {
      setLoadError(failMessage(settingsRes.error ?? sitesRes.error));
      setLoading(false);
      return;
    }
    const map = {} as Record<FieldKey, string>;
    (settingsRes.data ?? []).forEach((s: { key: string; value: string }) => {
      if (FIELDS.some((f) => f.key === s.key)) map[s.key as FieldKey] = s.value;
    });
    const siteList = (sitesRes.data ?? []) as Site[];
    setValues(map);
    setSites(siteList);
    setSiteCaps(Object.fromEntries(siteList.map((s) => [s.id, String(s.capacity)])));
    setLoadError(null);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const totalSites = useMemo(
    () => sites.reduce((sum, s) => sum + (toNumber(siteCaps[s.id] ?? '') ?? 0), 0),
    [sites, siteCaps]
  );
  const midi = toNumber(values.daily_production_midi ?? '');
  const soir = toNumber(values.daily_production_soir ?? '');
  const budget = toNumber(values.budget_per_barquette ?? '');
  const mismatch = sites.length > 0 && ((midi !== null && midi !== totalSites) || (soir !== null && soir !== totalSites));

  const handleSave = async () => {
    const settings: Record<string, number> = {};
    for (const field of FIELDS) {
      const n = toNumber(values[field.key] ?? '');
      if (n === null) {
        setFormError(`${field.label} : valeur manquante ou invalide.`);
        return;
      }
      settings[field.key] = n;
    }
    const sitePayload = [];
    for (const site of sites) {
      const n = toNumber(siteCaps[site.id] ?? '');
      if (n === null || !Number.isInteger(n) || n < 0) {
        setFormError(`Capacité de ${site.name} invalide.`);
        return;
      }
      sitePayload.push({ id: site.id, capacity: n });
    }
    setFormError(null);
    setSaving(true);
    const result = await callRpc('admin_save_settings', { p_settings: settings, p_sites: sitePayload });
    setSaving(false);
    if (!result.ok) {
      setFormError(result.message);
      toast({ title: 'Enregistrement refusé', description: result.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Paramètres enregistrés', description: 'Les nouveaux réglages sont appliqués immédiatement.' });
    load();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (loadError) {
    return (
      <Card className="border-destructive/30">
        <CardContent className="pt-6 flex flex-col items-center text-center gap-3">
          <AlertTriangle className="w-8 h-8 text-destructive" />
          <p className="text-sm">{loadError}</p>
          <Button variant="outline" onClick={() => { setLoading(true); load(); }}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Réessayer
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Paramètres</h1>
          <p className="text-sm text-muted-foreground mt-1">Réglages appliqués à toute l&apos;application</p>
        </div>
        <Button onClick={handleSave} disabled={saving}>
          {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          Enregistrer
        </Button>
      </div>

      {formError && (
        <div className="flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          {formError}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Configuration opérationnelle
          </CardTitle>
        </CardHeader>
        <CardContent className="grid sm:grid-cols-2 gap-5">
          {FIELDS.map((field) => {
            const Icon = field.icon;
            return (
              <div key={field.key} className="space-y-2">
                <Label htmlFor={field.key} className="flex items-center gap-2 text-sm">
                  <Icon className="w-3.5 h-3.5 text-muted-foreground" />
                  {field.label}
                </Label>
                <Input
                  id={field.key}
                  type="number"
                  inputMode="decimal"
                  step={field.step}
                  min={0}
                  value={values[field.key] ?? ''}
                  onChange={(e) => setValues({ ...values, [field.key]: e.target.value })}
                />
                <p className="text-xs text-muted-foreground">{field.hint}</p>
              </div>
            );
          })}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Capacité des sites
          </CardTitle>
          <CardDescription>Nombre de barquettes livrées à chaque site par service. Sert d&apos;objectif sur l&apos;écran de préparation.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {sites.length === 0 ? (
            <p className="text-sm text-muted-foreground">Aucun site enregistré.</p>
          ) : (
            <div className="grid sm:grid-cols-2 gap-4">
              {sites.map((site) => (
                <div key={site.id} className="space-y-2">
                  <Label htmlFor={`site-${site.id}`}>{site.name}</Label>
                  <Input
                    id={`site-${site.id}`}
                    type="number"
                    inputMode="numeric"
                    step="1"
                    min={0}
                    value={siteCaps[site.id] ?? ''}
                    onChange={(e) => setSiteCaps({ ...siteCaps, [site.id]: e.target.value })}
                  />
                </div>
              ))}
            </div>
          )}
          <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm">
            <span>Total sites : <strong>{totalSites}</strong> barquettes / service</span>
            {budget !== null && midi !== null && soir !== null && (
              <span>Budget ingrédients journalier : <strong>{(budget * (midi + soir)).toFixed(2).replace('.', ',')} €</strong></span>
            )}
          </div>
          {mismatch && (
            <div className="flex items-start gap-2 rounded-lg bg-amber-50 border border-amber-200 px-3 py-2 text-xs text-amber-900">
              <Info className="w-4 h-4 shrink-0" />
              La production prévue (midi {midi ?? '—'} / soir {soir ?? '—'}) ne correspond pas au total des sites ({totalSites}).
              Vérifiez que c&apos;est voulu.
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">À propos</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>Maison Ravita — Gestion de restauration collective</p>
          <p>Application web responsive et installable (PWA).</p>
        </CardContent>
      </Card>
    </div>
  );
}
