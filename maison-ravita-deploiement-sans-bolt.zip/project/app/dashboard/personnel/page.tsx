'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase, type Profile } from '@/lib/supabase';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Plus, Phone, AlertTriangle, UserCheck, Pencil, RefreshCw } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { roleLabels } from '@/lib/role-nav';
import { callRpc, failMessage } from '@/lib/rpc';
import { cn } from '@/lib/utils';
import { AddStaffDialog } from '@/components/personnel/add-staff-dialog';
import { EditStaffDialog } from '@/components/personnel/edit-staff-dialog';

type Filter = 'all' | 'active' | 'pending';

function initials(name: string) {
  return name.split(' ').filter(Boolean).map((n) => n[0]).join('').toUpperCase().slice(0, 2) || '?';
}

export default function PersonnelPage() {
  const { profile: me } = useAuth();
  const isAdmin = me?.role === 'admin';
  const [staff, setStaff] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [filter, setFilter] = useState<Filter>('all');
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Profile | null>(null);
  const [activating, setActivating] = useState<string | null>(null);

  const loadStaff = useCallback(async () => {
    const { data, error } = await supabase.from('profiles').select('*').order('full_name');
    if (error) {
      setLoadError(failMessage(error));
    } else {
      setStaff((data ?? []) as Profile[]);
      setLoadError(null);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadStaff();
  }, [loadStaff]);

  const pending = useMemo(() => staff.filter((s) => !s.active), [staff]);
  const visible = useMemo(
    () => staff.filter((s) => (filter === 'all' ? true : filter === 'active' ? s.active : !s.active)),
    [staff, filter]
  );

  const activate = async (member: Profile) => {
    setActivating(member.id);
    const result = await callRpc('admin_update_staff', {
      p_user_id: member.id,
      p_full_name: member.full_name,
      p_role: member.role,
      p_active: true,
      p_phone: member.phone ?? '',
      p_hourly_rate: null,
    });
    setActivating(null);
    if (!result.ok) {
      toast({ title: 'Activation impossible', description: result.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Compte activé', description: `${member.full_name} — ${roleLabels[member.role]}` });
    loadStaff();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (loadError) {
    return (
      <Card className="border-destructive/30">
        <CardContent className="pt-6 flex flex-col items-center text-center gap-3">
          <AlertTriangle className="w-8 h-8 text-destructive" />
          <p className="text-sm">{loadError}</p>
          <Button variant="outline" onClick={() => { setLoading(true); loadStaff(); }}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Réessayer
          </Button>
        </CardContent>
      </Card>
    );
  }

  const filters: { key: Filter; label: string; count: number }[] = [
    { key: 'all', label: 'Tous', count: staff.length },
    { key: 'active', label: 'Actifs', count: staff.length - pending.length },
    { key: 'pending', label: 'En attente / inactifs', count: pending.length },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Personnel</h1>
          <p className="text-sm text-muted-foreground mt-1">{staff.length} employé(s)</p>
        </div>
        {isAdmin && (
          <Button onClick={() => setAdding(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Ajouter
          </Button>
        )}
      </div>

      {isAdmin && pending.length > 0 && filter !== 'pending' && (
        <button
          onClick={() => setFilter('pending')}
          className="w-full flex items-center gap-3 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-left text-amber-900 transition-colors hover:bg-amber-100"
        >
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <span className="text-sm">
            {pending.length} compte(s) en attente ou désactivé(s). Ces personnes n&apos;ont accès à aucune donnée.
          </span>
        </button>
      )}

      <div className="flex gap-2 overflow-x-auto pb-1">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              'shrink-0 rounded-full border px-3 py-1.5 text-sm transition-colors',
              filter === f.key ? 'bg-primary text-primary-foreground border-primary' : 'bg-background hover:bg-muted'
            )}
          >
            {f.label} <span className="opacity-70">({f.count})</span>
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-10">Aucun employé dans cette catégorie.</p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-3">
          {visible.map((member) => (
            <Card key={member.id} className={cn('transition-shadow hover:shadow-md', !member.active && 'border-amber-200')}>
              <CardContent className="pt-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={cn(
                      'w-10 h-10 shrink-0 rounded-full flex items-center justify-center font-semibold text-sm',
                      member.active ? 'bg-primary/10 text-primary' : 'bg-amber-100 text-amber-800'
                    )}>
                      {initials(member.full_name)}
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-sm truncate">
                        {member.full_name}
                        {member.id === me?.id && <span className="text-muted-foreground font-normal"> (vous)</span>}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">{member.email}</p>
                    </div>
                  </div>
                  <Badge variant={member.active ? 'default' : 'outline'}
                    className={cn(!member.active && 'border-amber-300 text-amber-800')}>
                    {member.active ? 'Actif' : 'En attente'}
                  </Badge>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  <Badge variant="outline">{roleLabels[member.role]}</Badge>
                  {member.phone && (
                    <span className="inline-flex items-center gap-1"><Phone className="w-3 h-3" />{member.phone}</span>
                  )}
                  {isAdmin && member.hourly_rate != null && (
                    <span>{Number(member.hourly_rate).toFixed(2).replace('.', ',')} €/h</span>
                  )}
                </div>
                {isAdmin && (
                  <div className="flex gap-2">
                    {!member.active && (
                      <Button size="sm" className="flex-1" disabled={activating === member.id} onClick={() => activate(member)}>
                        {activating === member.id
                          ? <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          : <UserCheck className="w-4 h-4 mr-2" />}
                        Activer ({roleLabels[member.role]})
                      </Button>
                    )}
                    <Button size="sm" variant="outline" className={cn(member.active && 'flex-1')} onClick={() => setEditing(member)}>
                      <Pencil className="w-4 h-4 mr-2" />
                      Modifier
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {isAdmin && (
        <>
          <AddStaffDialog open={adding} onOpenChange={setAdding} onCreated={loadStaff} />
          <EditStaffDialog member={editing} isSelf={editing?.id === me?.id} onClose={() => setEditing(null)} onSaved={loadStaff} />
        </>
      )}
    </div>
  );
}
