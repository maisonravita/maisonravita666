'use client';

import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase, type Ingredient, type Purchase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ShoppingCart, Loader2, Camera, Package, PackageCheck, Plus, X } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { ShoppingList, type ShoppingRow } from '@/components/achats/shopping-list';

const PRIORITY_ORDER = { high: 0, medium: 1, low: 2 } as const;

export default function AchatsPage() {
  const { profile } = useAuth();
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [shoppingItems, setShoppingItems] = useState<ShoppingRow[]>([]);
  const [horizon, setHorizon] = useState(7);
  const [receivingId, setReceivingId] = useState<string | null>(null);
  const [purchases, setPurchases] = useState<(Purchase & { ingredients: Ingredient })[]>([]);
  const [loading, setLoading] = useState(true);
  const [addingPurchase, setAddingPurchase] = useState(false);
  const [purchaseForm, setPurchaseForm] = useState({
    ingredient_id: '',
    quantity: '',
    unit: 'kg',
    price: '',
  });
  const [receiptPhoto, setReceiptPhoto] = useState<string | null>(null);
  const [substitution, setSubstitution] = useState('');

  const loadData = useCallback(async () => {
    const [ingRes, shopRes, purchRes, horizonRes] = await Promise.all([
      supabase.from('ingredients').select('*').order('name'),
      supabase.from('shopping_items').select('*, ingredients(*)').eq('status', 'pending'),
      supabase.from('purchases').select('*, ingredients(*)').order('created_at', { ascending: false }).limit(10),
      supabase.from('settings').select('value').eq('key', 'shopping_horizon_days').maybeSingle(),
    ]);
    if (ingRes.error || shopRes.error || purchRes.error) {
      console.error('achats load failed', ingRes.error ?? shopRes.error ?? purchRes.error);
      toast({ title: 'Chargement incomplet', description: 'Certaines données n’ont pas pu être chargées.', variant: 'destructive' });
    }
    setIngredients((ingRes.data ?? []) as Ingredient[]);
    setShoppingItems(
      ((shopRes.data ?? []) as unknown as ShoppingRow[])
        .filter((i) => i.ingredients)
        .sort(
          (a, b) =>
            PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority] ||
            a.ingredients.name.localeCompare(b.ingredients.name)
        )
    );
    const days = Number(horizonRes.data?.value);
    if (days >= 1) setHorizon(days);
    setPurchases((purchRes.data ?? []) as unknown as (Purchase & { ingredients: Ingredient })[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadData();
    const onFocus = () => loadData();
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, [loadData]);

  const handleReceiptPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setReceiptPhoto(reader.result as string);
    reader.readAsDataURL(file);
  };

  const submitPurchase = async () => {
    if (!profile || !purchaseForm.ingredient_id || !purchaseForm.quantity || !purchaseForm.price) return;
    const qty = parseFloat(purchaseForm.quantity);
    const price = parseFloat(purchaseForm.price);
    if (isNaN(qty) || isNaN(price) || qty <= 0 || price < 0) return;
    const { error } = await supabase.from('purchases').insert({
      ingredient_id: purchaseForm.ingredient_id,
      quantity_bought: qty,
      unit: purchaseForm.unit,
      actual_price: price,
      receipt_photo_url: receiptPhoto,
      substitution: substitution || null,
      status: 'purchased',
      courier_id: profile.id,
    });
    if (error) {
      console.error('purchase insert failed', error);
      toast({ title: 'Enregistrement impossible', description: 'Réessayez dans un instant.', variant: 'destructive' });
      return;
    }
    toast({ title: 'Achat enregistré', description: `${qty} ${purchaseForm.unit} pour ${price.toFixed(2)}€` });
    setAddingPurchase(false);
    setPurchaseForm({ ingredient_id: '', quantity: '', unit: 'kg', price: '' });
    setReceiptPhoto(null);
    setSubstitution('');
    loadData();
  };

  const markShoppingItemPurchased = async (item: ShoppingRow) => {
    if (!profile) return;
    const { error: updateError } = await supabase
      .from('shopping_items')
      .update({ status: 'purchased' })
      .eq('id', item.id);
    const { error } = updateError
      ? { error: updateError }
      : await supabase.from('purchases').insert({
          shopping_item_id: item.id,
          ingredient_id: item.ingredient_id,
          quantity_bought: item.quantity_needed,
          unit: item.unit,
          actual_price: item.estimated_price,
          status: 'purchased',
          courier_id: profile.id,
        });
    if (error) {
      console.error('mark purchased failed', error);
      toast({ title: 'Enregistrement impossible', description: 'Réessayez dans un instant.', variant: 'destructive' });
      return;
    }
    toast({ title: 'Achat enregistré', description: item.ingredients.name });
    loadData();
  };

  const receivePurchase = async (id: string) => {
    setReceivingId(id);
    const { error } = await supabase.rpc('receive_purchase', { p_purchase_id: id });
    setReceivingId(null);
    if (error) {
      console.error('receive purchase failed', error);
      toast({
        title: 'Réception impossible',
        description: error.message.includes('already_received') ? 'Cet achat a déjà été réceptionné.' : 'Réessayez dans un instant.',
        variant: 'destructive',
      });
      return;
    }
    toast({ title: 'Achat réceptionné', description: 'La quantité a été ajoutée au stock.' });
    loadData();
  };

  if (!profile) return null;
  const canReceive = profile.role === 'admin' || profile.role === 'cook';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Achats</h1>
          <p className="text-sm text-muted-foreground mt-1">Liste de courses et déclarations d'achats</p>
        </div>
        <Button onClick={() => setAddingPurchase(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nouvel achat
        </Button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <ShoppingList
            key={horizon}
            items={shoppingItems}
            horizon={horizon}
            canRecalculate={canReceive}
            canBuy={profile.role === 'admin' || profile.role === 'courier'}
            onPurchased={markShoppingItemPurchased}
            onRefreshed={loadData}
          />

          {/* Recent purchases */}
          <div className="space-y-3">
            <h2 className="text-sm font-semibold text-muted-foreground">Achats récents ({purchases.length})</h2>
            {purchases.length === 0 ? (
              <Card>
                <CardContent className="pt-10 pb-10 text-center">
                  <ShoppingCart className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">Aucun achat enregistré</p>
                </CardContent>
              </Card>
            ) : (
              purchases.map((purch) => (
                <Card key={purch.id}>
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                          <Package className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold text-sm">{purch.ingredients?.name ?? '—'}</p>
                          <p className="text-xs text-muted-foreground">
                            {purch.quantity_bought} {purch.unit} · {purch.actual_price.toFixed(2)}€
                          </p>
                        </div>
                      </div>
                      <Badge variant={purch.status === 'received' ? 'default' : 'secondary'}>
                        {purch.status === 'purchased' ? 'En attente de réception' :
                         purch.status === 'received' ? 'Réceptionné' : purch.status}
                      </Badge>
                    </div>
                    {purch.status === 'purchased' && canReceive && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="mt-3 w-full"
                        disabled={receivingId === purch.id}
                        onClick={() => receivePurchase(purch.id)}
                      >
                        {receivingId === purch.id ? (
                          <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                        ) : (
                          <PackageCheck className="mr-1.5 h-4 w-4" />
                        )}
                        Réceptionner et ajouter au stock
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </>
      )}

      {/* Add purchase modal */}
      {addingPurchase && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center" onClick={() => setAddingPurchase(false)}>
          <Card className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl slide-up" onClick={(e) => e.stopPropagation()}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Nouvel achat</CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setAddingPurchase(false)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Ingrédient</Label>
                <select
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
                  value={purchaseForm.ingredient_id}
                  onChange={(e) => {
                    const ing = ingredients.find((i) => i.id === e.target.value);
                    setPurchaseForm({ ...purchaseForm, ingredient_id: e.target.value, unit: ing?.unit ?? 'kg' });
                  }}
                >
                  <option value="">Sélectionner...</option>
                  {ingredients.map((ing) => (
                    <option key={ing.id} value={ing.id}>{ing.name}</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label>Quantité</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={purchaseForm.quantity}
                    onChange={(e) => setPurchaseForm({ ...purchaseForm, quantity: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Unité</Label>
                  <Input value={purchaseForm.unit} onChange={(e) => setPurchaseForm({ ...purchaseForm, unit: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Prix (€)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={purchaseForm.price}
                    onChange={(e) => setPurchaseForm({ ...purchaseForm, price: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Photo du ticket</Label>
                <label className="block">
                  <div className="border-2 border-dashed rounded-xl p-4 text-center cursor-pointer hover:border-primary transition-colors">
                    {receiptPhoto ? (
                      <img src={receiptPhoto} alt="Ticket" className="max-h-32 mx-auto rounded-lg" />
                    ) : (
                      <>
                        <Camera className="w-6 h-6 text-muted-foreground mx-auto mb-1" />
                        <p className="text-sm text-muted-foreground">Photographier le ticket</p>
                      </>
                    )}
                  </div>
                  <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleReceiptPhoto} />
                </label>
              </div>
              <div className="space-y-2">
                <Label>Substitution (facultatif)</Label>
                <Input
                  value={substitution}
                  onChange={(e) => setSubstitution(e.target.value)}
                  placeholder="ex: marque différente"
                />
              </div>
              <Button className="w-full h-12" onClick={submitPurchase}>
                Enregistrer l'achat
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
