'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { getNavItemsForRole, roleLabels, roleIcons } from '@/lib/role-nav';
import { DashboardShell } from '@/components/dashboard-shell';
import { Button } from '@/components/ui/button';
import { Clock, Loader2, LogOut, RefreshCw, UserX } from 'lucide-react';

function AccountNotice({
  icon: Icon,
  title,
  text,
  onRetry,
  onSignOut,
  retrying,
}: {
  icon: typeof Clock;
  title: string;
  text: string;
  onRetry: () => void;
  onSignOut: () => void;
  retrying: boolean;
}) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="w-full max-w-sm text-center space-y-4 rounded-2xl border bg-card p-8 shadow-sm">
        <div className="mx-auto w-14 h-14 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
          <Icon className="w-7 h-7" />
        </div>
        <h1 className="text-lg font-semibold">{title}</h1>
        <p className="text-sm text-muted-foreground leading-relaxed">{text}</p>
        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={onRetry} disabled={retrying}>
            {retrying ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            Vérifier à nouveau
          </Button>
          <Button variant="outline" onClick={onSignOut}>
            <LogOut className="w-4 h-4 mr-2" />
            Se déconnecter
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, profile, loading, signOut, refreshProfile } = useAuth();
  const router = useRouter();
  const [retrying, setRetrying] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      router.replace('/');
    }
  }, [loading, user, router]);

  const retry = async () => {
    setRetrying(true);
    try {
      await refreshProfile();
    } finally {
      setRetrying(false);
    }
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!profile) {
    return (
      <AccountNotice
        icon={UserX}
        title="Profil introuvable"
        text="Votre fiche employé n'a pas pu être chargée. Vérifiez votre connexion ou contactez l'administrateur."
        onRetry={retry}
        onSignOut={signOut}
        retrying={retrying}
      />
    );
  }

  if (!profile.active) {
    return (
      <AccountNotice
        icon={Clock}
        title="Compte en attente de validation"
        text="Votre compte a bien été créé, mais l'administrateur doit l'activer avant que vous puissiez accéder à l'application."
        onRetry={retry}
        onSignOut={signOut}
        retrying={retrying}
      />
    );
  }

  const navItems = getNavItemsForRole(profile.role);
  const RoleIcon = roleIcons[profile.role];

  return (
    <DashboardShell
      navItems={navItems}
      profile={profile}
      roleLabel={roleLabels[profile.role]}
      RoleIcon={RoleIcon}
      onSignOut={signOut}
    >
      {children}
    </DashboardShell>
  );
}
