'use client';

import { useState, useEffect, useCallback } from 'react';
import { supabase, type Cargo, type Site, type Recipe } from '@/lib/supabase';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Package, Loader2, MapPin, Clock, Truck, AlertTriangle, RefreshCw } from 'lucide-react';
import { failMessage } from '@/lib/rpc';

type CargoRow = Cargo & {
  sites: Site | null;
  recipes: Recipe | null;
  preparator: { full_name: string } | null;
  driver: { full_name: string } | null;
};

const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  open: { label: 'En préparation', color: 'bg-blue-100 text-blue-700' },
  closed: { label: 'Fermé — prêt au chargement', color: 'bg-success/10 text-success' },
  loaded: { label: 'Chargé', color: 'bg-warning/10 text-warning' },
  in_delivery: { label: 'En livraison', color: 'bg-info/10 text-info' },
  delivered: { label: 'Livré', color: 'bg-success/10 text-success' },
};

export default function CargosPage() {
  const [cargos, setCargos] = useState<CargoRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');

  const loadCargos = useCallback(async () => {
    let query = supabase
      .from('cargos')
      .select('*, sites(*), recipes(*), preparator:profiles!cargos_preparator_profile_fkey(full_name), driver:profiles!cargos_driver_id_fkey(full_name)')
      .order('created_at', { ascending: false })
      .limit(200);
    if (filter !== 'all') {
      query = query.eq('status', filter);
    }
    const { data, error } = await query;
    if (error) {
      setLoadError(failMessage(error));
    } else {
      setLoadError(null);
      setCargos((data ?? []) as unknown as CargoRow[]);
    }
    setLoading(false);
  }, [filter]);

  useEffect(() => {
    loadCargos();
    const interval = setInterval(loadCargos, 15000);
    return () => clearInterval(interval);
  }, [loadCargos]);

  const filters = [
    { value: 'all', label: 'Tous' },
    { value: 'open', label: 'En préparation' },
    { value: 'closed', label: 'Fermés' },
    { value: 'loaded', label: 'Chargés' },
    { value: 'in_delivery', label: 'En livraison' },
    { value: 'delivered', label: 'Livrés' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Cargos</h1>
        <p className="text-sm text-muted-foreground mt-1">Suivi des cargos de barquettes</p>
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {filters.map((f) => (
          <button
            key={f.value}
            onClick={() => { setFilter(f.value); setLoading(true); }}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
              filter === f.value
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/70'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : loadError ? (
        <Card className="border-destructive/30">
          <CardContent className="pt-6 flex flex-col items-center text-center gap-3">
            <AlertTriangle className="w-8 h-8 text-destructive" />
            <p className="text-sm">{loadError}</p>
            <Button variant="outline" onClick={() => { setLoading(true); loadCargos(); }}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Réessayer
            </Button>
          </CardContent>
        </Card>
      ) : cargos.length === 0 ? (
        <Card>
          <CardContent className="pt-10 pb-10 text-center">
            <Package className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">Aucun cargo dans cette catégorie</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {cargos.map((cargo) => {
            const statusCfg = STATUS_CONFIG[cargo.status] ?? STATUS_CONFIG.open;
            return (
              <Card key={cargo.id}>
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Package className="w-4 h-4 text-primary" />
                        <span className="font-semibold text-sm">{cargo.code}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {cargo.recipes?.name ?? 'Recette inconnue'}
                      </p>
                    </div>
                    <Badge className={statusCfg.color}>{statusCfg.label}</Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center mb-3">
                    <div className="rounded-lg bg-muted/50 py-2">
                      <MapPin className="w-3 h-3 text-muted-foreground mx-auto mb-1" />
                      <p className="text-xs font-medium">{cargo.sites?.name ?? '—'}</p>
                    </div>
                    <div className="rounded-lg bg-muted/50 py-2">
                      <Clock className="w-3 h-3 text-muted-foreground mx-auto mb-1" />
                      <p className="text-xs font-medium capitalize">{cargo.service}</p>
                    </div>
                    <div className="rounded-lg bg-muted/50 py-2">
                      <Package className="w-3 h-3 text-muted-foreground mx-auto mb-1" />
                      <p className="text-xs font-medium">{cargo.meal_unit_count}/{cargo.max_capacity}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 text-xs text-muted-foreground">
                    <span>Préparé par {cargo.preparator?.full_name ?? '—'}</span>
                    {cargo.driver && (
                      <span className="inline-flex items-center gap-1">
                        <Truck className="w-3 h-3" />
                        {cargo.driver.full_name}
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
