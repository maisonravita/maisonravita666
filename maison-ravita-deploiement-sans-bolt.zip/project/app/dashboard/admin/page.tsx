'use client';

import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase, type Cargo, type Menu, type Request as RequestItem } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  Package,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  ShoppingCart,
  Truck,
  Bell,
  CalendarDays,
  Loader2,
  Users,
} from 'lucide-react';
import Link from 'next/link';

interface DashboardData {
  totalCounter: number;
  cargosOpen: number;
  cargosClosed: number;
  cargosLoaded: number;
  cargosInDelivery: number;
  cargosDelivered: number;
  menusToday: number;
  menusValidated: number;
  urgentRequests: number;
  unreadNotifications: number;
  todaySpending: number;
  dailyBudget: number;
  budgetConsumed: number;
  pendingInvoices: number;
}

export default function AdminDashboard() {
  const { profile } = useAuth();
  const [data, setData] = useState<DashboardData | null>(null);
  const [recentRequests, setRecentRequests] = useState<RequestItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);

  const loadDashboard = useCallback(async () => {
    const today = new Date().toISOString().split('T')[0];

    const [
      counterRes,
      cargosRes,
      menusRes,
      requestsRes,
      notifRes,
      purchasesRes,
      invoicesRes,
      urgentRes,
      settingsRes,
    ] = await Promise.all([
      supabase.from('total_counter').select('count').eq('id', 1).maybeSingle(),
      supabase.from('cargos').select('status'),
      supabase.from('menus').select('*').eq('date', today),
      supabase.from('requests').select('*').order('created_at', { ascending: false }).limit(5),
      supabase.from('notifications').select('*').eq('read', false),
      supabase.from('purchases').select('actual_price').gte('created_at', today),
      supabase.from('supplier_invoices').select('*').eq('status', 'to_verify'),
      supabase
        .from('requests')
        .select('id', { count: 'exact', head: true })
        .in('urgency', ['high', 'critical'])
        .not('status', 'in', '(resolved,rejected)'),
      supabase
        .from('settings')
        .select('key, value')
        .in('key', ['budget_per_barquette', 'daily_production_midi', 'daily_production_soir']),
    ]);

    const failed = [counterRes, cargosRes, menusRes, requestsRes, notifRes, purchasesRes, invoicesRes, urgentRes, settingsRes]
      .find((r) => r.error);
    if (failed) {
      console.error('admin dashboard load failed', failed.error);
      setLoadError(true);
      setLoading(false);
      return;
    }
    setLoadError(false);

    const setting = (key: string, fallback: number) => {
      const row = (settingsRes.data ?? []).find((s: { key: string; value: string }) => s.key === key);
      const n = Number(row?.value);
      return Number.isFinite(n) && row ? n : fallback;
    };
    const dailyBudget =
      setting('budget_per_barquette', 1.5) *
      (setting('daily_production_midi', 380) + setting('daily_production_soir', 380));

    const cargos = (cargosRes.data ?? []) as Cargo[];
    const menus = (menusRes.data ?? []) as Menu[];

    const todaySpending = (purchasesRes.data ?? []).reduce(
      (sum, p: { actual_price: number | null }) => sum + Number(p.actual_price ?? 0),
      0
    );

    setData({
      totalCounter: counterRes.data?.count ?? 0,
      cargosOpen: cargos.filter((c) => c.status === 'open').length,
      cargosClosed: cargos.filter((c) => c.status === 'closed').length,
      cargosLoaded: cargos.filter((c) => c.status === 'loaded').length,
      cargosInDelivery: cargos.filter((c) => c.status === 'in_delivery').length,
      cargosDelivered: cargos.filter((c) => c.status === 'delivered').length,
      menusToday: menus.length,
      menusValidated: menus.filter((m) => m.status === 'validated').length,
      urgentRequests: urgentRes.count ?? 0,
      unreadNotifications: notifRes.data?.length ?? 0,
      todaySpending,
      dailyBudget,
      budgetConsumed: dailyBudget > 0 ? (todaySpending / dailyBudget) * 100 : 0,
      pendingInvoices: invoicesRes.data?.length ?? 0,
    });

    setRecentRequests((requestsRes.data ?? []) as RequestItem[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadDashboard();
    const interval = setInterval(loadDashboard, 30000);
    return () => clearInterval(interval);
  }, [loadDashboard]);

  if (loadError && !data) {
    return (
      <Card className="border-destructive/30">
        <CardContent className="pt-6 flex flex-col items-center text-center gap-3">
          <AlertTriangle className="w-8 h-8 text-destructive" />
          <p className="text-sm">Impossible de charger le tableau de bord. Vérifiez votre connexion.</p>
          <Button variant="outline" onClick={() => { setLoading(true); loadDashboard(); }}>Réessayer</Button>
        </CardContent>
      </Card>
    );
  }

  if (loading || !data) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const kpiCards = [
    { label: 'Cargos en préparation', value: data.cargosOpen, icon: Package, color: 'text-blue-500', bg: 'bg-blue-50' },
    { label: 'Cargos fermés', value: data.cargosClosed, icon: CheckCircle2, color: 'text-success', bg: 'bg-success/10' },
    { label: 'Cargos chargés', value: data.cargosLoaded, icon: Truck, color: 'text-warning', bg: 'bg-warning/10' },
    { label: 'Cargos en livraison', value: data.cargosInDelivery, icon: Truck, color: 'text-info', bg: 'bg-info/10' },
    { label: 'Cargos livrés', value: data.cargosDelivered, icon: CheckCircle2, color: 'text-success', bg: 'bg-success/10' },
    { label: 'Demandes urgentes', value: data.urgentRequests, icon: AlertTriangle, color: 'text-destructive', bg: 'bg-destructive/10' },
    { label: 'Factures à vérifier', value: data.pendingInvoices, icon: ShoppingCart, color: 'text-warning', bg: 'bg-warning/10' },
    { label: 'Notifications non lues', value: data.unreadNotifications, icon: Bell, color: 'text-primary', bg: 'bg-primary/10' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Tableau de bord</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Vue d&apos;ensemble des opérations — {new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}
          </p>
        </div>
        <div className="flex items-center gap-3 bg-primary/5 rounded-2xl px-4 py-3 border border-primary/10">
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Total barquettes produites</p>
            <p className="text-2xl font-bold text-primary tabular-nums">{data.totalCounter.toLocaleString('fr-FR')}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-primary" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-primary/20">
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-2">
              <CalendarDays className="w-5 h-5 text-primary" />
              <span className="text-2xl font-bold">{data.menusToday}</span>
            </div>
            <p className="text-xs text-muted-foreground">Menus aujourd&apos;hui</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-2">
              <CheckCircle2 className="w-5 h-5 text-success" />
              <span className="text-2xl font-bold">{data.menusValidated}</span>
            </div>
            <p className="text-xs text-muted-foreground">Menus validés</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-5 h-5 text-info" />
              <span className="text-2xl font-bold">{data.todaySpending.toFixed(0)}€</span>
            </div>
            <p className="text-xs text-muted-foreground">Dépenses du jour</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-2">
              <Package className="w-5 h-5 text-warning" />
              <span className="text-2xl font-bold">{data.cargosOpen + data.cargosClosed + data.cargosLoaded + data.cargosInDelivery + data.cargosDelivered}</span>
            </div>
            <p className="text-xs text-muted-foreground">Cargos totaux</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Budget du jour</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">
              {data.todaySpending.toFixed(2).replace('.', ',')} € / {data.dailyBudget.toFixed(2).replace('.', ',')} €
            </span>
            <span className="text-sm font-semibold">{data.budgetConsumed.toFixed(1)}%</span>
          </div>
          <Progress value={Math.min(data.budgetConsumed, 100)} className="h-3" />
          {data.budgetConsumed > 100 && (
            <p className="text-xs text-destructive mt-2">Budget journalier dépassé.</p>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {kpiCards.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <Card key={kpi.label} className="overflow-hidden">
              <CardContent className="pt-5">
                <div className={`w-10 h-10 rounded-xl ${kpi.bg} flex items-center justify-center mb-3`}>
                  <Icon className={`w-5 h-5 ${kpi.color}`} />
                </div>
                <p className="text-2xl font-bold">{kpi.value}</p>
                <p className="text-xs text-muted-foreground mt-1">{kpi.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Demandes récentes</CardTitle>
              <Link href="/dashboard/notifications">
                <Button variant="ghost" size="sm">Voir tout</Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentRequests.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">
                Aucune demande récente
              </p>
            ) : (
              recentRequests.map((req) => (
                <div key={req.id} className="flex items-start gap-3 p-3 rounded-xl bg-muted/50">
                  <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                    req.urgency === 'critical' ? 'bg-destructive' :
                    req.urgency === 'high' ? 'bg-warning' : 'bg-muted-foreground'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{req.category}</p>
                    <p className="text-xs text-muted-foreground truncate">{req.description}</p>
                  </div>
                  <Badge variant="outline" className="text-xs shrink-0">
                    {req.status}
                  </Badge>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Actions rapides</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            <Link href="/dashboard/menus">
              <Button variant="outline" className="w-full h-20 flex-col gap-2">
                <CalendarDays className="w-6 h-6" />
                <span className="text-xs">Générer les menus</span>
              </Button>
            </Link>
            <Link href="/dashboard/cargos">
              <Button variant="outline" className="w-full h-20 flex-col gap-2">
                <Package className="w-6 h-6" />
                <span className="text-xs">Voir les cargos</span>
              </Button>
            </Link>
            <Link href="/dashboard/personnel">
              <Button variant="outline" className="w-full h-20 flex-col gap-2">
                <Users className="w-6 h-6" />
                <span className="text-xs">Personnel</span>
              </Button>
            </Link>
            <Link href="/dashboard/finances">
              <Button variant="outline" className="w-full h-20 flex-col gap-2">
                <TrendingUp className="w-6 h-6" />
                <span className="text-xs">Finances</span>
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
