'use client';

import { useState, useEffect, useCallback } from 'react';
import { supabase, type Site, type SupplierInvoice, type CustomerInvoice } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Receipt, Loader2, TrendingUp, FileText, CheckCircle2, XCircle, Euro, AlertTriangle, RefreshCw } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { failMessage } from '@/lib/rpc';

export default function FinancesPage() {
  const [sites, setSites] = useState<Site[]>([]);
  const [invoices, setInvoices] = useState<SupplierInvoice[]>([]);
  const [customerInvoices, setCustomerInvoices] = useState<CustomerInvoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [totalSpending, setTotalSpending] = useState(0);

  const loadData = useCallback(async () => {
    const [sitesRes, invRes, custInvRes, purchRes] = await Promise.all([
      supabase.from('sites').select('*'),
      supabase.from('supplier_invoices').select('*').order('created_at', { ascending: false }),
      supabase.from('customer_invoices').select('*, sites(*)').order('created_at', { ascending: false }),
      supabase.from('purchases').select('actual_price'),
    ]);
    const failed = [sitesRes, invRes, custInvRes, purchRes].find((r) => r.error);
    if (failed) {
      setLoadError(failMessage(failed.error));
      setLoading(false);
      return;
    }
    setLoadError(null);
    setSites((sitesRes.data ?? []) as Site[]);
    setInvoices((invRes.data ?? []) as SupplierInvoice[]);
    setCustomerInvoices((custInvRes.data ?? []) as unknown as CustomerInvoice[]);
    setTotalSpending((purchRes.data ?? []).reduce((sum, p: { actual_price: number | null }) => sum + Number(p.actual_price ?? 0), 0));
    setLoading(false);
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const setInvoiceStatus = async (id: string, status: 'validated' | 'rejected') => {
    setBusyId(id);
    const { data, error } = await supabase.from('supplier_invoices').update({ status }).eq('id', id).select('id');
    setBusyId(null);
    if (error || !data?.length) {
      toast({ title: 'Mise à jour impossible', description: failMessage(error), variant: 'destructive' });
      return;
    }
    toast({ title: status === 'validated' ? 'Facture validée' : 'Facture rejetée' });
    loadData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (loadError) {
    return (
      <Card className="border-destructive/30">
        <CardContent className="pt-6 flex flex-col items-center text-center gap-3">
          <AlertTriangle className="w-8 h-8 text-destructive" />
          <p className="text-sm">{loadError}</p>
          <Button variant="outline" onClick={() => { setLoading(true); loadData(); }}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Réessayer
          </Button>
        </CardContent>
      </Card>
    );
  }

  const pendingInvoices = invoices.filter((i) => i.status === 'to_verify' || i.status === 'imported');
  const validatedInvoices = invoices.filter((i) => i.status === 'validated');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Finances</h1>
        <p className="text-sm text-muted-foreground mt-1">Suivi des dépenses et facturation</p>
      </div>

      <div className="grid sm:grid-cols-3 gap-3">
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-2">
              <Euro className="w-5 h-5 text-primary" />
              <span className="text-2xl font-bold">{totalSpending.toFixed(2)}€</span>
            </div>
            <p className="text-xs text-muted-foreground">Total des achats</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-2">
              <FileText className="w-5 h-5 text-warning" />
              <span className="text-2xl font-bold">{pendingInvoices.length}</span>
            </div>
            <p className="text-xs text-muted-foreground">Factures à vérifier</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-2">
              <CheckCircle2 className="w-5 h-5 text-success" />
              <span className="text-2xl font-bold">{validatedInvoices.length}</span>
            </div>
            <p className="text-xs text-muted-foreground">Factures validées</p>
          </CardContent>
        </Card>
      </div>

      {/* Pending invoices */}
      <div className="space-y-3">
        <h2 className="text-sm font-semibold text-muted-foreground">Factures à vérifier</h2>
        {pendingInvoices.length === 0 ? (
          <Card>
            <CardContent className="pt-10 pb-10 text-center">
              <Receipt className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">Aucune facture en attente</p>
            </CardContent>
          </Card>
        ) : (
          pendingInvoices.map((inv) => (
            <Card key={inv.id}>
              <CardContent className="pt-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-semibold text-sm">{inv.supplier ?? 'Fournisseur inconnu'}</p>
                    <p className="text-xs text-muted-foreground">
                      {inv.category} · {inv.invoice_number ?? 'N° non renseigné'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{inv.amount_ttc.toFixed(2)}€</p>
                    <p className="text-xs text-muted-foreground">TTC</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" className="flex-1" disabled={busyId === inv.id} onClick={() => setInvoiceStatus(inv.id, 'validated')}>
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Valider
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1" disabled={busyId === inv.id} onClick={() => setInvoiceStatus(inv.id, 'rejected')}>
                    <XCircle className="w-3 h-3 mr-1" />
                    Rejeter
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Customer invoices */}
      <div className="space-y-3">
        <h2 className="text-sm font-semibold text-muted-foreground">Factures clients</h2>
        {customerInvoices.length === 0 ? (
          <Card>
            <CardContent className="pt-10 pb-10 text-center">
              <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">Aucune facture client émise</p>
            </CardContent>
          </Card>
        ) : (
          customerInvoices.map((inv) => {
            const custInv = inv as CustomerInvoice & { sites?: Site };
            return (
              <Card key={inv.id}>
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-semibold text-sm">{custInv.sites?.name ?? 'Site'}</p>
                      <p className="text-xs text-muted-foreground">
                        {inv.period} · {inv.quantity_billable} barquettes
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">{inv.amount_ttc.toFixed(2)}€</p>
                      <Badge variant={inv.paid ? 'default' : 'secondary'}>
                        {inv.paid ? 'Payée' : 'En attente'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
