'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase, type Ingredient, type StockLot } from '@/lib/supabase';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Boxes, Loader2, AlertTriangle, Plus, Minus, PackagePlus, Search, CalendarClock, History, ChefHat, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { cn } from '@/lib/utils';
import { AddStockDialog, CATEGORIES } from '@/components/stocks/add-stock-dialog';
import { RemoveStockDialog } from '@/components/stocks/remove-stock-dialog';
import { MovementsDialog } from '@/components/stocks/movements-dialog';
import { DietBadges, DietFlagsDialog } from '@/components/stocks/diet-flags';

interface IngredientWithStock extends Ingredient {
  total_stock: number;
  lots: StockLot[];
}

type View = 'stock' | 'catalogue';

const fmt = (n: number) => (Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0+$/, ''));

function daysUntil(date: string) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((new Date(`${date}T00:00:00`).getTime() - today.getTime()) / 86400000);
}

export default function StocksPage() {
  const { profile } = useAuth();
  const [ingredients, setIngredients] = useState<IngredientWithStock[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [search, setSearch] = useState('');
  const [view, setView] = useState<View>('stock');
  const [adding, setAdding] = useState<{ preselected: Ingredient | null } | null>(null);
  const [removing, setRemoving] = useState<IngredientWithStock | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [editingDiet, setEditingDiet] = useState<Ingredient | null>(null);

  const canEdit = profile?.role === 'admin' || profile?.role === 'cook';

  const loadStocks = useCallback(async () => {
    const [ingRes, lotRes] = await Promise.all([
      supabase.from('ingredients').select('*').order('name'),
      supabase.from('stock_lots').select('*').gt('quantity', 0).order('expiry_date', { ascending: true, nullsFirst: false }),
    ]);
    if (ingRes.error || lotRes.error) {
      console.error('stock load failed', ingRes.error ?? lotRes.error);
      setLoadError(true);
      setLoading(false);
      return;
    }
    const lots = (lotRes.data ?? []) as StockLot[];
    setIngredients(
      ((ingRes.data ?? []) as Ingredient[]).map((ing) => {
        const ingLots = lots.filter((l) => l.ingredient_id === ing.id);
        return {
          ...ing,
          price: Number(ing.price),
          alert_threshold: Number(ing.alert_threshold),
          total_stock: ingLots.reduce((sum, l) => sum + Number(l.quantity), 0),
          lots: ingLots,
        };
      })
    );
    setLoadError(false);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadStocks();
    const onFocus = () => loadStocks();
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, [loadStocks]);

  const inStock = useMemo(() => ingredients.filter((i) => i.total_stock > 0), [ingredients]);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    const base = view === 'stock' ? inStock : ingredients;
    return base.filter((i) => !q || i.name.toLowerCase().includes(q));
  }, [view, inStock, ingredients, search]);

  const lowCount = inStock.filter((i) => i.alert_threshold > 0 && i.total_stock <= i.alert_threshold).length;
  const expiringCount = inStock.filter((i) => i.lots.some((l) => l.expiry_date && daysUntil(l.expiry_date) <= 2)).length;
  const stockValue = inStock.reduce((s, i) => s + i.total_stock * i.price, 0);

  const done = () => {
    setAdding(null);
    setRemoving(null);
    setEditingDiet(null);
    loadStocks();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold">Stocks</h1>
          <p className="mt-1 text-sm text-muted-foreground">Ce qui est réellement en réserve</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowHistory(true)}>
            <History className="mr-2 h-4 w-4" />
            Historique
          </Button>
          {canEdit && (
            <Button onClick={() => setAdding({ preselected: null })}>
              <PackagePlus className="mr-2 h-4 w-4" />
              Ajouter un aliment
            </Button>
          )}
        </div>
      </div>

      <div className="flex items-start gap-3 rounded-xl border border-sky-200 bg-sky-50 p-3 text-sm text-sky-900">
        <ChefHat className="mt-0.5 h-4 w-4 shrink-0" />
        Stock automatique : chaque barquette scannée en production retire les ingrédients de sa recette. Quand un aliment manque pour les menus à venir ou passe sous son seuil, il est ajouté tout seul à la liste de courses.
      </div>

      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Aliments en stock', value: String(inStock.length), tone: 'text-foreground' },
          { label: 'Stock bas', value: String(lowCount), tone: lowCount ? 'text-amber-600' : 'text-foreground' },
          { label: 'Valeur estimée', value: `${stockValue.toFixed(0)} €`, tone: 'text-foreground' },
        ].map((s) => (
          <Card key={s.label}>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className={cn('text-xl font-bold', s.tone)}>{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {expiringCount > 0 && (
        <div className="flex items-center gap-3 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
          <CalendarClock className="h-5 w-5 shrink-0" />
          {expiringCount} aliment(s) arrivent à date limite d’ici 2 jours : à utiliser en priorité.
        </div>
      )}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="inline-flex rounded-lg bg-muted p-1">
          {([
            ['stock', `En stock (${inStock.length})`],
            ['catalogue', `Catalogue (${ingredients.length})`],
          ] as const).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setView(id)}
              className={cn(
                'rounded-md px-3 py-1.5 text-sm font-medium transition-all',
                view === id ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="relative flex-1 sm:max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Rechercher…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : loadError ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
            <AlertTriangle className="h-8 w-8 text-destructive" />
            <p className="text-sm text-muted-foreground">Impossible de charger le stock.</p>
            <Button variant="outline" onClick={() => { setLoading(true); loadStocks(); }}>Réessayer</Button>
          </CardContent>
        </Card>
      ) : visible.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-3 py-14 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <Boxes className="h-7 w-7" />
            </div>
            <p className="font-semibold">{search ? 'Aucun résultat' : 'Le stock est vide'}</p>
            <p className="max-w-sm text-sm text-muted-foreground">
              {search
                ? 'Aucun aliment ne correspond à votre recherche.'
                : 'Ajoutez les aliments que vous recevez ou achetez, avec la quantité et la date limite.'}
            </p>
            {canEdit && (
              <Button onClick={() => setAdding({ preselected: null })}>
                <PackagePlus className="mr-2 h-4 w-4" />
                {search ? `Ajouter « ${search} »` : 'Ajouter un aliment'}
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((ing) => {
            const empty = ing.total_stock <= 0;
            const isLow = !empty && ing.alert_threshold > 0 && ing.total_stock <= ing.alert_threshold;
            return (
              <Card key={ing.id} className={cn('transition-shadow hover:shadow-md', isLow && 'border-amber-300', empty && 'opacity-80')}>
                <CardContent className="p-4">
                  <div className="mb-2 flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{ing.name}</p>
                      <p className="text-xs text-muted-foreground">{CATEGORIES[ing.category] ?? ing.category}</p>
                    </div>
                    {isLow && (
                      <Badge variant="outline" className="shrink-0 border-amber-300 text-amber-700">
                        <AlertTriangle className="mr-1 h-3 w-3" /> Bas
                      </Badge>
                    )}
                    {empty && <Badge variant="secondary" className="shrink-0">Épuisé</Badge>}
                  </div>

                  <DietBadges ingredient={ing} />

                  <div className="mb-2 flex items-baseline gap-1">
                    <span className={cn('text-2xl font-bold tabular-nums', isLow && 'text-amber-600', empty && 'text-muted-foreground')}>
                      {fmt(ing.total_stock)}
                    </span>
                    <span className="text-sm text-muted-foreground">{ing.unit}</span>
                    <span className="ml-auto text-xs text-muted-foreground">{ing.price.toFixed(2)} € / {ing.unit}</span>
                  </div>

                  {ing.lots.length > 0 && (
                    <div className="mb-3 space-y-1">
                      {ing.lots.slice(0, 3).map((lot) => {
                        const d = lot.expiry_date ? daysUntil(lot.expiry_date) : null;
                        return (
                          <div key={lot.id} className="flex items-center justify-between rounded-md bg-muted/50 px-2 py-1 text-xs">
                            <span className="text-muted-foreground">{lot.lot_number ? `Lot ${lot.lot_number}` : 'Lot'}</span>
                            <span className="font-medium tabular-nums">{fmt(Number(lot.quantity))} {ing.unit}</span>
                            <span className={cn(d !== null && d <= 2 ? 'font-medium text-amber-700' : 'text-muted-foreground', d !== null && d < 0 && 'text-destructive')}>
                              {lot.expiry_date ? `DLC ${new Date(`${lot.expiry_date}T00:00:00`).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })}` : '—'}
                            </span>
                          </div>
                        );
                      })}
                      {ing.lots.length > 3 && <p className="text-xs text-muted-foreground">+ {ing.lots.length - 3} autre(s) lot(s)</p>}
                    </div>
                  )}

                  {canEdit && (
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="flex-1" onClick={() => setAdding({ preselected: ing })}>
                        <Plus className="mr-1 h-3.5 w-3.5" /> Entrée
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1" disabled={empty} onClick={() => setRemoving(ing)}>
                        <Minus className="mr-1 h-3.5 w-3.5" /> Sortie
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-9 w-9 shrink-0"
                        aria-label="Régime alimentaire"
                        title="Halal, porc, alcool"
                        onClick={() => setEditingDiet(ing)}
                      >
                        <ShieldCheck className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {adding && (
        <AddStockDialog
          ingredients={ingredients}
          preselected={adding.preselected}
          onClose={() => setAdding(null)}
          onDone={done}
        />
      )}
      {showHistory && <MovementsDialog onClose={() => setShowHistory(false)} />}
      {editingDiet && (
        <DietFlagsDialog ingredient={editingDiet} onClose={() => setEditingDiet(null)} onDone={done} />
      )}
      {removing && (
        <RemoveStockDialog
          ingredient={removing}
          available={removing.total_stock}
          onClose={() => setRemoving(null)}
          onDone={done}
        />
      )}
    </div>
  );
}
