'use client';

import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase, type Cargo, type Site, type Recipe, type DeliveryRoute } from '@/lib/supabase';
import { callRpc, failMessage } from '@/lib/rpc';
import { compressImage } from '@/lib/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import {
  Truck,
  Loader2,
  Package,
  MapPin,
  Camera,
  CheckCircle2,
  AlertTriangle,
  Navigation,
  Clock,
  X,
  RefreshCw,
  ClipboardCheck,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

type CargoRow = Cargo & { sites: Site; recipes: Recipe };
type DriverStep = 'checkin' | 'cargos' | 'route';

const CARGO_SELECT = '*, sites(*), recipes(*)';

export default function LivraisonsPage() {
  const { profile } = useAuth();
  const [step, setStep] = useState<DriverStep | null>(null);
  const [closedCargos, setClosedCargos] = useState<CargoRow[]>([]);
  const [loadedCargos, setLoadedCargos] = useState<CargoRow[]>([]);
  const [routeCargos, setRouteCargos] = useState<CargoRow[]>([]);
  const [activeRoute, setActiveRoute] = useState<DeliveryRoute | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [busy, setBusy] = useState(false);
  const [selectedCargoIds, setSelectedCargoIds] = useState<string[]>([]);
  const [receivedCargoIds, setReceivedCargoIds] = useState<string[]>([]);
  const [receivingCargo, setReceivingCargo] = useState<CargoRow | null>(null);
  const [receiptChecks, setReceiptChecks] = useState([false, false, false]);
  const [deliveringCargo, setDeliveringCargo] = useState<CargoRow | null>(null);
  const [deliveryQty, setDeliveryQty] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');
  const [deliveryPhoto, setDeliveryPhoto] = useState<string | null>(null);
  const [photoLoading, setPhotoLoading] = useState(false);
  const [incidentModal, setIncidentModal] = useState(false);
  const [incidentDesc, setIncidentDesc] = useState('');
  const [incidentType, setIncidentType] = useState('delay');
  const [incidentCargoId, setIncidentCargoId] = useState('');

  const load = useCallback(async () => {
    if (!profile) return;
    setLoading(true);
    setLoadError(false);
    const { data: route, error: routeError } = await supabase
      .from('delivery_routes')
      .select('*')
      .eq('driver_id', profile.id)
      .eq('status', 'active')
      .maybeSingle();
    if (routeError) {
      console.error(routeError);
      setLoadError(true);
      setLoading(false);
      return;
    }
    if (route) {
      const { data, error } = await supabase
        .from('cargos')
        .select(CARGO_SELECT)
        .eq('route_id', route.id)
        .order('created_at');
      if (error) {
        console.error(error);
        setLoadError(true);
      } else {
        setActiveRoute(route as DeliveryRoute);
        setRouteCargos((data ?? []) as unknown as CargoRow[]);
        setStep('route');
      }
      setLoading(false);
      return;
    }
    const [closedRes, loadedRes, receiptsRes] = await Promise.all([
      supabase.from('cargos').select(CARGO_SELECT).eq('status', 'closed').order('closed_at'),
      supabase
        .from('cargos')
        .select(CARGO_SELECT)
        .eq('status', 'loaded')
        .eq('driver_id', profile.id)
        .order('loaded_at'),
      supabase.from('cargo_receipts').select('cargo_id').eq('driver_id', profile.id),
    ]);
    if (closedRes.error || loadedRes.error || receiptsRes.error) {
      console.error(closedRes.error ?? loadedRes.error ?? receiptsRes.error);
      setLoadError(true);
    } else {
      setActiveRoute(null);
      setRouteCargos([]);
      setClosedCargos((closedRes.data ?? []) as unknown as CargoRow[]);
      setLoadedCargos((loadedRes.data ?? []) as unknown as CargoRow[]);
      setReceivedCargoIds((receiptsRes.data ?? []).map((r) => r.cargo_id));
    }
    setLoading(false);
  }, [profile]);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const start = new Date();
      start.setHours(0, 0, 0, 0);
      const { data } = await supabase
        .from('employee_checkins')
        .select('id')
        .eq('user_id', profile.id)
        .gte('check_in_at', start.toISOString())
        .limit(1);
      setStep(data && data.length > 0 ? 'cargos' : 'checkin');
    })();
  }, [profile]);

  useEffect(() => {
    if (step === 'cargos' || step === 'route') load();
  }, [step, load]);

  const handleCheckin = async () => {
    if (!profile) return;
    setBusy(true);
    const { error } = await supabase
      .from('employee_checkins')
      .insert({ user_id: profile.id, location_verified: false });
    setBusy(false);
    if (error) {
      toast({ title: 'Pointage non enregistré', description: failMessage(error), variant: 'destructive' });
      return;
    }
    toast({ title: 'Prise de service enregistrée' });
    setStep('cargos');
  };

  const confirmReceipt = async () => {
    if (!receivingCargo || !receiptChecks.every(Boolean)) return;
    setBusy(true);
    const res = await callRpc('receive_cargo', {
      p_cargo_id: receivingCargo.id, p_count_checked: receiptChecks[0],
      p_destination_checked: receiptChecks[1], p_condition_checked: receiptChecks[2],
    });
    setBusy(false);
    if (!res.ok) {
      toast({ title: 'Réception non enregistrée', description: res.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Réception confirmée', description: 'Cargo vérifié, prêt à charger.' });
    setReceivingCargo(null);
    load();
  };

  const toggleCargoSelection = (cargoId: string) => {
    if (!receivedCargoIds.includes(cargoId)) return;
    setSelectedCargoIds((prev) =>
      prev.includes(cargoId) ? prev.filter((id) => id !== cargoId) : [...prev, cargoId]
    );
  };

  const confirmLoading = async () => {
    if (selectedCargoIds.length === 0) return;
    setBusy(true);
    const res = await callRpc<{ loaded: number; requested: number }>('load_cargos', {
      p_cargo_ids: selectedCargoIds,
    });
    setBusy(false);
    if (!res.ok) {
      toast({ title: 'Chargement refusé', description: res.message, variant: 'destructive' });
      return;
    }
    if (res.loaded < res.requested) {
      toast({
        title: `${res.loaded} cargo(s) chargé(s) sur ${res.requested}`,
        description: 'Les autres ont déjà été pris par un autre livreur.',
      });
    } else {
      toast({ title: 'Cargos chargés', description: `${res.loaded} cargo(s) chargé(s).` });
    }
    setSelectedCargoIds([]);
    load();
  };

  const startRoute = async () => {
    setBusy(true);
    const res = await callRpc('start_route');
    setBusy(false);
    if (!res.ok) {
      toast({ title: 'Tournée non démarrée', description: res.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Tournée démarrée', description: 'Bonne route !' });
    setStep('route');
    load();
  };

  const handlePhotoCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setPhotoLoading(true);
    try {
      setDeliveryPhoto(await compressImage(file));
    } catch {
      toast({ title: 'Photo illisible', description: 'Reprenez la photo.', variant: 'destructive' });
    } finally {
      setPhotoLoading(false);
    }
  };

  const openDelivery = (cargo: CargoRow) => {
    setDeliveringCargo(cargo);
    setDeliveryQty(String(cargo.meal_unit_count));
    setDeliveryPhoto(null);
    setDeliveryNotes('');
  };

  const confirmDelivery = async () => {
    if (!deliveringCargo || !deliveryPhoto) return;
    const qty = Number(deliveryQty);
    if (!Number.isInteger(qty) || qty < 0 || qty > deliveringCargo.meal_unit_count) {
      toast({
        title: 'Quantité invalide',
        description: `Entre 0 et ${deliveringCargo.meal_unit_count}.`,
        variant: 'destructive',
      });
      return;
    }
    if (qty < deliveringCargo.meal_unit_count && !deliveryNotes.trim()) {
      toast({
        title: 'Précisez la différence',
        description: 'Indiquez dans les notes pourquoi des barquettes manquent.',
        variant: 'destructive',
      });
      return;
    }
    setBusy(true);
    const res = await callRpc<{ remaining: number }>('deliver_cargo', {
      p_cargo_id: deliveringCargo.id,
      p_quantity: qty,
      p_photo: deliveryPhoto,
      p_notes: deliveryNotes.trim() || null,
    });
    setBusy(false);
    if (!res.ok) {
      toast({ title: 'Livraison non enregistrée', description: res.message, variant: 'destructive' });
      return;
    }
    toast({
      title: 'Livraison confirmée',
      description:
        res.remaining > 0
          ? `${qty} barquettes livrées. Encore ${res.remaining} cargo(s) à livrer.`
          : `${qty} barquettes livrées. Tous les cargos sont livrés.`,
    });
    setDeliveringCargo(null);
    load();
  };

  const reportIncident = async () => {
    if (!profile || !incidentDesc.trim()) return;
    setBusy(true);
    const { error } = await supabase.from('incidents').insert({
      type: incidentType,
      description: incidentDesc.trim().slice(0, 1000),
      driver_id: profile.id,
      route_id: activeRoute?.id ?? null,
      cargo_id: incidentCargoId || null,
    });
    setBusy(false);
    if (error) {
      toast({ title: 'Signalement non envoyé', description: failMessage(error), variant: 'destructive' });
      return;
    }
    toast({ title: 'Incident signalé', description: "L'administration a été prévenue." });
    setIncidentModal(false);
    setIncidentDesc('');
    setIncidentCargoId('');
  };

  const finishRoute = async () => {
    if (!activeRoute) return;
    setBusy(true);
    const res = await callRpc<{ delivered: number }>('finish_route', { p_route_id: activeRoute.id });
    setBusy(false);
    if (!res.ok) {
      toast({ title: 'Tournée non terminée', description: res.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Tournée terminée', description: `${res.delivered} cargo(s) livré(s).` });
    setActiveRoute(null);
    setStep('cargos');
  };

  if (!profile || step === null) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (step === 'checkin') {
    return (
      <div className="max-w-md mx-auto space-y-6">
        <div className="text-center pt-6">
          <h1 className="text-2xl font-bold">Espace Livreur</h1>
          <p className="text-sm text-muted-foreground mt-1">{profile.full_name}</p>
        </div>
        <Card>
          <CardContent className="pt-6 text-center space-y-4">
            <div className="w-20 h-20 rounded-3xl bg-primary/10 flex items-center justify-center mx-auto">
              <Truck className="w-10 h-10 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold text-lg">Prise de service</h2>
              <p className="text-sm text-muted-foreground mt-1">Confirmez votre début de service.</p>
            </div>
            <Button className="w-full h-12" onClick={handleCheckin} disabled={busy}>
              {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Confirmer mon arrivée'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const errorCard = loadError && (
    <Card className="border-destructive/40">
      <CardContent className="pt-6 text-center space-y-3">
        <p className="text-sm text-destructive">Impossible de charger les cargos. Vérifiez votre connexion.</p>
        <Button variant="outline" onClick={load}>
          <RefreshCw className="w-4 h-4 mr-2" /> Réessayer
        </Button>
      </CardContent>
    </Card>
  );

  if (step === 'cargos') {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Cargos disponibles</h1>
            <p className="text-sm text-muted-foreground mt-1">Sélectionnez les cargos à charger</p>
          </div>
          <Button variant="outline" size="icon" onClick={load} disabled={loading} aria-label="Actualiser">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>

        {errorCard}

        {loading && !loadError ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          !loadError && (
            <>
              {closedCargos.length > 0 && (
                <div className="space-y-3">
                  <h2 className="text-sm font-semibold text-muted-foreground">
                    À charger ({closedCargos.length})
                  </h2>
                  {closedCargos.map((cargo) => (
                    <CargoCard
                      key={cargo.id}
                      cargo={cargo}
                      selected={selectedCargoIds.includes(cargo.id)}
                      selectable={receivedCargoIds.includes(cargo.id)}
                      actionLabel={!receivedCargoIds.includes(cargo.id) ? 'Réceptionner et vérifier' : undefined}
                      onAction={!receivedCargoIds.includes(cargo.id) ? () => { setReceivingCargo(cargo); setReceiptChecks([false,false,false]); } : undefined}
                      onSelect={() => toggleCargoSelection(cargo.id)}
                    />
                  ))}
                  {selectedCargoIds.length > 0 && (
                    <Button className="w-full h-12" onClick={confirmLoading} disabled={busy}>
                      {busy ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                      )}
                      Confirmer le chargement ({selectedCargoIds.length})
                    </Button>
                  )}
                </div>
              )}

              {loadedCargos.length > 0 && (
                <div className="space-y-3">
                  <h2 className="text-sm font-semibold text-muted-foreground">
                    Dans mon camion — prêts à partir ({loadedCargos.length})
                  </h2>
                  {loadedCargos.map((cargo) => (
                    <CargoCard key={cargo.id} cargo={cargo} />
                  ))}
                  <Button className="w-full h-12" onClick={startRoute} disabled={busy}>
                    {busy ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Navigation className="w-4 h-4 mr-2" />
                    )}
                    Démarrer ma tournée
                  </Button>
                </div>
              )}

      {receivingCargo && (
        <Modal title={`Réception — ${receivingCargo.code}`} onClose={() => setReceivingCargo(null)}>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Vérifiez physiquement le cargo avant de confirmer sa prise en charge.</p>
            <p className="font-medium">{receivingCargo.sites?.name} · {receivingCargo.service} · {receivingCargo.meal_unit_count} barquettes</p>
            {['Quantité de barquettes vérifiée', 'Site et service de destination vérifiés', 'Cargo et barquettes en bon état'].map((label, index) => (
              <label key={index} className="flex items-center gap-3 rounded-lg border p-3 text-sm">
                <input type="checkbox" className="h-5 w-5" checked={receiptChecks[index]} onChange={(e) => setReceiptChecks((prev) => prev.map((v, i) => i === index ? e.target.checked : v))} />
                {label}
              </label>
            ))}
            <Button className="w-full h-12" disabled={busy || !receiptChecks.every(Boolean)} onClick={confirmReceipt}>
              <ClipboardCheck className="w-4 h-4 mr-2" /> Confirmer la réception
            </Button>
            <p className="text-xs text-muted-foreground">En cas d'écart ou de dommage, fermez cette fenêtre et signalez un incident à votre responsable avant de charger.</p>
          </div>
        </Modal>
      )}

              {closedCargos.length === 0 && loadedCargos.length === 0 && (
                <Card>
                  <CardContent className="pt-10 pb-10 text-center">
                    <Package className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground">Aucun cargo disponible pour le moment</p>
                  </CardContent>
                </Card>
              )}
            </>
          )
        )}
      </div>
    );
  }

  const remaining = routeCargos.filter((c) => c.status === 'in_delivery');
  const delivered = routeCargos.filter((c) => c.status === 'delivered');
  const progress = routeCargos.length > 0 ? (delivered.length / routeCargos.length) * 100 : 0;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Tournée en cours</h1>
          <p className="text-sm text-muted-foreground mt-1">Livrez chaque cargo puis terminez la tournée</p>
        </div>
        <Badge className="bg-info/10 text-info">En cours</Badge>
      </div>

      {errorCard}

      <Card>
        <CardContent className="pt-5 space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">
              {delivered.length} / {routeCargos.length} cargo(s) livré(s)
            </span>
            <span className="text-muted-foreground">{remaining.length} restant(s)</span>
          </div>
          <Progress value={progress} className="h-2" />
        </CardContent>
      </Card>

      {loading && routeCargos.length === 0 ? (
        <div className="flex items-center justify-center py-10">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="space-y-3">
          {remaining.length > 0 && (
            <h2 className="text-sm font-semibold text-muted-foreground">À livrer ({remaining.length})</h2>
          )}
          {remaining.map((cargo) => (
            <CargoCard key={cargo.id} cargo={cargo} actionLabel="Livrer ce cargo" onAction={() => openDelivery(cargo)} />
          ))}
          {remaining.length === 0 && routeCargos.length > 0 && (
            <Card className="border-success/40">
              <CardContent className="pt-6 text-center">
                <CheckCircle2 className="w-10 h-10 text-success mx-auto mb-2" />
                <p className="text-sm font-medium">Tous les cargos ont été livrés</p>
                <p className="text-xs text-muted-foreground mt-1">Vous pouvez terminer la tournée.</p>
              </CardContent>
            </Card>
          )}
          {delivered.length > 0 && (
            <>
              <h2 className="text-sm font-semibold text-muted-foreground pt-2">Livrés ({delivered.length})</h2>
              {delivered.map((cargo) => (
                <CargoCard key={cargo.id} cargo={cargo} done />
              ))}
            </>
          )}
        </div>
      )}

      <div className="flex gap-3">
        <Button variant="outline" className="flex-1" onClick={() => setIncidentModal(true)}>
          <AlertTriangle className="w-4 h-4 mr-2" />
          Signaler un incident
        </Button>
        <Button
          className="flex-1"
          variant={remaining.length === 0 ? 'default' : 'ghost'}
          onClick={finishRoute}
          disabled={busy || remaining.length > 0}
        >
          Terminer la tournée
        </Button>
      </div>

      {deliveringCargo && (
        <Modal onClose={() => setDeliveringCargo(null)} title={`Livraison — ${deliveringCargo.sites.name}`}>
          <div className="space-y-4">
            <div className="rounded-xl bg-muted/50 p-3">
              <p className="text-sm font-medium">
                {deliveringCargo.code} · {deliveringCargo.recipes.name}
              </p>
              <p className="text-xs text-muted-foreground">{deliveringCargo.meal_unit_count} barquettes chargées</p>
            </div>
            <div className="space-y-2">
              <Label>Quantité livrée</Label>
              <Input
                type="number"
                inputMode="numeric"
                min={0}
                max={deliveringCargo.meal_unit_count}
                value={deliveryQty}
                onChange={(e) => setDeliveryQty(e.target.value)}
              />
              {Number(deliveryQty) < deliveringCargo.meal_unit_count && deliveryQty !== '' && (
                <p className="text-xs text-warning">
                  {deliveringCargo.meal_unit_count - Number(deliveryQty)} barquette(s) manquante(s) : l'administration
                  sera prévenue.
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label>Photo du déchargement (obligatoire)</Label>
              <label className="block">
                <div className="border-2 border-dashed rounded-xl p-6 text-center cursor-pointer hover:border-primary transition-colors">
                  {photoLoading ? (
                    <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto" />
                  ) : deliveryPhoto ? (
                    <img src={deliveryPhoto} alt="Preuve de livraison" className="max-h-40 mx-auto rounded-lg" />
                  ) : (
                    <>
                      <Camera className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">Prendre une photo</p>
                    </>
                  )}
                </div>
                <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handlePhotoCapture} />
              </label>
            </div>
            <div className="space-y-2">
              <Label>Notes {Number(deliveryQty) < deliveringCargo.meal_unit_count ? '(obligatoire)' : '(facultatif)'}</Label>
              <Textarea
                value={deliveryNotes}
                onChange={(e) => setDeliveryNotes(e.target.value)}
                placeholder="Différence, remarque..."
                rows={2}
                maxLength={1000}
              />
            </div>
            <Button className="w-full h-12" onClick={confirmDelivery} disabled={!deliveryPhoto || deliveryQty === '' || busy}>
              {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
              Confirmer la livraison
            </Button>
          </div>
        </Modal>
      )}

      {incidentModal && (
        <Modal onClose={() => setIncidentModal(false)} title="Signaler un incident">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Type d&apos;incident</Label>
              <select
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
                value={incidentType}
                onChange={(e) => setIncidentType(e.target.value)}
              >
                <option value="delay">Retard</option>
                <option value="missing_cargo">Cargo manquant</option>
                <option value="damaged">Barquettes endommagées</option>
                <option value="wrong_destination">Mauvaise destination</option>
                <option value="wrong_quantity">Quantité incorrecte</option>
                <option value="transport_incident">Incident de transport</option>
                <option value="other">Autre</option>
              </select>
            </div>
            {routeCargos.length > 0 && (
              <div className="space-y-2">
                <Label>Cargo concerné (facultatif)</Label>
                <select
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
                  value={incidentCargoId}
                  onChange={(e) => setIncidentCargoId(e.target.value)}
                >
                  <option value="">Aucun en particulier</option>
                  {routeCargos.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.code} — {c.sites.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                value={incidentDesc}
                onChange={(e) => setIncidentDesc(e.target.value)}
                placeholder="Décrivez l'incident..."
                rows={3}
                maxLength={1000}
              />
            </div>
            <Button className="w-full h-12" onClick={reportIncident} disabled={!incidentDesc.trim() || busy}>
              {busy && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Envoyer le signalement
            </Button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function CargoCard({
  cargo,
  selectable,
  selected,
  onSelect,
  actionLabel,
  onAction,
  done,
}: {
  cargo: CargoRow;
  selectable?: boolean;
  selected?: boolean;
  onSelect?: () => void;
  actionLabel?: string;
  onAction?: () => void;
  done?: boolean;
}) {
  return (
    <Card
      className={`transition-colors ${selected ? 'border-primary bg-primary/5' : ''} ${done ? 'opacity-70' : ''} ${
        selectable ? 'cursor-pointer hover:border-primary/50' : ''
      }`}
      onClick={selectable ? onSelect : undefined}
    >
      <CardContent className="pt-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            {selectable && (
              <span
                className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                  selected ? 'border-primary bg-primary' : 'border-border'
                }`}
              >
                {selected && <CheckCircle2 className="w-3 h-3 text-primary-foreground" />}
              </span>
            )}
            {done && <CheckCircle2 className="w-5 h-5 text-success" />}
            <div>
              <p className="font-semibold text-sm">{cargo.code}</p>
              <p className="text-xs text-muted-foreground">{cargo.recipes?.name}</p>
            </div>
          </div>
          <Badge variant="secondary">{cargo.meal_unit_count} barquettes</Badge>
        </div>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <MapPin className="w-3 h-3" /> {cargo.sites?.name}
          </span>
          <span className="flex items-center gap-1 capitalize">
            <Clock className="w-3 h-3" /> {cargo.service}
          </span>
        </div>
        {actionLabel && onAction && (
          <Button size="sm" className="w-full mt-3" onClick={onAction}>
            {actionLabel}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

function Modal({ children, title, onClose }: { children: React.ReactNode; title: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center" onClick={onClose}>
      <Card
        className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">{title}</CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} aria-label="Fermer">
              <X className="w-5 h-5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>{children}</CardContent>
      </Card>
    </div>
  );
}
