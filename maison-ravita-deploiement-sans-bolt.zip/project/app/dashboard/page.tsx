'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';

const roleHomePaths: Record<string, string> = {
  admin: '/dashboard/admin',
  cook: '/dashboard/stocks',
  preparator: '/dashboard/production',
  driver: '/dashboard/livraisons',
  courier: '/dashboard/achats',
};

export default function DashboardRedirectPage() {
  const { profile, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && profile) {
      const path = roleHomePaths[profile.role] ?? '/dashboard/stocks';
      router.replace(path);
    }
  }, [profile, loading, router]);

  return (
    <div className="flex items-center justify-center py-20">
      <p className="text-muted-foreground">Chargement...</p>
    </div>
  );
}
