'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase, type Cargo, type Site, type Recipe } from '@/lib/supabase';
import { callRpc, failMessage } from '@/lib/rpc';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  QrCode,
  Camera,
  Package,
  CheckCircle2,
  XCircle,
  Loader2,
  ScanLine,
  X,
  AlertCircle,
  ChefHat,
  ArrowRight,
  ArrowLeft,
} from 'lucide-react';
import jsQR from 'jsqr';
import { toast } from '@/hooks/use-toast';

type Step = 'checkin' | 'hygiene' | 'site' | 'service' | 'prepare';

const HYGIENE_ITEMS = [
  { key: 'hands', label: 'Mains lavées' },
  { key: 'outfit', label: 'Tenue propre' },
  { key: 'hair', label: 'Protection des cheveux' },
  { key: 'station', label: 'Poste nettoyé' },
  { key: 'equipment', label: 'Matériel prêt' },
  { key: 'safety', label: 'Consignes de sécurité comprises' },
];

type OpenCargoResult = {
  cargo: Cargo;
  recipe: Recipe;
  my_total_today: number;
  site_done: number;
  site_target: number;
};

export default function ProductionPage() {
  const { profile } = useAuth();
  const [step, setStep] = useState<Step | null>(null);
  const [sites, setSites] = useState<Site[]>([]);
  const [selectedSite, setSelectedSite] = useState<Site | null>(null);
  const [selectedService, setSelectedService] = useState<'midi' | 'soir' | null>(null);
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [activeCargo, setActiveCargo] = useState<Cargo | null>(null);
  const [cargoCount, setCargoCount] = useState(0);
  const [totalToday, setTotalToday] = useState(0);
  const [siteDone, setSiteDone] = useState(0);
  const [siteTarget, setSiteTarget] = useState(0);
  const [blocked, setBlocked] = useState<string | null>(null);
  const [opening, setOpening] = useState(false);
  const [busy, setBusy] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [lastScanResult, setLastScanResult] = useState<{ ok: boolean; message: string } | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const scanIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanLockRef = useRef(false);
  const [hygieneItems, setHygieneItems] = useState<Record<string, boolean>>({});

  useEffect(() => {
    supabase
      .from('sites')
      .select('*')
      .order('name')
      .then(({ data, error }) => {
        if (error) {
          toast({ title: 'Sites indisponibles', description: failMessage(error), variant: 'destructive' });
          return;
        }
        setSites((data ?? []) as Site[]);
      });
  }, []);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const start = new Date();
      start.setHours(0, 0, 0, 0);
      const since = start.toISOString();
      const [checkin, hygiene] = await Promise.all([
        supabase.from('employee_checkins').select('id').eq('user_id', profile.id).gte('check_in_at', since).limit(1),
        supabase.from('hygiene_checklists').select('id').eq('user_id', profile.id).gte('created_at', since).limit(1),
      ]);
      if (!checkin.data?.length) setStep('checkin');
      else if (!hygiene.data?.length) setStep('hygiene');
      else setStep('site');
    })();
  }, [profile]);

  const handleCheckin = async () => {
    if (!profile) return;
    setBusy(true);
    const { error } = await supabase.from('employee_checkins').insert({
      user_id: profile.id,
      location_verified: false,
    });
    setBusy(false);
    if (error) {
      toast({ title: 'Pointage non enregistré', description: failMessage(error), variant: 'destructive' });
      return;
    }
    toast({ title: 'Pointage enregistré', description: 'Vous êtes pointé(e) pour aujourd\u2019hui.' });
    setStep('hygiene');
  };

  const handleHygieneConfirm = async () => {
    if (!profile) return;
    const allChecked = HYGIENE_ITEMS.every((item) => hygieneItems[item.key]);
    if (!allChecked) {
      toast({ title: 'Checklist incomplète', description: 'Veuillez cocher tous les éléments.', variant: 'destructive' });
      return;
    }
    setBusy(true);
    const { error } = await supabase.from('hygiene_checklists').insert({
      user_id: profile.id,
      items: hygieneItems,
      confirmed: true,
    });
    setBusy(false);
    if (error) {
      toast({ title: 'Checklist non enregistrée', description: failMessage(error), variant: 'destructive' });
      return;
    }
    setStep('site');
  };

  const handleSiteSelect = (site: Site) => {
    setSelectedSite(site);
    setStep('service');
  };

  const openCargo = useCallback(async (site: Site, service: 'midi' | 'soir') => {
    setOpening(true);
    setBlocked(null);
    const res = await callRpc<OpenCargoResult>('open_cargo', { p_site_id: site.id, p_service: service });
    setOpening(false);
    if (!res.ok) {
      setActiveCargo(null);
      setRecipe(null);
      setBlocked(res.message);
      return;
    }
    setActiveCargo(res.cargo);
    setCargoCount(res.cargo.meal_unit_count);
    setRecipe(res.recipe);
    setTotalToday(Number(res.my_total_today));
    setSiteDone(Number(res.site_done));
    setSiteTarget(Number(res.site_target));
  }, []);

  const handleServiceSelect = (service: 'midi' | 'soir') => {
    if (!selectedSite) return;
    setSelectedService(service);
    setLastScanResult(null);
    setStep('prepare');
    openCargo(selectedSite, service);
  };

  const processScan = async (qrCode: string) => {
    if (!activeCargo || !selectedSite || !selectedService || scanLockRef.current) return;
    scanLockRef.current = true;
    const res = await callRpc<{ cargo_count: number; max_capacity: number }>('process_scan', {
      p_qr_code: qrCode,
      p_cargo_id: activeCargo.id,
      p_site_id: selectedSite.id,
      p_service: selectedService,
      p_recipe_id: activeCargo.recipe_id,
    });
    scanLockRef.current = false;
    if (!res.ok) {
      setLastScanResult({ ok: false, message: res.message });
      toast({ title: 'Scan refusé', description: res.message, variant: 'destructive' });
      return;
    }
    setCargoCount(res.cargo_count);
    setTotalToday((prev) => prev + 1);
    setSiteDone((prev) => prev + 1);
    const full = res.cargo_count >= res.max_capacity;
    setLastScanResult({
      ok: true,
      message: full ? 'Cargo plein : fermez-le pour continuer.' : 'Barquette enregistrée',
    });
  };
  const startCamera = async () => {
    setScanning(true);
    setLastScanResult(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      scanIntervalRef.current = setInterval(() => {
        scanFrame();
      }, 200);
    } catch {
      toast({
        title: 'Caméra indisponible',
        description: 'Utilisez la saisie manuelle à la place.',
        variant: 'destructive',
      });
      setScanning(false);
    }
  };

  const scanFrame = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video.readyState !== video.HAVE_ENOUGH_DATA) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height);
    if (code) {
      stopCamera();
      processScan(code.data);
    }
  };

  const stopCamera = () => {
    setScanning(false);
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  const closeCargo = async () => {
    if (!activeCargo || !selectedSite || !selectedService) return;
    setBusy(true);
    const res = await callRpc<{ count: number }>('close_cargo', { p_cargo_id: activeCargo.id });
    setBusy(false);
    if (!res.ok) {
      toast({ title: 'Cargo non fermé', description: res.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Cargo fermé', description: `${res.count} barquettes prêtes au chargement.` });
    setLastScanResult(null);
    openCargo(selectedSite, selectedService);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualCode.trim()) {
      processScan(manualCode.trim());
      setManualCode('');
    }
  };

  if (!profile || step === null) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  // Step: Check-in
  if (step === 'checkin') {
    return (
      <div className="max-w-md mx-auto space-y-6">
        <div className="text-center pt-6">
          <h1 className="text-2xl font-bold">Bienvenue, {profile.full_name}</h1>
          <p className="text-sm text-muted-foreground mt-1">Préparateur — Maison Ravita</p>
        </div>
        <Card>
          <CardContent className="pt-6 text-center space-y-4">
            <div className="w-20 h-20 rounded-3xl bg-primary/10 flex items-center justify-center mx-auto">
              <ChefHat className="w-10 h-10 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold text-lg">Pointage d'arrivée</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Confirmez votre arrivée pour commencer votre service.
              </p>
            </div>
            <Button className="w-full h-12 text-base" onClick={handleCheckin} disabled={busy}>
              {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Confirmer mon arrivée'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Step: Hygiene
  if (step === 'hygiene') {
    return (
      <div className="max-w-md mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Consignes d'hygiène</h1>
          <p className="text-sm text-muted-foreground mt-1">Cochez tous les éléments avant de commencer.</p>
        </div>
        <Card>
          <CardContent className="pt-6 space-y-3">
            {HYGIENE_ITEMS.map((item) => (
              <label
                key={item.key}
                className="flex items-center gap-3 p-3 rounded-xl border cursor-pointer hover:bg-muted/50 transition-colors"
              >
                <input
                  type="checkbox"
                  checked={hygieneItems[item.key] ?? false}
                  onChange={(e) =>
                    setHygieneItems({ ...hygieneItems, [item.key]: e.target.checked })
                  }
                  className="w-5 h-5 rounded accent-primary"
                />
                <span className="text-sm font-medium">{item.label}</span>
              </label>
            ))}
          </CardContent>
        </Card>
        <Button className="w-full h-12 text-base" onClick={handleHygieneConfirm} disabled={busy}>
          {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Commencer'}
        </Button>
      </div>
    );
  }

  // Step: Site selection
  if (step === 'site') {
    return (
      <div className="max-w-md mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Choisir le site</h1>
          <p className="text-sm text-muted-foreground mt-1">Sélectionnez le site de préparation.</p>
        </div>
        <div className="space-y-3">
          {sites.map((site) => (
            <button
              key={site.id}
              onClick={() => handleSiteSelect(site)}
              className="w-full p-5 rounded-2xl border-2 border-border hover:border-primary hover:bg-primary/5 transition-all text-left flex items-center justify-between"
            >
              <div>
                <p className="font-semibold text-lg">{site.name}</p>
                <p className="text-sm text-muted-foreground">{site.capacity} barquettes</p>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Step: Service selection
  if (step === 'service') {
    return (
      <div className="max-w-md mx-auto space-y-6">
        <button onClick={() => setStep('site')} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="w-4 h-4" /> Retour
        </button>
        <div>
          <h1 className="text-2xl font-bold">Choisir le service</h1>
          <p className="text-sm text-muted-foreground mt-1">{selectedSite?.name}</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {(['midi', 'soir'] as const).map((svc) => (
            <button
              key={svc}
              onClick={() => handleServiceSelect(svc)}
              className="p-6 rounded-2xl border-2 border-border hover:border-primary hover:bg-primary/5 transition-all"
            >
              <p className="font-semibold text-xl capitalize">{svc}</p>
              <p className="text-sm text-muted-foreground mt-1">
                {svc === 'midi' ? 'Service du midi' : 'Service du soir'}
              </p>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // Step: Prepare (main scanning interface)
  if (step === 'prepare') {
    const capacity = activeCargo?.max_capacity ?? 0;
    const cargoFull = capacity > 0 && cargoCount >= capacity;
    const backToService = (
      <button
        onClick={() => {
          stopCamera();
          setStep('service');
        }}
        className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="w-4 h-4" /> Changer de service
      </button>
    );

    if (opening) {
      return (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      );
    }

    if (blocked || !activeCargo) {
      return (
        <div className="max-w-md mx-auto space-y-4">
          {backToService}
          <Card className="border-destructive/40">
            <CardContent className="pt-6 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto">
                <AlertCircle className="w-8 h-8 text-destructive" />
              </div>
              <div>
                <h2 className="font-semibold text-lg">Scan impossible</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  {blocked ?? 'Le cargo n\u2019a pas pu être ouvert.'}
                </p>
              </div>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => selectedSite && selectedService && openCargo(selectedSite, selectedService)}
              >
                Réessayer
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    return (
      <div className="max-w-md mx-auto space-y-4">
        {backToService}
        <div className="sticky top-16 bg-card border rounded-2xl p-4 shadow-sm z-10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold">Cargo en cours</span>
            <Badge variant="secondary">{activeCargo.code}</Badge>
          </div>
          <div className="flex items-end gap-2 mb-2">
            <span className={`text-4xl font-bold tabular-nums ${cargoFull ? 'text-warning' : 'text-primary'}`}>
              {cargoCount}
            </span>
            <span className="text-lg text-muted-foreground mb-1">/ {capacity}</span>
          </div>
          <Progress value={capacity ? (cargoCount / capacity) * 100 : 0} className="h-2" />
          <div className="grid grid-cols-2 gap-2 mt-3 text-xs text-muted-foreground">
            <span>
              Mon total du jour : <strong className="text-foreground">{totalToday}</strong>
            </span>
            <span className="text-right">
              {selectedSite?.name} · {selectedService} :{' '}
              <strong className="text-foreground">
                {siteDone} / {siteTarget}
              </strong>
            </span>
          </div>
        </div>

        {recipe && (
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center gap-2 mb-2">
                <ChefHat className="w-4 h-4 text-primary" />
                <span className="text-sm font-semibold">{recipe.name}</span>
              </div>
              <p className="text-xs text-muted-foreground">
                {Number(recipe.cost_per_portion).toFixed(2)} €/portion ·{' '}
                {recipe.allergens?.length ? recipe.allergens.join(', ') : 'Aucun allergène'}
              </p>
            </CardContent>
          </Card>
        )}

        {/* Scan result feedback */}
        {lastScanResult && (
          <div
            className={`p-4 rounded-xl flex items-center gap-3 fade-in ${
              lastScanResult.ok
                ? 'bg-success/10 text-success'
                : 'bg-destructive/10 text-destructive'
            }`}
          >
            {lastScanResult.ok ? (
              <CheckCircle2 className="w-5 h-5 shrink-0" />
            ) : (
              <XCircle className="w-5 h-5 shrink-0" />
            )}
            <span className="text-sm font-medium">{lastScanResult.message}</span>
          </div>
        )}

        {/* Scanner */}
        <Card>
          <CardContent className="pt-4 space-y-4">
            {scanning ? (
              <div className="relative">
                <video
                  ref={videoRef}
                  className="w-full rounded-xl bg-black aspect-[3/4] object-cover"
                  playsInline
                  muted
                />
                <canvas ref={canvasRef} className="hidden" />
                <div className="absolute inset-8 border-2 border-white/70 rounded-2xl pointer-events-none">
                  <div className="absolute left-0 right-0 h-0.5 bg-primary scan-line" />
                </div>
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2 rounded-full"
                  onClick={stopCamera}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <Button
                className="w-full h-32 flex-col gap-2 text-base"
                onClick={startCamera}
                disabled={cargoFull}
              >
                <ScanLine className="w-10 h-10" />
                Scanner une barquette
              </Button>
            )}

            {/* Manual entry */}
            <form onSubmit={handleManualSubmit} className="space-y-2">
              <Label className="text-xs text-muted-foreground">Saisie manuelle (en cas de problème caméra)</Label>
              <div className="flex gap-2">
                <Input
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder="Code QR..."
                  className="text-sm"
                />
                <Button type="submit" size="default" disabled={cargoFull}>
                  Valider
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Close cargo */}
        <Button
          className="w-full h-12"
          variant={cargoFull ? 'default' : 'outline'}
          onClick={closeCargo}
          disabled={cargoCount === 0 || busy}
        >
          <Package className="w-4 h-4 mr-2" />
          Fermer le cargo ({cargoCount} barquettes)
        </Button>
      </div>
    );
  }

  return null;
}
