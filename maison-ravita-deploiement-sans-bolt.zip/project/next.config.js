/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: { unoptimized: true },
  swcMinify: false,
  webpack: (config) => {
    config.watchOptions = undefined;
    config.cache = false;
    config.snapshot = { managedPaths: [] };
    return config;
  },
  experimental: {
    cpus: 1,
  },
};

module.exports = nextConfig;
