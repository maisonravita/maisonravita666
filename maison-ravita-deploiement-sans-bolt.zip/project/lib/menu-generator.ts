export type GenerationMode = 'stock' | 'libre';

export type PlannableRecipe = {
  id: string;
  name: string;
  main_protein: string;
  lines: Array<{ ingredient_id: string; qty: number }>;
};

export type Slot = { date: string; service: 'midi' | 'soir'; portions: number };

export type PlannedSlot = Slot & { recipe_id: string; coverage: number };

export function recipeCost(
  lines: PlannableRecipe['lines'],
  prices: Map<string, number>
): number {
  return lines.reduce((sum, l) => sum + l.qty * (prices.get(l.ingredient_id) ?? 0), 0);
}

export function stockCoverage(
  recipe: PlannableRecipe,
  stock: Map<string, number>,
  portions: number
): number {
  if (recipe.lines.length === 0) return 0;
  const total = recipe.lines.reduce((sum, l) => {
    const needed = l.qty * portions;
    const available = stock.get(l.ingredient_id) ?? 0;
    return sum + Math.min(1, available / needed);
  }, 0);
  return total / recipe.lines.length;
}

type PickContext = {
  mode: GenerationMode;
  stock: Map<string, number>;
  usage: Map<string, number>;
  avoidProteins: string[];
  excludeId?: string;
};

export function pickRecipe(
  pool: PlannableRecipe[],
  slot: Slot,
  ctx: PickContext
): { recipe: PlannableRecipe; coverage: number } | null {
  const candidates = pool.filter((r) => r.id !== ctx.excludeId);
  if (candidates.length === 0) return null;

  let best: { recipe: PlannableRecipe; coverage: number; score: number } | null = null;
  for (const recipe of candidates) {
    const coverage = stockCoverage(recipe, ctx.stock, slot.portions);
    let score = -(ctx.usage.get(recipe.id) ?? 0) * 1.5;
    ctx.avoidProteins.forEach((p, i) => {
      if (p === recipe.main_protein) score -= i === 0 ? 0.6 : 0.3;
    });
    score += ctx.mode === 'stock' ? coverage * 3 + Math.random() * 0.15 : Math.random() * 1.2;
    if (!best || score > best.score) best = { recipe, coverage, score };
  }
  return best && { recipe: best.recipe, coverage: best.coverage };
}

function consume(stock: Map<string, number>, recipe: PlannableRecipe, portions: number) {
  for (const l of recipe.lines) {
    const left = (stock.get(l.ingredient_id) ?? 0) - l.qty * portions;
    stock.set(l.ingredient_id, Math.max(0, left));
  }
}

export function planWeek(
  pool: PlannableRecipe[],
  slots: Slot[],
  mode: GenerationMode,
  initialStock: Map<string, number>,
  locked: Map<string, PlannableRecipe>
): PlannedSlot[] {
  const stock = new Map(initialStock);
  const usage = new Map<string, number>();
  const proteinBySlot = new Map<string, string>();
  const key = (s: Slot) => `${s.date}|${s.service}`;

  locked.forEach((recipe, k) => {
    usage.set(recipe.id, (usage.get(recipe.id) ?? 0) + 1);
    proteinBySlot.set(k, recipe.main_protein);
  });

  const planned: PlannedSlot[] = [];
  let previousProtein: string | undefined;

  for (const slot of slots) {
    const lockedRecipe = locked.get(key(slot));
    if (lockedRecipe) {
      consume(stock, lockedRecipe, slot.portions);
      previousProtein = lockedRecipe.main_protein;
      continue;
    }
    const otherService = proteinBySlot.get(`${slot.date}|${slot.service === 'midi' ? 'soir' : 'midi'}`);
    const avoid = [otherService, previousProtein].filter((p): p is string => !!p);
    const pick = pickRecipe(pool, slot, { mode, stock, usage, avoidProteins: avoid });
    if (!pick) continue;
    planned.push({ ...slot, recipe_id: pick.recipe.id, coverage: pick.coverage });
    usage.set(pick.recipe.id, (usage.get(pick.recipe.id) ?? 0) + 1);
    proteinBySlot.set(key(slot), pick.recipe.main_protein);
    previousProtein = pick.recipe.main_protein;
    if (mode === 'stock') consume(stock, pick.recipe, slot.portions);
  }
  return planned;
}
