import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL as string;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Missing Supabase environment variables. Please check your .env file.'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type UserRole =
  | 'admin'
  | 'cook'
  | 'preparator'
  | 'driver'
  | 'courier';

export type MealService = 'midi' | 'soir';

export type CargoStatus =
  | 'open'
  | 'closed'
  | 'loaded'
  | 'in_delivery'
  | 'delivered';

export type RecipeStatus = 'draft' | 'validated' | 'archived';

export type MenuStatus = 'draft' | 'validated' | 'rejected';

export type RequestStatus =
  | 'sent'
  | 'viewed'
  | 'processing'
  | 'resolved'
  | 'rejected';

export type RequestType =
  | 'missing_ingredient'
  | 'stock_shortage'
  | 'damaged_product'
  | 'equipment_issue'
  | 'hygiene_issue'
  | 'recipe_error'
  | 'other';

export type UrgencyLevel = 'low' | 'medium' | 'high' | 'critical';

export type StockMovementType =
  | 'in'
  | 'out'
  | 'loss'
  | 'adjustment'
  | 'inventory';

export type PurchaseStatus = 'pending' | 'purchased' | 'received' | 'rejected';

export type InvoiceStatus =
  | 'imported'
  | 'to_verify'
  | 'validated'
  | 'rejected';

export type DeliveryIncidentType =
  | 'delay'
  | 'missing_cargo'
  | 'damaged'
  | 'wrong_destination'
  | 'wrong_quantity'
  | 'transport_incident'
  | 'other';

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  phone?: string;
  active: boolean;
  created_at: string;
  hourly_rate?: number;
}

export interface Site {
  id: string;
  name: string;
  capacity: number;
  address?: string;
  latitude?: number;
  longitude?: number;
  created_at: string;
}

export interface Recipe {
  id: string;
  name: string;
  description?: string;
  photo_url?: string;
  servings: number;
  prep_time_minutes: number;
  cook_time_minutes: number;
  cost_per_portion: number;
  allergens: string[];
  conservation?: string;
  steps: string[];
  status: RecipeStatus;
  main_protein: string;
  created_at: string;
  updated_at: string;
}

export interface RecipeIngredient {
  id: string;
  recipe_id: string;
  ingredient_id: string;
  quantity_per_portion: number;
  unit: string;
}

export interface Ingredient {
  id: string;
  name: string;
  category: string;
  unit: string;
  package_size?: number;
  price: number;
  supplier?: string;
  alert_threshold: number;
  contains_pork: boolean;
  contains_alcohol: boolean;
  halal_certified: boolean;
  created_at: string;
}

export interface StockLot {
  id: string;
  ingredient_id: string;
  lot_number?: string;
  quantity: number;
  unit: string;
  expiry_date?: string;
  received_at: string;
}

export interface StockMovement {
  id: string;
  ingredient_id: string;
  movement_type: StockMovementType;
  quantity: number;
  unit: string;
  reason?: string;
  user_id: string;
  created_at: string;
}

export interface Menu {
  id: string;
  date: string;
  service: MealService;
  site_id: string | null;
  recipe_id: string;
  status: MenuStatus;
  quantity: number;
  created_at: string;
  validated_by?: string;
  validated_at?: string;
}

export interface Cargo {
  id: string;
  code: string;
  site_id: string;
  service: MealService;
  recipe_id: string;
  preparator_id: string;
  meal_unit_count: number;
  max_capacity: number;
  status: CargoStatus;
  photo_url?: string;
  created_at: string;
  closed_at?: string;
  loaded_at?: string;
  delivered_at?: string;
  driver_id?: string | null;
  route_id?: string | null;
}

export interface MealUnit {
  id: string;
  qr_code: string;
  cargo_id: string;
  site_id: string;
  service: MealService;
  recipe_id: string;
  scanned_at: string;
  scanned_by: string;
}

export interface ScanEvent {
  id: string;
  qr_code: string;
  meal_unit_id?: string;
  cargo_id: string;
  user_id: string;
  success: boolean;
  error_message?: string;
  created_at: string;
}

export interface EmployeeCheckin {
  id: string;
  user_id: string;
  check_in_at: string;
  check_out_at?: string;
  latitude?: number;
  longitude?: number;
  location_verified: boolean;
}

export interface HygieneChecklist {
  id: string;
  user_id: string;
  date: string;
  items: Record<string, boolean>;
  confirmed: boolean;
  created_at: string;
}

export interface Request {
  id: string;
  user_id: string;
  type: RequestType;
  category: string;
  description: string;
  quantity_missing?: number;
  urgency: UrgencyLevel;
  photo_url?: string;
  service?: MealService;
  status: RequestStatus;
  rejection_reason?: string;
  created_at: string;
  updated_at: string;
}

export interface Notification {
  id: string;
  user_id?: string;
  title: string;
  message: string;
  type: string;
  read: boolean;
  link?: string;
  created_at: string;
}

export interface ShoppingItem {
  id: string;
  ingredient_id: string;
  quantity_needed: number;
  unit: string;
  priority: 'low' | 'medium' | 'high';
  status: PurchaseStatus;
  estimated_price: number;
  supplier?: string;
  reason?: string | null;
  halal_required: boolean;
  created_at: string;
}

export interface Purchase {
  id: string;
  shopping_item_id?: string;
  ingredient_id: string;
  quantity_bought: number;
  unit: string;
  actual_price: number;
  receipt_photo_url?: string;
  substitution?: string;
  status: PurchaseStatus;
  courier_id: string;
  created_at: string;
  received_at?: string;
}

export interface SupplierInvoice {
  id: string;
  category: string;
  supplier?: string;
  invoice_number?: string;
  invoice_date?: string;
  amount_ht: number;
  tva_rate: number;
  amount_ttc: number;
  document_url?: string;
  status: InvoiceStatus;
  purchase_id?: string;
  created_at: string;
}

export interface DeliveryRoute {
  id: string;
  driver_id: string;
  status: 'planned' | 'active' | 'completed' | 'cancelled';
  started_at?: string;
  completed_at?: string;
  cargo_ids: string[];
}

export interface GpsPosition {
  id: string;
  route_id: string;
  driver_id: string;
  latitude: number;
  longitude: number;
  recorded_at: string;
}

export interface DeliveryProof {
  id: string;
  cargo_id: string;
  route_id: string;
  driver_id: string;
  site_id: string;
  quantity_delivered: number;
  photo_url: string;
  latitude?: number;
  longitude?: number;
  notes?: string;
  created_at: string;
}

export interface Incident {
  id: string;
  type: DeliveryIncidentType;
  description: string;
  cargo_id?: string;
  route_id?: string;
  driver_id: string;
  created_at: string;
}

export interface CustomerInvoice {
  id: string;
  site_id: string;
  period: string;
  quantity_billable: number;
  unit_price: number;
  amount_ht: number;
  tva_rate: number;
  amount_ttc: number;
  due_date?: string;
  paid: boolean;
  paid_at?: string;
  created_at: string;
}

export interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  entity_type: string;
  entity_id?: string;
  details: Record<string, unknown>;
  created_at: string;
}

export interface Settings {
  id: string;
  key: string;
  value: string;
  description?: string;
}

export interface StaffSchedule {
  id: string;
  user_id: string;
  date: string;
  start_time: string;
  end_time: string;
  role: UserRole;
  published: boolean;
}

export interface BudgetException {
  id: string;
  requested_by: string;
  amount: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  approved_by?: string;
  approved_at?: string;
  created_at: string;
}

export interface PayrollRecord {
  id: string;
  user_id: string;
  period: string;
  base_salary: number;
  overtime_hours: number;
  overtime_pay: number;
  bonus: number;
  advance: number;
  total: number;
  created_at: string;
}
