import { supabase } from '@/lib/supabase';

export type RpcResult<T = Record<string, unknown>> =
  | ({ ok: true } & T)
  | { ok: false; message: string };

const GENERIC = 'Action impossible pour le moment. Vérifiez votre connexion et réessayez.';

export async function callRpc<T = Record<string, unknown>>(
  fn: string,
  args?: Record<string, unknown>
): Promise<RpcResult<T>> {
  const { data, error } = await supabase.rpc(fn, args);
  if (error) {
    console.error(`rpc ${fn} failed`, error);
    return { ok: false, message: GENERIC };
  }
  const result = data as ({ status?: string; message?: string } & T) | null;
  if (!result || typeof result !== 'object' || result.status !== 'ok') {
    return { ok: false, message: result?.message ?? GENERIC };
  }
  return { ok: true, ...result };
}

export function failMessage(error: unknown): string {
  if (error) console.error(error);
  return GENERIC;
}
