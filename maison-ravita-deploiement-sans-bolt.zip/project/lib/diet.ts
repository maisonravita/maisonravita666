import type { Ingredient } from '@/lib/supabase';

export type DietRestriction = 'halal' | 'sans_porc' | 'vegetarien' | 'sans_alcool';

export const DIET_OPTIONS: Array<{ id: DietRestriction; label: string; hint: string }> = [
  { id: 'halal', label: 'Halal', hint: 'Sans porc ni alcool, viandes certifiées halal uniquement' },
  { id: 'sans_porc', label: 'Sans porc', hint: 'Aucun produit contenant du porc' },
  { id: 'sans_alcool', label: 'Sans alcool', hint: 'Aucun ingrédient contenant de l’alcool' },
  { id: 'vegetarien', label: 'Végétarien', hint: 'Ni viande ni poisson' },
];

export type DietIngredient = Pick<
  Ingredient,
  'id' | 'name' | 'category' | 'contains_pork' | 'contains_alcohol' | 'halal_certified'
>;

export type DietIssueKind = 'porc' | 'alcool' | 'non_halal' | 'viande';

export type DietIssue = { kind: DietIssueKind; ingredient: string };

export const ISSUE_LABELS: Record<DietIssueKind, string> = {
  porc: 'contient du porc',
  alcool: 'contient de l’alcool',
  non_halal: 'viande non certifiée halal',
  viande: 'contient viande ou poisson',
};

export function parseRestrictions(value: string | null | undefined): DietRestriction[] {
  const valid = new Set(DIET_OPTIONS.map((o) => o.id));
  return (value ?? '')
    .split(',')
    .map((v) => v.trim())
    .filter((v): v is DietRestriction => valid.has(v as DietRestriction));
}

export function dietIssues(
  lines: Array<{ ingredient_id: string }>,
  ingredients: Map<string, DietIngredient>,
  restrictions: DietRestriction[]
): DietIssue[] {
  if (restrictions.length === 0) return [];
  const has = (r: DietRestriction) => restrictions.includes(r);
  const issues: DietIssue[] = [];
  for (const line of lines) {
    const ing = ingredients.get(line.ingredient_id);
    if (!ing) continue;
    const isMeat = ing.category === 'viandes';
    if ((has('halal') || has('sans_porc')) && ing.contains_pork) {
      issues.push({ kind: 'porc', ingredient: ing.name });
    } else if (has('halal') && isMeat && !ing.halal_certified) {
      issues.push({ kind: 'non_halal', ingredient: ing.name });
    }
    if ((has('halal') || has('sans_alcool')) && ing.contains_alcohol) {
      issues.push({ kind: 'alcool', ingredient: ing.name });
    }
    if (has('vegetarien') && (isMeat || ing.category === 'poissons')) {
      issues.push({ kind: 'viande', ingredient: ing.name });
    }
  }
  return issues;
}

export function describeIssues(issues: DietIssue[]): string {
  return issues.map((i) => `${i.ingredient} : ${ISSUE_LABELS[i.kind]}`).join(' · ');
}
