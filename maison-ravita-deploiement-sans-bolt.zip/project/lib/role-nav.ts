import {
  LayoutDashboard,
  UtensilsCrossed,
  Package,
  ShoppingCart,
  Truck,
  Users,
  Receipt,
  ClipboardCheck,
  QrCode,
  MapPin,
  ChefHat,
  Boxes,
  FileText,
  Settings,
  Bell,
  CalendarDays,
  type LucideIcon,
} from 'lucide-react';
import type { UserRole } from './supabase';

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  roles: UserRole[];
}

export const navItems: NavItem[] = [
  { label: 'Tableau de bord', href: '/dashboard/admin', icon: LayoutDashboard, roles: ['admin'] },
  { label: 'Menus & Recettes', href: '/dashboard/menus', icon: CalendarDays, roles: ['admin'] },
  { label: 'Stocks', href: '/dashboard/stocks', icon: Boxes, roles: ['admin', 'cook'] },
  { label: 'Achats', href: '/dashboard/achats', icon: ShoppingCart, roles: ['admin', 'cook', 'courier'] },
  { label: 'Production', href: '/dashboard/production', icon: QrCode, roles: ['admin', 'preparator'] },
  { label: 'Cargos', href: '/dashboard/cargos', icon: Package, roles: ['admin', 'preparator', 'driver'] },
  { label: 'Livraisons', href: '/dashboard/livraisons', icon: Truck, roles: ['admin', 'driver'] },
  { label: 'Personnel', href: '/dashboard/personnel', icon: Users, roles: ['admin'] },
  { label: 'Finances', href: '/dashboard/finances', icon: Receipt, roles: ['admin'] },
  { label: 'Notifications', href: '/dashboard/notifications', icon: Bell, roles: ['admin', 'cook', 'preparator', 'driver', 'courier'] },
  { label: 'Paramètres', href: '/dashboard/parametres', icon: Settings, roles: ['admin'] },
];

export function getNavItemsForRole(role: UserRole): NavItem[] {
  return navItems.filter((item) => item.roles.includes(role));
}

export const roleLabels: Record<UserRole, string> = {
  admin: 'Administrateur',
  cook: 'Cuisinier',
  preparator: 'Préparateur',
  driver: 'Livreur',
  courier: 'Coursier',
};

export const roleColors: Record<UserRole, string> = {
  admin: 'bg-primary text-primary-foreground',
  cook: 'bg-orange-500 text-white',
  preparator: 'bg-blue-500 text-white',
  driver: 'bg-purple-500 text-white',
  courier: 'bg-teal-500 text-white',
};

export const roleIcons: Record<UserRole, LucideIcon> = {
  admin: LayoutDashboard,
  cook: ChefHat,
  preparator: QrCode,
  driver: Truck,
  courier: ShoppingCart,
};
