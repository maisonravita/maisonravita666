import { supabase, type Ingredient, type Recipe } from '@/lib/supabase';
import { RECIPE_CATALOG } from '@/lib/recipe-catalog';
import { recipeCost, type PlannableRecipe } from '@/lib/menu-generator';
import {
  dietIssues,
  parseRestrictions,
  type DietIngredient,
  type DietIssue,
  type DietRestriction,
} from '@/lib/diet';

export type RecipeWithLines = Recipe & PlannableRecipe & { cost: number; diet: DietIssue[] };

type PlanningIngredient = DietIngredient & Pick<Ingredient, 'unit' | 'price'>;

export type PlanningData = {
  recipes: RecipeWithLines[];
  ingredients: Map<string, PlanningIngredient>;
  stock: Map<string, number>;
  budget: number;
  portions: { midi: number; soir: number };
  restrictions: DietRestriction[];
};

type RecipeRow = Recipe & {
  recipe_ingredients: Array<{ ingredient_id: string; quantity_per_portion: number }>;
};

export async function loadPlanningData(): Promise<PlanningData> {
  const [recipesRes, ingredientsRes, lotsRes, settingsRes] = await Promise.all([
    supabase.from('recipes').select('*, recipe_ingredients(ingredient_id, quantity_per_portion)'),
    supabase
      .from('ingredients')
      .select('id, name, unit, price, category, contains_pork, contains_alcohol, halal_certified'),
    supabase.from('stock_lots').select('ingredient_id, quantity'),
    supabase.from('settings').select('key, value'),
  ]);
  const error = recipesRes.error ?? ingredientsRes.error ?? lotsRes.error ?? settingsRes.error;
  if (error) throw new Error(error.message);

  const ingredients = new Map<string, PlanningIngredient>(
    ((ingredientsRes.data ?? []) as PlanningIngredient[]).map((i) => [i.id, { ...i, price: Number(i.price) }])
  );
  const prices = new Map(Array.from(ingredients.values()).map((i) => [i.id, i.price]));

  const stock = new Map<string, number>();
  for (const lot of lotsRes.data ?? []) {
    stock.set(lot.ingredient_id, (stock.get(lot.ingredient_id) ?? 0) + Number(lot.quantity));
  }

  const rawSettings = new Map((settingsRes.data ?? []).map((s) => [s.key as string, s.value as string]));
  const settings = new Map(Array.from(rawSettings.entries()).map(([k, v]) => [k, Number(v)]));
  const restrictions = parseRestrictions(rawSettings.get('diet_restrictions'));

  const recipes = ((recipesRes.data ?? []) as RecipeRow[]).map((r) => {
    const lines = r.recipe_ingredients.map((l) => ({
      ingredient_id: l.ingredient_id,
      qty: Number(l.quantity_per_portion),
    }));
    const cost = lines.length > 0 ? recipeCost(lines, prices) : Number(r.cost_per_portion);
    return { ...r, lines, cost, diet: dietIssues(lines, ingredients, restrictions) };
  });

  return {
    recipes,
    ingredients,
    stock,
    budget: settings.get('budget_per_barquette') || 1.5,
    portions: {
      midi: settings.get('daily_production_midi') || 380,
      soir: settings.get('daily_production_soir') || 380,
    },
    restrictions,
  };
}

export async function syncRecipeCatalog(data: PlanningData): Promise<number> {
  const idByName = new Map(
    Array.from(data.ingredients.values()).map((i) => [i.name.toLowerCase(), i.id])
  );
  const prices = new Map(Array.from(data.ingredients.values()).map((i) => [i.id, i.price]));
  const existing = new Set(data.recipes.map((r) => r.name.toLowerCase()));
  let created = 0;

  for (const entry of RECIPE_CATALOG) {
    if (existing.has(entry.name.toLowerCase())) continue;
    const lines = entry.ingredients
      .map((i) => ({ ingredient_id: idByName.get(i.name.toLowerCase()), qty: i.qty }))
      .filter((l): l is { ingredient_id: string; qty: number } => !!l.ingredient_id);
    if (lines.length === 0) continue;

    const { data: recipe, error } = await supabase
      .from('recipes')
      .insert({
        name: entry.name,
        description: entry.description,
        main_protein: entry.main_protein,
        allergens: entry.allergens,
        prep_time_minutes: entry.prep_time_minutes,
        cook_time_minutes: entry.cook_time_minutes,
        conservation: entry.conservation,
        steps: entry.steps,
        cost_per_portion: Number(recipeCost(lines, prices).toFixed(2)),
        status: 'validated',
      })
      .select('id')
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!recipe) continue;

    const { error: linesError } = await supabase.from('recipe_ingredients').insert(
      lines.map((l) => ({
        recipe_id: recipe.id,
        ingredient_id: l.ingredient_id,
        quantity_per_portion: l.qty,
        unit: data.ingredients.get(l.ingredient_id)?.unit ?? 'kg',
      }))
    );
    if (linesError) throw new Error(linesError.message);
    created++;
  }
  return created;
}

export async function refreshRecipeCosts(recipes: RecipeWithLines[]) {
  const stale = recipes.filter(
    (r) => r.lines.length > 0 && Math.abs(Number(r.cost_per_portion) - r.cost) >= 0.005
  );
  await Promise.all(
    stale.map((r) =>
      supabase
        .from('recipes')
        .update({ cost_per_portion: Number(r.cost.toFixed(2)), updated_at: new Date().toISOString() })
        .eq('id', r.id)
    )
  );
}

export function eligibleRecipes(data: PlanningData): RecipeWithLines[] {
  return data.recipes.filter(
    (r) => r.status === 'validated' && r.lines.length > 0 && r.cost <= data.budget && r.diet.length === 0
  );
}

export async function saveRestrictions(restrictions: DietRestriction[]) {
  const { error } = await supabase
    .from('settings')
    .update({ value: restrictions.join(',') })
    .eq('key', 'diet_restrictions');
  if (error) throw new Error('Impossible d’enregistrer les restrictions alimentaires.');
}

export async function refreshShoppingList(): Promise<number> {
  const { data, error } = await supabase.rpc('generate_shopping_list');
  if (error) throw new Error('La liste de courses n’a pas pu être mise à jour.');
  const result = data as { created?: number } | null;
  return result?.created ?? 0;
}
